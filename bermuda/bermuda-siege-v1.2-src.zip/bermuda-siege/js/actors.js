/* BERMUDA SIEGE — actor sprites (survivors, aliens, tracers, debris) */
(function () {
  'use strict';
  var S = SG.S, ALIEN = SG.ALIEN, clamp = SG.clamp;

  function shadow(x, y, rx, ry, a) {
    var ctx = RND.ctx;
    ctx.fillStyle = 'rgba(5,14,20,' + (a || 0.28) + ')';
    ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 6.2832); ctx.fill();
  }

  function bar(x, y, w, f, col) {
    var ctx = RND.ctx;
    ctx.fillStyle = 'rgba(4,10,16,.7)';
    ctx.fillRect(x - w / 2 - 1, y - 1, w + 2, 5);
    ctx.fillStyle = col;
    ctx.fillRect(x - w / 2, y, w * clamp(f, 0, 1), 3);
  }

  function drawPlayer(p, t) {
    var ctx = RND.ctx;
    var pac = PIX.SURVIVORS[p.skin] || PIX.SURVIVORS.wanderer;
    var img = p.hit > 0 ? pac.flash : pac.img;
    var flip = Math.cos(p.aim) < 0;
    var walking = Math.hypot(p.in && p.in.mx || 0, p.in && p.in.my || 0) > 0.1;
    var stride = walking ? 1 : 0.22;
    var bob = p.down ? 0 : Math.sin(t * 9 + p.id) * 1.1 * stride;
    var puff = p.down ? 1 : 1 + Math.sin(t * 18 + p.id) * 0.03 * stride;

    shadow(p.x, p.y + 1, 13 * puff, 5, 0.3);
    ctx.save();
    ctx.translate(p.x, p.y);
    if (p.down) { ctx.rotate(1.35); ctx.globalAlpha = 0.75; }
    ctx.scale((flip ? -1 : 1) * 1.3, 1.3 * (2 - puff));
    ctx.drawImage(img, -13, -30 + bob, 26, 30);
    ctx.restore();

    // muzzle flash + light spill, so every shot reads on screen
    if (!p.down && p.flash > 0) {
      var mx = p.x + Math.cos(p.aim) * 24, my = p.y - 17 + Math.sin(p.aim) * 15;
      var k = clamp(p.flash / 0.07, 0, 1);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      var g = ctx.createRadialGradient(mx, my, 0, mx, my, 26 * k);
      g.addColorStop(0, 'rgba(255,240,190,' + (0.85 * k) + ')');
      g.addColorStop(1, 'rgba(255,180,80,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(mx, my, 26 * k, 0, 6.2832); ctx.fill();
      ctx.restore();
    }

    // weapon nudge so aiming reads clearly
    if (!p.down) {
      ctx.save();
      ctx.translate(p.x + Math.cos(p.aim) * 13, p.y - 17 + Math.sin(p.aim) * 8);
      ctx.rotate(p.aim);
      ctx.fillStyle = '#2b3340';
      ctx.fillRect(-2, -2.5, 15, 5);
      ctx.fillStyle = '#8fa3ab';
      ctx.fillRect(8, -1.5, 7, 3);
      ctx.restore();
    }

    // reload ring: the only thing between you and a very short life
    if (!p.down && p.rl > 0) {
      var rf = 1 - p.rl / SG.AMMO.reload;
      ctx.save();
      ctx.strokeStyle = 'rgba(255,212,121,.9)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y - 16, 19, -1.57, -1.57 + 6.2832 * rf);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,212,121,.9)';
      ctx.font = 'bold 9px Vazirmatn, Tahoma, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('پر کردن خشاب', p.x, p.y + 15);
      ctx.restore();
    }

    // tag
    ctx.font = '10px Vazirmatn, Tahoma, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = p.id === S.localId ? p.color : 'rgba(226,240,246,.8)';
    ctx.fillText(p.name, p.x, p.y - 44);
    if (p.hp < p.max || p.down) bar(p.x, p.y - 41, 30, p.hp / p.max, p.down ? '#ff5b6e' : p.hp / p.max > 0.5 ? '#8bff6a' : '#ffd479');

    if (p.gatherNode && p.gatherNode.alive) {
      var n = p.gatherNode;
      var f = n.hp / n.max;
      ctx.strokeStyle = 'rgba(139,255,106,.65)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(n.x, n.y - n.s * 0.9, 22, -1.57, -1.57 + 6.2832 * (1 - f));
      ctx.stroke();
    }
  }

  function drawAlien(a, t) {
    var ctx = RND.ctx;
    var def = ALIEN[a.type];
    var entry = PIX.ALIENS[def.spr];
    var pac = entry && entry.spr;
    if (!pac || !pac.img) return;
    var bob = Math.sin(t * 7 + a.id * 1.7) * 1.6;
    var flip = Math.cos(a.aim || 0) < 0;
    var sc = def.boss ? 1.7 : 1.2;
    var breathe = 1 + Math.sin(t * 5 + a.id) * 0.045;
    var lunge = a.swing > 0 ? a.swing * 14 : 0;
    shadow(a.x, a.y + 1, def.r * 0.9 * breathe, def.r * 0.36, 0.3);
    ctx.save();
    ctx.translate(a.x + Math.cos(a.aim || 0) * lunge, a.y + bob * 0.4 + Math.sin(a.aim || 0) * lunge * 0.6);
    ctx.rotate(Math.sin(t * 9 + a.id * 2.3) * 0.035);
    ctx.scale((flip ? -1 : 1) * sc, sc * breathe);
    ctx.drawImage(a.hit > 0 ? pac.flash : pac.img, -pac.img.width / 2, -pac.img.height + 2);
    ctx.restore();

    if (def.boss || a.hp < a.max) {
      bar(a.x, a.y - (def.boss ? 46 : 26), def.boss ? 56 : 24, a.hp / a.max, def.boss ? '#ff6b8a' : '#c48bff');
    }
    if (def.boss) {
      ctx.font = '10px Vazirmatn, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ff9db4';
      ctx.fillText('موجود مادر', a.x, a.y - 52);
    }
  }

  function drawBullets() {
    var ctx = RND.ctx, i, b;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (i = 0; i < S.bullets.length; i++) {
      b = S.bullets[i];
      ctx.strokeStyle = 'rgba(255,236,170,.95)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - b.vx * 0.016, b.y - b.vy * 0.016);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,220,.9)';
      ctx.fillRect(b.x - 1.5, b.y - 1.5, 3, 3);
    }
    for (i = 0; i < S.ebullets.length; i++) {
      b = S.ebullets[i];
      ctx.fillStyle = 'rgba(255,120,240,.9)';
      ctx.beginPath(); ctx.arc(b.x, b.y, 4.5, 0, 6.2832); ctx.fill();
      ctx.fillStyle = 'rgba(255,220,255,.9)';
      ctx.beginPath(); ctx.arc(b.x, b.y, 1.8, 0, 6.2832); ctx.fill();
    }
    ctx.restore();
  }

  function drawParts() {
    var ctx = RND.ctx, i, p;
    ctx.save();
    for (i = 0; i < S.parts.length; i++) {
      p = S.parts[i];
      ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
      ctx.fillStyle = p.col;
      ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
    ctx.restore();
  }

  function drawTexts() {
    var ctx = RND.ctx, i, t2;
    ctx.save();
    ctx.font = 'bold 12px Vazirmatn, Tahoma, sans-serif';
    ctx.textAlign = 'center';
    for (i = 0; i < S.texts.length; i++) {
      t2 = S.texts[i];
      ctx.globalAlpha = clamp(t2.life / t2.max, 0, 1);
      ctx.fillStyle = 'rgba(4,10,16,.55)';
      ctx.fillText(t2.txt, t2.x + 1, t2.y + 1);
      ctx.fillStyle = t2.col;
      ctx.fillText(t2.txt, t2.x, t2.y);
    }
    ctx.restore();
  }

  window.ACT = {
    shadow: shadow, bar: bar,
    drawPlayer: drawPlayer, drawAlien: drawAlien,
    drawBullets: drawBullets, drawParts: drawParts, drawTexts: drawTexts
  };
})();
