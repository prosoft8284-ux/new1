/* ============================================================
   BERMUDA SIEGE — SIMULATION (phase clock, survivors, harvesting,
   construction, damage bookkeeping, snapshot sync)
   ============================================================ */
window.SIM = (function () {
  'use strict';

  var S = SG.S, clamp = SG.clamp, GRID = SG.GRID, dist = SG.dist;
  var BUILD = SG.BUILD, ALIEN = SG.ALIEN;

  /* ---------------- phase clock ---------------- */
  function start() {
    if (S.started) return;
    S.started = true;
    S.phase = 'day';
    S.tLeft = SG.DAY_LEN;
    S.day = 1;
    S.nights = 0;
  }

  function tickPhase(dt) {
    var i;
    S.tLeft -= dt;

    // light follows the clock with a soft ramp so dusk/dawn feel gradual
    var target = S.phase === 'night' ? 0.9 : (S.tLeft < 14 ? 0.35 : 0);
    S.light += (target - S.light) * Math.min(1, dt * 0.55);

    // scheduled wave arrivals
    for (i = S.spawnQ.length - 1; i >= 0; i--) {
      var q = S.spawnQ[i];
      q.t -= dt;
      if (q.t <= 0) {
        spawnAlien(q.type, q.x, q.y);
        S.spawnQ.splice(i, 1);
      }
    }

    if (S.phase === 'night' && !S.spawnQ.length && !S.aliens.length && S.tLeft > 7) S.tLeft = 7;

    if (S.tLeft <= 0) {
      if (S.phase === 'day') startNight(); else startDay();
    }
  }

  function startNight() {
    S.nights++;
    S.phase = 'night';
    S.tLeft = SG.NIGHT_LEN;
    if (window.SFX) SFX.dusk && SFX.dusk();
    if (window.HUD) HUD.banner('شب ' + S.nights + ' — آن‌ها می‌آیند', 'آنچه ساخته‌اید حالا باید جواب بدهد.', '#ff8af0');
    buildWave(S.nights);
  }

  function startDay() {
    // whatever is still walking gets cooked by the sunrise
    for (var i = 0; i < S.aliens.length; i++) {
      var a = S.aliens[i];
      SG.part(a.x, a.y, '#ffcf7a', 10, 120, 0.7, 3);
      SG.popText(a.x, a.y - 20, 'سوخت', '#ffcf7a');
    }
    S.aliens.length = 0;
    S.spawnQ.length = 0;

    var bonus = { wood: 26, stone: 18, metal: 8 };
    S.res.wood += bonus.wood; S.res.stone += bonus.stone; S.res.metal += bonus.metal;
    SG.popText(S.core.x, S.core.y - 80, 'سپیده‌دم — منابع تازه', '#8bff6a');

    if (S.nights >= SG.WIN_NIGHTS) {
      S.over = true; S.win = true;
      if (window.HUD) HUD.banner('جزیره آزاد شد', 'سه شب دوام آوردید. برمودا دیگر مال آن‌ها نیست.', '#8bff6a');
      if (window.SFX) SFX.dawn && SFX.dawn();
      return;
    }

    S.day++;
    S.phase = 'day';
    S.tLeft = SG.DAY_LEN;

    // what you cut down stays down; the jungle only pushes up a little near camp
    SW.respawn();
    if (window.SFX) SFX.dawn && SFX.dawn();
    if (window.HUD) HUD.banner('روز ' + S.day, 'منابع جمع کنید، دیوارها را تعمیر کنید.', '#ffd479');
  }

  /* ---------------- waves ---------------- */
  function buildWave(night) {
    var portals = SW.portals();
    var mult = 1 + 0.42 * Math.max(0, S.players.length - 1);
    // night one is a crowd of weak bugs: lots of targets, little threat
    var count = Math.round((18 + night * 8) * mult);
    var i, t, type, roll, p;
    for (i = 0; i < count; i++) {
      p = portals[(Math.random() * portals.length) | 0];
      t = 1.5 + (i / count) * 16 + Math.random() * 2.2;
      roll = Math.random();
      if (night === 1) type = roll < 0.62 ? 'runner' : roll < 0.86 ? 'skitter' : 'warrior';
      else if (night === 2) type = roll < 0.40 ? 'runner' : roll < 0.56 ? 'skitter' : roll < 0.74 ? 'warrior' : roll < 0.88 ? 'neural' : 'bomber';
      else type = roll < 0.32 ? 'runner' : roll < 0.44 ? 'skitter' : roll < 0.62 ? 'warrior' : roll < 0.76 ? 'brute' : roll < 0.88 ? 'neural' : 'bomber';
      S.spawnQ.push({
        t: t, type: type,
        x: p.x + (Math.random() - 0.5) * 110,
        y: p.y + (Math.random() - 0.5) * 110
      });
    }
    if (night >= 2) {
      p = portals[0];
      for (i = 0; i < night; i++) {
        S.spawnQ.push({ t: 10 + i * 4, type: 'brute', x: p.x + (Math.random() - 0.5) * 90, y: p.y + (Math.random() - 0.5) * 90 });
      }
    }
    if (night >= SG.WIN_NIGHTS) {
      p = portals[0];
      S.spawnQ.push({ t: 16, type: 'mother', x: p.x, y: p.y });
    }
  }

  function spawnAlien(type, x, y) {
    var d = ALIEN[type];
    if (!d) return null;
    var scale = (1 + 0.34 * Math.max(0, S.players.length - 1)) * (1 + 0.1 * Math.max(0, S.nights - 1));
    if (S.nights <= 1) scale *= 0.66;      // night one: a lot of soft targets
    var a = {
      id: S.nextId++,
      type: type, x: x, y: y, tx: x, ty: y,
      hp: d.hp * scale, max: d.hp * scale,
      dmgMul: S.nights <= 1 ? 0.6 : S.nights === 2 ? 0.85 : 1,
      aim: 0, cd: Math.random() * 0.6, hit: 0, spin: Math.random() * 6.28,
      sp: d.spawner ? 5 : 0
    };
    S.aliens.push(a);
    SG.part(x, y, '#c48bff', 8, 110, 0.6, 3);
    return a;
  }

  /* ---------------- survivors ---------------- */
  function updPlayer(p, dt) {
    if (p.hit > 0) p.hit -= dt;
    if (p.flash > 0) p.flash -= dt;
    if (p.rl > 0) {
      p.rl -= dt;
      if (p.rl <= 0) { p.rl = 0; p.mag = p.magMax || SG.AMMO.max; }
    }
    var i = p.in || {};
    if (p.down) {
      p.rt -= dt;
      if (p.rt <= 0) {
        p.down = false;
        p.hp = p.max * 0.7;
        p.x = S.core.x + (Math.random() - 0.5) * 90;
        p.y = S.core.y + 70;
        p.cd = 0.6;
        SG.part(p.x, p.y, p.color, 14, 130, 0.7, 3);
      }
      return;
    }

    var mx = i.mx || 0, my = i.my || 0;
    var m = Math.hypot(mx, my);
    if (m > 0.06) {
      if (m > 1) { mx /= m; my /= m; }
      var sp = 172;
      moveActor(p, mx * sp, my * sp, dt, 15, false);
    }
    if (typeof i.a === 'number') p.aim = i.a;

    p.cd -= dt;
    if (i.f && p.cd <= 0) shoot(p);
    if (i.g) gather(p, dt);
    if (i.r) repair(p, dt);
    if (i.b) { tryPlace(p, i.b[0], i.b[1], i.b[2]); i.b = null; }
  }

  function damagePlayer(p, dmg) {
    if (p.down) return;
    p.hp -= dmg;
    p.hit = 0.18;
    if (p.hp <= 0) {
      p.hp = 0;
      p.down = true;
      p.rt = 11;
      SG.part(p.x, p.y - 12, p.color, 16, 150, 0.9, 3);
      SG.popText(p.x, p.y - 34, 'زمین‌گیر شد', '#ff5b6e');
      if (window.SFX) SFX.kill && SFX.kill(p.x, p.y);
    }
  }

  /* ---------------- movement / collision ---------------- */
  function blockAt(x, y, rad) {
    for (var i = 0; i < S.buildings.length; i++) {
      var b = S.buildings[i];
      if (!BUILD[b.kind].block) continue;
      if (Math.abs(x - b.x) < 20 + rad && Math.abs(y - b.y) < 20 + rad) return b;
    }
    return null;
  }

  function moveActor(a, vx, vy, dt, rad, isAlien) {
    var nx = a.x + vx * dt, ny = a.y + vy * dt;
    if (SW.walkable(nx, a.y) && !blockAt(nx, a.y, rad)) a.x = nx;
    else if (isAlien) a.wall = blockAt(nx, a.y, rad) || a.wall;
    if (SW.walkable(a.x, ny) && !blockAt(a.x, ny, rad)) a.y = ny;
    else if (isAlien) a.wall = blockAt(a.x, ny, rad) || a.wall;

    // the core itself is solid
    var d = dist(a.x, a.y, S.core.x, S.core.y);
    if (d < S.core.r + rad * 0.6) {
      var ang = Math.atan2(a.y - S.core.y, a.x - S.core.x);
      a.x = S.core.x + Math.cos(ang) * (S.core.r + rad * 0.6);
      a.y = S.core.y + Math.sin(ang) * (S.core.r + rad * 0.6);
    }
  }

  /* ---------------- weapons ---------------- */
  function shoot(p) {
    if (p.rl > 0) return;
    if (p.mag === undefined) { p.mag = SG.AMMO.max; p.magMax = SG.AMMO.max; }
    if (p.mag <= 0) { p.rl = SG.AMMO.reload; return; }
    p.mag--;
    if (p.mag === 0) p.rl = SG.AMMO.reload;
    p.cd = 0.135;
    var ang = p.aim + (Math.random() - 0.5) * 0.045;
    var mx = p.x + Math.cos(ang) * 22, my = p.y - 16 + Math.sin(ang) * 22;
    S.bullets.push({
      x: mx, y: my,
      vx: Math.cos(ang) * 1080, vy: Math.sin(ang) * 1080,
      life: 0.62, dmg: 26, owner: p.id, hit: 0
    });
    SG.part(mx, my, '#ffe9a8', 2, 60, 0.18, 2);
    p.aim = ang;
    p.flash = 0.07;
    if (window.SFX) SFX.shot && SFX.shot('rifle');
  }

  /* ---------------- harvesting ---------------- */
  function nearestNode(p, radius) {
    var best = null, bd = radius;
    for (var i = 0; i < S.nodes.length; i++) {
      var n = S.nodes[i];
      if (!n.alive) continue;
      var d = dist(p.x, p.y, n.x, n.y) - n.r * 0.5;
      if (d < bd) { bd = d; best = n; }
    }
    return best;
  }

  function gather(p, dt) {
    if (p.gt === undefined) p.gt = 0;
    p.gt -= dt;
    var n = nearestNode(p, 108);
    if (!n) {
      p.gatherNode = null;
      return;
    }
    p.gatherNode = n;
    if (p.gt > 0) return;
    p.gt = 0.3;
    var dmg = 30;
    n.hp -= dmg;
    SG.part(n.x, n.y - n.s * 0.8, n.type === 'rock' ? '#cfcabc' : '#8bd77a', 5, 90, 0.45, 2.4);
    if (window.SFX) SFX.hit && SFX.hit(n.x, n.y);
    if (n.hp <= 0) {
      n.alive = false;
      n.hp = 0;
      var gain = n.type === 'rock' ? { stone: 9 } : n.type === 'tree' ? { wood: 11 } : { metal: 10 };
      for (var k in gain) S.res[k] = (S.res[k] || 0) + gain[k];
      SG.popText(n.x, n.y - 26, '+' + (gain.wood || gain.stone || gain.metal) + (gain.wood ? ' چوب' : gain.stone ? ' سنگ' : ' فلز'), gain.wood ? '#a8e0a0' : gain.stone ? '#dfe6ee' : '#9fd8ff');
      SG.part(n.x, n.y - 16, n.type === 'rock' ? '#cfcabc' : '#7fbf6a', 12, 120, 0.7, 3);
      if (window.SFX) SFX.pickup && SFX.pickup(n.type);
    }
  }

  function repair(p, dt) {
    if (p.rt2 === undefined) p.rt2 = 0;
    p.rt2 -= dt;
    var best = null, bd = 96;
    for (var i = 0; i < S.buildings.length; i++) {
      var b = S.buildings[i];
      if (b.hp >= b.max) continue;
      var d = dist(p.x, p.y, b.x, b.y);
      if (d < bd) { bd = d; best = b; }
    }
    if (!best || S.res.wood < 2) { p.repairB = best; return; }
    p.repairB = best;
    if (p.rt2 > 0) return;
    p.rt2 = 0.25;
    S.res.wood -= 2;
    best.hp = Math.min(best.max, best.hp + 55);
    SG.part(best.x, best.y - 10, '#8bff6a', 4, 60, 0.4, 2);
  }

  /* ---------------- construction ---------------- */
  function placeOk(kind, cx, cy) {
    var d = dist(cx, cy, S.core.x, S.core.y);
    if (d > SG.BASE_R || d < 58) return { ok: false, why: 'بیرون از محدودهٔ ساخت' };
    if (!SW.walkable(cx, cy)) return { ok: false, why: 'زمین ناهموار' };
    for (var i = 0; i < S.buildings.length; i++) {
      var b = S.buildings[i];
      if (Math.abs(b.x - cx) < GRID * 0.9 && Math.abs(b.y - cy) < GRID * 0.9) return { ok: false, why: 'آن‌جا پر است' };
    }
    var p = SG.me();
    for (var j = 0; j < S.players.length; j++) {
      var pl = S.players[j];
      if (Math.abs(pl.x - cx) < 30 && Math.abs(pl.y - cy) < 30) return { ok: false, why: 'روی بازیکن' };
    }
    var cost = BUILD[kind].cost;
    if (!SG.canAfford(cost)) return { ok: false, why: 'منبع کم است: ' + SG.affordText(cost) };
    return { ok: true };
  }

  function tryPlace(p, kind, cx, cy) {
    var def = BUILD[kind];
    if (!def) return;
    var chk = placeOk(kind, cx, cy);
    if (!chk.ok) {
      SG.popText(cx, cy - 20, chk.why, '#ff8080');
      if (window.SFX) SFX.hit && SFX.hit(cx, cy);
      return;
    }
    SG.pay(def.cost);
    S.buildings.push({
      id: S.nextId++, kind: kind, x: cx, y: cy,
      hp: def.hp, max: def.hp, cd: 0, aim: -Math.PI / 2, hit: 0, t: Math.random() * 6
    });
    SG.part(cx, cy, '#ffd479', 12, 110, 0.6, 3);
    SG.popText(cx, cy - 24, def.name + ' ساخته شد', '#8bff6a');
    if (window.SFX) SFX.pickup && SFX.pickup('build');
  }

  function hurtBuilding(b, dmg) {
    b.hp -= dmg;
    b.hit = 0.15;
    if (b.hp <= 0) {
      b.dead = true;
      SG.part(b.x, b.y, b.kind === 'stone' ? '#cfcabc' : '#c98b52', 16, 150, 0.8, 3);
      if (window.SFX) SFX.explosion && SFX.explosion(b.x, b.y, false);
    }
  }

  function damageCore(dmg) {
    if (S.over) return;
    S.core.hp = Math.max(0, S.core.hp - dmg);
    if (window.HUD) HUD.shake(6);
    if (S.core.hp <= 0 && !S.over) {
      S.over = true; S.win = false;
      if (window.SFX) SFX.explosion && SFX.explosion(S.core.x, S.core.y, true);
      if (window.HUD) HUD.banner('هسته سقوط کرد', 'شب ' + Math.max(1, S.nights) + ' — جزیره در دست آن‌ها ماند.', '#ff5b6e');
    }
  }

  /* ---------------- fx ---------------- */
  function updFx(dt) {
    var i, p;
    for (i = S.parts.length - 1; i >= 0; i--) {
      p = S.parts[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += p.g * dt;
      p.vx *= 0.96;
      if (p.life <= 0) S.parts.splice(i, 1);
    }
    for (i = S.texts.length - 1; i >= 0; i--) {
      p = S.texts[i];
      p.life -= dt;
      p.y -= 22 * dt;
      if (p.life <= 0) S.texts.splice(i, 1);
    }
    for (i = S.buildings.length - 1; i >= 0; i--) {
      if (S.buildings[i].dead) S.buildings.splice(i, 1);
      else if (S.buildings[i].hit > 0) S.buildings[i].hit -= dt;
    }
  }

  /* ---------------- main update ---------------- */
  function update(dt) {
    if (!S.ready || S.paused) return;
    S.time += dt;
    if (!S.started) return;
    if (S.over) { updFx(dt); return; }

    tickPhase(dt);

    // daylight is the only window for patching the hull back up
    if (S.phase === 'day' && S.core.hp < S.core.max) {
      S.core.hp = Math.min(S.core.max, S.core.hp + 4.5 * dt);
    }

    var i;
    for (i = 0; i < S.players.length; i++) updPlayer(S.players[i], dt);
    if (window.CMB) CMB.update(dt);
    updFx(dt);

    if (S.mode === 'host' && S.onSnap && S.time - S.lastSnap >= 0.1) {
      S.lastSnap = S.time;
      S.onSnap(snapshot());
    }
    if (S.mode === 'client' && S.onSend) {
      if (S.time - S.lastSnap >= 0.05) {
        S.lastSnap = S.time;
        var p = SG.me();
        S.onSend(p ? p.in : null);
      }
    }
  }

  /* ---------------- network payloads ---------------- */
  function snapshot() {
    var r = [];
    for (var i = 0; i < S.nodes.length; i++) {
      var n = S.nodes[i];
      if (!n.alive || n.hp < n.max) r.push([n.id, n.alive ? Math.round(n.hp) : 0]);
    }
    return {
      ph: S.phase === 'night' ? 'n' : 'd',
      tl: Math.round(S.tLeft),
      d: S.day, n: S.nights,
      lv: Math.round(S.light * 100) / 100,
      r: [Math.round(S.res.wood), Math.round(S.res.stone), Math.round(S.res.metal)],
      c: [Math.round(S.core.hp), S.core.max],
      k: S.kills,
      st: S.started ? 1 : 0,
      ov: S.over ? (S.win ? 2 : 1) : 0,
      p: S.players.map(function (p) {
        return [p.id, Math.round(p.x), Math.round(p.y), Math.round(p.aim * 100) / 100,
          Math.round(p.hp), p.max, p.down ? 1 : 0, p.name, p.skin, p.color, Math.round(p.hit * 100) / 100,
          p.mag === undefined ? SG.AMMO.max : p.mag, p.rl > 0 ? 1 : 0];
      }),
      a: S.aliens.map(function (a) {
        return [a.type, Math.round(a.x), Math.round(a.y), Math.round(a.hp), Math.round(a.max),
          Math.round(a.aim * 100) / 100, Math.round(a.hit * 100) / 100];
      }),
      b: S.buildings.map(function (b) {
        return [b.kind, b.x, b.y, Math.round(b.hp), b.max, Math.round(b.aim * 100) / 100];
      }),
      bl: S.bullets.map(function (b) { return [Math.round(b.x), Math.round(b.y)]; }),
      eb: S.ebullets.map(function (b) { return [Math.round(b.x), Math.round(b.y)]; }),
      nd: r
    };
  }

  function syncList(dst, src, mk) {
    while (dst.length > src.length) dst.pop();
    for (var i = 0; i < src.length; i++) {
      if (dst[i]) mk(dst[i], src[i], true);
      else dst[i] = mk({}, src[i], false);
    }
  }

  function applySnapshot(s) {
    if (!s) return;
    S.started = !!s.st;
    S.phase = s.ph === 'n' ? 'night' : 'day';
    S.tLeft = s.tl;
    S.day = s.d; S.nights = s.n;
    S.light = s.lv;
    S.res.wood = s.r[0]; S.res.stone = s.r[1]; S.res.metal = s.r[2];
    S.core.hp = s.c[0]; S.core.max = s.c[1];
    S.kills = s.k || 0;
    S.over = s.ov > 0;
    S.win = s.ov === 2;

    // players keep identity so aim/name never flicker
    var seen = {}, i, p;
    for (i = 0; i < s.p.length; i++) {
      var d = s.p[i];
      p = SG.playerById(d[0]);
      if (!p) {
        p = { id: d[0], name: d[7], skin: d[8], color: d[9], in: {}, cd: 0, kills: 0,
          mag: SG.AMMO.max, magMax: SG.AMMO.max, rl: 0 };
        p.x = d[1]; p.y = d[2];
        S.players.push(p);
      }
      p.tx = d[1]; p.ty = d[2];
      p.aim = d[3]; p.hp = d[4]; p.max = d[5]; p.down = !!d[6]; p.hit = d[10] || 0;
      p.mag = d[11] === undefined ? SG.AMMO.max : d[11];
      p.rl = d[12] ? 1 : 0;
      if (p.x === undefined) { p.x = d[1]; p.y = d[2]; }
      seen[d[0]] = 1;
    }
    for (i = S.players.length - 1; i >= 0; i--) if (!seen[S.players[i].id]) S.players.splice(i, 1);

    syncList(S.aliens, s.a, function (o, d, reuse) {
      o.type = d[0]; o.tx = d[1]; o.ty = d[2]; o.hp = d[3]; o.max = d[4];
      o.aim = d[5]; o.hit = d[6];
      if (!reuse) { o.x = d[1]; o.y = d[2]; }
      return o;
    });
    syncList(S.buildings, s.b, function (o, d, reuse) {
      o.kind = d[0]; o.tx = d[1]; o.ty = d[2]; o.hp = d[3]; o.max = d[4]; o.aim = d[5];
      o.x = d[1]; o.y = d[2];
      return o;
    });
    S.bullets = s.bl.map(function (d) { return { x: d[0], y: d[1] }; });
    S.ebullets = s.eb.map(function (d) { return { x: d[0], y: d[1] }; });

    if (s.nd && s.nd.length) {
      var map = {};
      for (i = 0; i < s.nd.length; i++) map[s.nd[i][0]] = s.nd[i][1];
      for (i = 0; i < S.nodes.length; i++) {
        var n = S.nodes[i];
        if (map[n.id] !== undefined) {
          n.hp = map[n.id];
          n.alive = n.hp > 0;
        } else if (n.hp !== n.max) { n.hp = n.max; n.alive = true; }
      }
    } else {
      for (i = 0; i < S.nodes.length; i++) if (S.nodes[i].hp !== S.nodes[i].max) { S.nodes[i].hp = S.nodes[i].max; S.nodes[i].alive = true; }
    }
  }

  /* client: only easing, the host owns the truth */
  function ease(dt) {
    var f = Math.min(1, dt * 11), i;
    for (i = 0; i < S.aliens.length; i++) {
      var a = S.aliens[i];
      if (a.tx !== undefined) { a.x += (a.tx - a.x) * f; a.y += (a.ty - a.y) * f; }
    }
    for (i = 0; i < S.players.length; i++) {
      var p = S.players[i];
      if (p.tx !== undefined) { p.x += (p.tx - p.x) * f; p.y += (p.ty - p.y) * f; }
    }
    SG.S.parts.length && (function () {
      for (var j = SG.S.parts.length - 1; j >= 0; j--) {
        var q = SG.S.parts[j];
        q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.vy += q.g * dt;
        if (q.life <= 0) SG.S.parts.splice(j, 1);
      }
    })();
    for (i = SG.S.texts.length - 1; i >= 0; i--) {
      SG.S.texts[i].life -= dt; SG.S.texts[i].y -= 22 * dt;
      if (SG.S.texts[i].life <= 0) SG.S.texts.splice(i, 1);
    }
  }

  return {
    start: start, update: update, tickPhase: tickPhase,
    startNight: startNight, startDay: startDay, buildWave: buildWave, spawnAlien: spawnAlien,
    updPlayer: updPlayer, damagePlayer: damagePlayer, moveActor: moveActor,
    shoot: shoot, gather: gather, repair: repair,
    tryPlace: tryPlace, placeOk: placeOk, hurtBuilding: hurtBuilding, damageCore: damageCore,
    nearestNode: nearestNode, blockAt: blockAt,
    snapshot: snapshot, applySnapshot: applySnapshot, ease: ease, updFx: updFx
  };
})();
