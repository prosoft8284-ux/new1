/* ============================================================
   BERMUDA SIEGE — SHARED STATE / DEFINITIONS
   One island, one base, three nights. Everything the other modules
   need to agree on lives here so sim, render and net never drift.
   ============================================================ */
window.SG = (function () {
  'use strict';

  var DAY_LEN = 150;        // seconds of daylight (first day is longer)
  var NIGHT_LEN = 78;       // seconds of siege
  var WIN_NIGHTS = 3;
  var AMMO = { max: 24, reload: 1.65 };   // one magazine, never enough
  var GRID = 40;
  var BASE_R = 520;         // matches SW.baseR(); build radius

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function dist(ax, ay, bx, by) { return Math.hypot(ax - bx, ay - by); }
  function now() { return (window.performance && performance.now) ? performance.now() : Date.now(); }

  /* ---------------- buildable things ---------------- */
  var BUILD = {
    wall: {
      key: '1', name: 'دیوار چوبی', short: 'چوب', icon: '▩',
      cost: { wood: 15 }, hp: 420, block: true,
      desc: 'سپر سریع و ارزان؛ بیگانه‌ها را کند می‌کند.'
    },
    stone: {
      key: '2', name: 'دیوار سنگی', short: 'سنگ', icon: '▦',
      cost: { stone: 20 }, hp: 980, block: true,
      desc: 'سه برابر جان می‌گیرد؛ ستون خط دفاعی.'
    },
    spike: {
      key: '3', name: 'تلهٔ نیزه', short: 'نیزه', icon: '✳',
      cost: { wood: 10, metal: 4 }, hp: 300, block: false,
      desc: 'هر بیگانه‌ای که رد شود زخمی می‌شود.'
    },
    turret: {
      key: '4', name: 'برجک خودکار', short: 'برجک', icon: '⌖',
      cost: { metal: 32, stone: 16 }, hp: 520, block: true,
      desc: 'خودش هدف می‌گیرد و شلیک می‌کند.'
    },
    lamp: {
      key: '5', name: 'مشعل', short: 'مشعل', icon: '✦',
      cost: { wood: 8 }, hp: 140, block: false,
      desc: 'شب را پس می‌زند؛ اطرافش روشن می‌ماند.'
    }
  };
  var BUILD_ORDER = ['wall', 'stone', 'spike', 'turret', 'lamp'];

  /* ---------------- bestiary ---------------- */
  var ALIEN = {
    skitter: { hp: 22, speed: 152, dmg: 5, r: 9, atk: 0.45, spr: 'skitter', bounty: 1 },
    runner: { hp: 44, speed: 98, dmg: 9, r: 13, atk: 0.70, spr: 'runner', bounty: 1 },
    warrior: { hp: 135, speed: 54, dmg: 17, r: 16, atk: 0.85, spr: 'warrior', bounty: 2 },
    neural: {
      hp: 62, speed: 42, dmg: 12, r: 14, atk: 1.7, spr: 'neural',
      ranged: true, range: 330, bounty: 2
    },
    bomber: { hp: 52, speed: 74, dmg: 32, r: 13, atk: 0.5, spr: 'bomber', suicide: true, bounty: 1 },
    brute: {
      hp: 340, speed: 40, dmg: 30, r: 20, atk: 1.05, spr: 'brute',
      bounty: 4, siege: 1.9
    },
    mother: {
      hp: 1700, speed: 27, dmg: 40, r: 30, atk: 1.15, spr: 'mother',
      boss: true, bounty: 25, spawner: true
    }
  };

  var SKINS = ['wanderer', 'warrior', 'mutant', 'tech', 'ronin', 'drifter'];
  var COLORS = ['#64e0ff', '#ffd479', '#8bff6a', '#ff8af0', '#ff5b6e', '#c69bff'];

  /* ---------------- state ---------------- */
  var S = {
    ready: false,
    mode: 'solo',              // solo | host | client
    localId: 1,
    started: false,
    time: 0,
    phase: 'day',
    tLeft: DAY_LEN,
    day: 1,
    nights: 0,
    light: 0,
    res: { wood: 0, stone: 0, metal: 0 },
    core: { x: 0, y: 0, hp: 1, max: 1, r: 64 },
    players: [],
    aliens: [],
    buildings: [],
    bullets: [],
    ebullets: [],
    parts: [],
    texts: [],
    nodes: [],
    spawnQ: [],
    over: false,
    win: false,
    kills: 0,
    nextId: 1,
    lastSnap: 0,
    onSnap: null,              // host: called with a snapshot object
    onSend: null,              // client: called with an input packet
    paused: false,
    target: null               // hud/aim target for touch
  };

  /* ---------------- players ---------------- */
  function addPlayer(id, name, skinIdx) {
    var p = {
      id: id,
      name: (name || 'بازمانده').slice(0, 12),
      skin: SKINS[(skinIdx || 0) % SKINS.length],
      color: COLORS[(skinIdx || 0) % COLORS.length],
      x: S.core.x + (Math.random() - 0.5) * 120,
      y: S.core.y + 90 + (Math.random() - 0.5) * 60,
      aim: -Math.PI / 2,
      hp: 100, max: 100,
      down: false, rt: 0, cd: 0,
      kills: 0, hit: 0,
      mag: AMMO.max, magMax: AMMO.max, rl: 0,
      in: { mx: 0, my: 0, a: -Math.PI / 2, f: false, g: false, r: false, b: null }
    };
    S.players.push(p);
    return p;
  }

  function me() {
    for (var i = 0; i < S.players.length; i++) if (S.players[i].id === S.localId) return S.players[i];
    return S.players[0] || null;
  }

  function playerById(id) {
    for (var i = 0; i < S.players.length; i++) if (S.players[i].id === id) return S.players[i];
    return null;
  }

  /* ---------------- setup ---------------- */
  function reset(opts) {
    opts = opts || {};
    S.mode = opts.mode || 'solo';
    S.localId = opts.localId || 1;
    S.started = false;
    S.time = 0;
    S.phase = 'day';
    S.tLeft = DAY_LEN;
    S.day = 1;
    S.nights = 0;
    S.light = 0;
    S.res = { wood: 20, stone: 10, metal: 4 };
    S.players = [];
    S.aliens = [];
    S.buildings = [];
    S.bullets = [];
    S.ebullets = [];
    S.parts = [];
    S.texts = [];
    S.spawnQ = [];
    S.over = false;
    S.win = false;
    S.kills = 0;
    S.nextId = 1;
    S.paused = false;
    var c = SW.core();
    S.core.x = c.x;
    S.core.y = c.y;
    S.core.max = 1800 + 400 * Math.max(0, (opts.count || 1) - 1);
    S.core.hp = S.core.max;
    S.nodes = SW.nodes();
    for (var i = 0; i < S.nodes.length; i++) {
      S.nodes[i].hp = S.nodes[i].max;
      S.nodes[i].alive = true;
    }
  }

  /* ---------------- small utilities used everywhere ---------------- */
  function canAfford(cost) {
    for (var k in cost) if ((S.res[k] || 0) < cost[k]) return false;
    return true;
  }
  function pay(cost) {
    for (var k in cost) S.res[k] = (S.res[k] || 0) - cost[k];
  }
  function affordText(cost) {
    var out = [];
    for (var k in cost) out.push(cost[k] + ' ' + (k === 'wood' ? 'چوب' : k === 'stone' ? 'سنگ' : 'فلز'));
    return out.join(' + ');
  }
  function cellOf(v) { return Math.floor(v / GRID) * GRID + GRID / 2; }

  function part(x, y, col, n, spd, life, size) {
    n = n || 6;
    for (var i = 0; i < n; i++) {
      var a = Math.random() * 6.2832, v = (spd || 90) * (0.35 + Math.random());
      S.parts.push({
        x: x, y: y,
        vx: Math.cos(a) * v, vy: Math.sin(a) * v - 20,
        life: (life || 0.5) * (0.6 + Math.random() * 0.7),
        max: life || 0.5,
        col: col || '#ffd479',
        size: size || 2.5,
        g: 90
      });
    }
  }
  function popText(x, y, txt, col) {
    S.texts.push({ x: x, y: y, txt: txt, col: col || '#ffe9a8', life: 1.1, max: 1.1 });
  }

  return {
    DAY_LEN: DAY_LEN, NIGHT_LEN: NIGHT_LEN, WIN_NIGHTS: WIN_NIGHTS, AMMO: AMMO,
    GRID: GRID, BASE_R: BASE_R,
    BUILD: BUILD, BUILD_ORDER: BUILD_ORDER, ALIEN: ALIEN,
    SKINS: SKINS, COLORS: COLORS,
    S: S,
    clamp: clamp, lerp: lerp, dist: dist, now: now,
    addPlayer: addPlayer, me: me, playerById: playerById, reset: reset,
    canAfford: canAfford, pay: pay, affordText: affordText, cellOf: cellOf,
    part: part, popText: popText
  };
})();
