package com.bermuda.siege;

/* Runs the back fallback on the UI thread. Top-level class because the
   bundler used here (older R8) crashes on javac's nested-class output. */
public class UiBack implements Runnable {
    private final MainActivity act;

    public UiBack(MainActivity a) { act = a; }

    @Override
    public void run() { act.hostBackNow(); }
}
