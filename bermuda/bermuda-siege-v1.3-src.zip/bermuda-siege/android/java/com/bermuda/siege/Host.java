package com.bermuda.siege;

import android.webkit.JavascriptInterface;

/* JS bridge. A top-level class on purpose: the bundler used here (older R8)
   crashes on javac's nested-class output, so no inner/anonymous classes. */
public class Host {
    private final MainActivity act;

    public Host(MainActivity a) { act = a; }

    @JavascriptInterface
    public void back() { act.onHostBack(); }
}
