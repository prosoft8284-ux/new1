/* ============================================================
   BERMUDA SIEGE — LAN SERVER
   Zero dependencies: static files + a hand-rolled WebSocket relay.
   The host client runs the simulation; this box only forwards packets.
       node server/server.js [port]
   ============================================================ */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = parseInt(process.argv[2] || process.env.PORT || '8080', 10);
const ROOT = path.resolve(__dirname, '..');
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon'
};

/* ---------------- static files ---------------- */
const server = http.createServer((req, res) => {
  let url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/') url = '/index.html';
  const file = path.join(ROOT, path.normalize(url).replace(/^([\\/])+/, ''));
  if (!file.startsWith(ROOT)) { res.writeHead(403).end('forbidden'); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('not found'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    res.end(data);
  });
});

/* ---------------- websocket plumbing ---------------- */
let nextId = 1000;
const rooms = new Map();      // code -> { clients:Set, hostId }

function encode(str) {
  const b = Buffer.from(str);
  const len = b.length;
  let head;
  if (len < 126) { head = Buffer.alloc(2); head[1] = len; }
  else if (len < 65536) { head = Buffer.alloc(4); head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
  head[0] = 0x81;
  return Buffer.concat([head, b]);
}

function send(ws, obj) {
  if (!ws || ws.destroyed || !ws.readable) return;
  try { ws.write(encode(JSON.stringify(obj))); } catch (e) { /* peer gone */ }
}

function roomOf(ws) { return ws.room ? rooms.get(ws.room) : null; }

function roster(room) {
  const out = [];
  room.clients.forEach((c) => {
    if (c.joined) out.push({ id: c.uid, name: c.name, skin: c.skin, host: c.uid === room.hostId });
  });
  return out;
}

function broadcastRoom(code, exceptWs) {
  const room = rooms.get(code);
  if (!room) return;
  const msg = { t: 'room', room: code, players: roster(room) };
  room.clients.forEach((c) => { if (c !== exceptWs) send(c, msg); });
  if (exceptWs) send(exceptWs, msg);
}

function joinRoom(ws, msg) {
  const code = String(msg.room || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'MAIN';
  let room = rooms.get(code);
  if (!room) { room = { code, clients: new Set(), hostId: 0 }; rooms.set(code, room); }

  if (room.clients.size >= 8) { send(ws, { t: 'err', msg: 'اتاق پر است' }); return; }

  ws.room = code;
  ws.joined = true;
  ws.name = String(msg.name || 'بازمانده').slice(0, 12);
  ws.skin = Number(msg.skin) || 0;
  room.clients.add(ws);
  if (!room.hostId) room.hostId = ws.uid;

  send(ws, { t: 'hello', id: ws.uid, room: code, host: ws.uid === room.hostId, count: room.clients.size });
  broadcastRoom(code, ws);
  console.log(`[room ${code}] +${ws.name}#${ws.uid} (${room.clients.size}) host=${room.hostId}`);
}

function leave(ws) {
  const room = roomOf(ws);
  if (!room) return;
  room.clients.delete(ws);
  if (room.hostId === ws.uid && room.clients.size) {
    room.hostId = room.clients.values().next().value.uid;
    room.clients.forEach((c) => send(c, { t: 'hello', id: c.uid, room: room.code, host: c.uid === room.hostId, count: room.clients.size }));
  }
  if (!room.clients.size) rooms.delete(room.code);
  else broadcastRoom(room.code, null);
  console.log(`[room ${room.code}] -${ws.name || ''}#${ws.uid} (${room.clients.size})`);
  ws.room = null;
}

function relay(ws, msg) {
  const room = roomOf(ws);
  if (!room) return;
  if (msg.t === 'bc') {
    const out = { t: 'msg', from: ws.uid, d: msg.d };
    room.clients.forEach((c) => { if (c !== ws) send(c, out); });
  } else if (msg.t === 'to') {
    room.clients.forEach((c) => { if (c.uid === msg.to) send(c, { t: 'msg', from: ws.uid, d: msg.d }); });
  }
}

function handleFrame(ws, op, data) {
  if (op === 0x8) { try { ws.end(); } catch (e) {} return; }
  if (op === 0x9) { try { ws.write(Buffer.concat([Buffer.from([0x8a, data.length]), data])); } catch (e) {} return; }
  if (op !== 0x1) return;

  let msg;
  try { msg = JSON.parse(data.toString('utf8')); } catch (e) { return; }
  if (!msg || typeof msg.t !== 'string') return;

  if (msg.t === 'join') joinRoom(ws, msg);
  else if (msg.t === 'ping') send(ws, { t: 'pong' });
  else relay(ws, msg);
}

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\n' +
    'Connection: Upgrade\r\n' +
    'Sec-WebSocket-Accept: ' + accept + '\r\n\r\n'
  );
  socket.setNoDelay(true);
  socket.uid = nextId++;
  socket.joined = false;
  socket.alive = true;

  let buf = Buffer.alloc(0);
  socket.on('data', (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const b0 = buf[0], b1 = buf[1];
      const op = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let off = 2;
      if (len === 126) {
        if (buf.length < 4) return;
        len = buf.readUInt16BE(2); off = 4;
      } else if (len === 127) {
        if (buf.length < 10) return;
        len = buf.readUInt32BE(6); off = 10;
      }
      let mask = null;
      if (masked) {
        if (buf.length < off + 4) return;
        mask = buf.slice(off, off + 4);
        off += 4;
      }
      if (buf.length < off + len) return;
      const payload = Buffer.from(buf.slice(off, off + len));
      if (mask) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      buf = buf.slice(off + len);
      handleFrame(socket, op, payload);
    }
  });

  socket.on('close', () => leave(socket));
  socket.on('error', () => { try { socket.destroy(); } catch (e) {} leave(socket); });
});

/* keep idle phones from dropping the table */
setInterval(() => {
  rooms.forEach((room) => room.clients.forEach((c) => {
    if (!c.destroyed) { try { c.write(Buffer.from([0x89, 0x00])); } catch (e) {} }
  }));
}, 25000);

function lanAddresses() {
  const out = [];
  const nets = os.networkInterfaces();
  Object.keys(nets).forEach((name) => {
    (nets[name] || []).forEach((n) => {
      if (n.family === 'IPv4' && !n.internal) out.push(n.address);
    });
  });
  return out;
}

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  BERMUDA SIEGE — LAN server');
  console.log('  ----------------------------------------');
  console.log('  local :  http://localhost:' + PORT + '/');
  lanAddresses().forEach((ip) => {
    console.log('  lan   :  http://' + ip + ':' + PORT + '/');
  });
  console.log('  ----------------------------------------');
  console.log('  Open the lan address on every phone/PC on the same Wi-Fi.');
  console.log('');
});
