/* touch layout + input check on an emulated landscape phone */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const CHROME = process.env.CHROME || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const URL = process.argv[2] || 'http://127.0.0.1:8080/play.html?solo=1';
const PORT = 9614;
const W = 844, H = 390;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-first-run',
    '--disable-background-timer-throttling', `--window-size=${W},${H}`,
    `--remote-debugging-port=${PORT}`, 'about:blank'], { stdio: 'ignore' });

  let tab = null;
  for (let i = 0; i < 40 && !tab; i++) {
    await sleep(250);
    try { tab = await (await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(URL)}`, { method: 'PUT' })).json(); } catch (e) {}
  }
  const ws = new WebSocket(tab.webSocketDebuggerUrl);
  let id = 0; const pend = new Map(); const logs = [];
  const send = (m, p) => new Promise((res) => { const i = ++id; pend.set(i, res); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { pend.get(m.id)(m.result); pend.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') logs.push('EXC ' + ((m.params.exceptionDetails.exception || {}).description || ''));
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') logs.push('ERR ' + m.params.args.map((a) => a.value !== undefined ? a.value : a.description).join(' '));
  };
  await new Promise((r) => { ws.onopen = r; });
  await send('Runtime.enable');
  await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 2, mobile: true });
  await send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
  await send('Page.reload', { ignoreCache: true });
  await sleep(9000);

  const ev = async (e) => {
    const r = await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) return 'EXC ' + ((r.exceptionDetails.exception || {}).description || '');
    return r.result && r.result.value;
  };

  // touch the canvas and drag: player must move
  const before = await ev('JSON.stringify({x:Math.round(SG.me().x),y:Math.round(SG.me().y),ammo:SG.me().mag})');
  const t0 = { x: 150, y: 300 };
  await send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: t0.x, y: t0.y, id: 1 }] });
  for (let i = 1; i <= 6; i++) {
    await send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: t0.x + i * 12, y: t0.y, id: 1 }] });
    await sleep(60);
  }
  const during = await ev('JSON.stringify({x:Math.round(SG.me().x),y:Math.round(SG.me().y),stickOn:document.getElementById("stickMove").classList.contains("on"),knob:document.querySelector("#stickMove i").style.transform})');
  await send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await sleep(200);

  // fire button
  const fireRect = await ev('(function(){var b=document.getElementById("btnFire").getBoundingClientRect();return JSON.stringify({x:b.left+b.width/2,y:b.top+b.height/2,w:b.width,v:getComputedStyle(document.getElementById("btnFire")).display});})()');
  const fr = JSON.parse(fireRect);
  const ammoBefore = await ev('SG.me().mag');
  await send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: fr.x, y: fr.y, id: 2 }] });
  await sleep(420);
  await send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  const ammoAfter = await ev('SG.me().mag');

  const layout = await ev(`(function(){var o={};['stickMove','stickAim','btnFire','btnGather','btnRepair','bar'].forEach(function(i){
    var e=document.getElementById(i); if(!e){o[i]='missing';return;} var b=e.getBoundingClientRect();
    o[i]=[Math.round(b.left),Math.round(b.top),Math.round(b.right),Math.round(b.bottom)];});
    o.touchMode=document.body.classList.contains('touch');
    o.view=[innerWidth,innerHeight];
    o.selectable=getComputedStyle(document.body).userSelect;
    return JSON.stringify(o);})()`);

  await sleep(300);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  const out = path.join(__dirname, '..', 'shots', 'touch.png');
  fs.writeFileSync(out, Buffer.from(shot.data, 'base64'));

  const r = { before: JSON.parse(before), during: JSON.parse(during), fireBtn: fr, ammo: [ammoBefore, ammoAfter], layout: JSON.parse(layout) };
  console.log(JSON.stringify(r, null, 1));

  const checks = [];
  checks.push(['moved with left stick', r.before.x !== r.during.x || r.before.y !== r.during.y]);
  checks.push(['stick base lit while dragging', r.during.stickOn === true]);
  checks.push(['knob followed the drag', /translate/.test(r.during.knob || '') && !/0px, calc\(-50% \+ 0px\)/.test(r.during.knob || '')]);
  checks.push(['touch ui visible', r.layout.touchMode === true && r.fireBtn.v !== 'none']);
  checks.push(['fire button consumed ammo', r.ammo[1] < r.ammo[0]]);
  const inside = (b) => b && b[0] >= 0 && b[1] >= 0 && b[2] <= r.layout.view[0] && b[3] <= r.layout.view[1];
  checks.push(['all controls inside the screen', ['stickMove', 'stickAim', 'btnFire', 'btnGather', 'btnRepair', 'bar'].every((k) => inside(r.layout[k]))]);
  checks.push(['text not selectable', r.layout.selectable === 'none']);
  let bad = 0;
  checks.forEach(([n, ok]) => { if (!ok) bad++; console.log((ok ? 'ok   ' : 'FAIL ') + n); });
  if (logs.length) { console.log(logs.join('\n')); bad++; }
  else console.log('no page errors');
  console.log(bad ? 'TOUCH FAILED' : 'all touch checks passed');
  chrome.kill();
  process.exit(bad ? 1 : 0);
})();
