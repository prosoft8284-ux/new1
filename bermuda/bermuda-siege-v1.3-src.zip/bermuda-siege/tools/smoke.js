/* Headless smoke test for Bermuda Siege (drives Chrome over CDP, no deps).
   node tools/smoke.js "http://127.0.0.1:8080/play.html?solo=1" */
'use strict';
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const CHROME = process.env.CHROME ||
  'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9337 + Math.floor(Math.random() * 40);
const url = process.argv[2] || 'http://127.0.0.1:8080/play.html?solo=1';
const outDir = process.argv[3] || path.resolve(__dirname, '../shots');
const pre = process.argv[4] || 'shot';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function json(u, opts) {
  const r = await fetch(u, opts);
  return r.json();
}

(async () => {
  fs.mkdirSync(outDir, { recursive: true });
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-features=Translate', '--window-size=1000,560',
    `--remote-debugging-port=${PORT}`, 'about:blank'
  ], { stdio: 'ignore' });

  let target = null;
  for (let i = 0; i < 40 && !target; i++) {
    await sleep(250);
    try {
      target = await json(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(url)}`,
        { method: 'PUT' });
    } catch (e) { /* not up yet */ }
  }
  if (!target) { console.error('chrome did not start'); chrome.kill(); process.exit(2); }

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();
  const logs = [];

  const send = (method, params) => new Promise((resolve) => {
    const mid = ++id;
    pending.set(mid, resolve);
    ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
  });

  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails;
      logs.push('EXC ' + (d.exception && d.exception.description || d.text));
    }
    if (m.method === 'Runtime.consoleAPICalled') {
      logs.push('LOG ' + m.params.type + ' ' +
        m.params.args.map((a) => a.value !== undefined ? a.value : a.description).join(' '));
    }
    if (m.method === 'Log.entryAdded') {
      const e = m.params.entry;
      if (e.level === 'error') logs.push('ERR ' + e.text + ' @' + (e.url || ''));
    }
  };

  await new Promise((r) => { ws.onopen = r; });
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Page.enable');
  await sleep(5000);

  const evalJs = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r && r.exceptionDetails) return 'EXC: ' + (r.exceptionDetails.exception && r.exceptionDetails.exception.description);
    return r && r.result ? r.result.value : undefined;
  };

  const shot = async (name) => {
    const r = await send('Page.captureScreenshot', { format: 'png' });
    if (r && r.data) fs.writeFileSync(path.join(outDir, name + '.png'), Buffer.from(r.data, 'base64'));
  };

  await evalJs(`(function(){var p=SG.me(); if(p){RND.cam.x=p.x; RND.cam.y=p.y-20;} return 1;})()`);
  await sleep(900);
  await shot(pre + '-day');

  // fast-forward into the first night and let the wave land
  const report = await evalJs(`(function(){
    if (typeof SG === 'undefined') return 'no SG';
    var S = SG.S;
    var snap = {ready:S.ready, mode:S.mode, players:S.players.length, nodes:S.nodes.length, core:Math.round(S.core.hp)};
    S.tLeft = 1;
    for (var i=0;i<40;i++) SIM.update(0.05);
    snap.phase = S.phase;
    for (i=0;i<400;i++) SIM.update(0.05);   // 20s of siege
    snap.aliens = S.aliens.length;
    snap.spawnQ = S.spawnQ.length;
    snap.coreAfter = Math.round(S.core.hp);
    snap.buildings = S.buildings.length;
    snap.phase2 = S.phase;
    snap.light = Math.round(S.light*100)/100;
    return JSON.stringify(snap);
  })()`);
  console.log('STATE', report);

  // put a few things on the field so the screenshot shows defence
  await evalJs(`(function(){
    var S=SG.S, c=SW.core();
    S.res.wood=300; S.res.stone=300; S.res.metal=200;
    var kinds=['wall','wall','stone','spike','turret','lamp'];
    for (var i=0;i<kinds.length;i++){
      SIM.tryPlace(SG.me(), kinds[i], SG.cellOf(c.x-80+i*40), SG.cellOf(c.y-120));
    }
    for (var j=0;j<5;j++){
      var a=S.aliens[j];
      if(a){ a.x=c.x-160+j*70; a.y=c.y-40+ (j%2)*30; }
    }
    var p=SG.me(); p.x=c.x-100; p.y=c.y+70;
    RND.cam.x=p.x; RND.cam.y=p.y-20;
    for (var k=0;k<3;k++) SIM.update(0.05);
    return 'ok';
  })()`);
  await sleep(400);
  await shot(pre + '-night');

  /* ---- gameplay: gather, build a ring, survive 30s ---- */
  const play = await evalJs(`(function(){
    var S=SG.S, c=SW.core(), p=SG.me(), out={};
    S.res.wood=900; S.res.stone=900; S.res.metal=600;

    // gathering: stand next to the closest tree and harvest it
    var n=null, bd=1e9;
    for (var i=0;i<S.nodes.length;i++){ var q=S.nodes[i]; if(!q.alive) continue;
      var d=Math.hypot(q.x-c.x,q.y-c.y); if(d<bd){bd=d;n=q;} }
    var w0=S.res.wood, s0=S.res.stone, m0=S.res.metal;
    if(n){ p.x=n.x+40; p.y=n.y+40; for(i=0;i<40;i++) SIM.gather(p,0.3); }
    out.gathered = n ? (S.res.wood-w0)+(S.res.stone-s0)+(S.res.metal-m0) : -1;

    // building ring
    var placed=0;
    for (var a=0;a<12;a++){
      var an=a/12*6.2832, x=c.x+Math.cos(an)*146, y=c.y+Math.sin(an)*146;
      if(SIM.placeOk(a%4===0?'stone':'wall',x,y).ok){ SIM.tryPlace(p,a%4===0?'stone':'wall',x,y); placed++; }
    }
    for (a=0;a<4;a++){
      an=a/4*6.2832+0.78; x=c.x+Math.cos(an)*92; y=c.y+Math.sin(an)*92;
      if(SIM.placeOk('turret',x,y).ok){ SIM.tryPlace(p,'turret',x,y); placed++; }
    }
    out.placed=placed; out.builds=S.buildings.length;

    var k0=S.kills, core0=S.core.hp;
    for (i=0;i<600;i++) SIM.update(0.05);      // 30 seconds of night
    out.kills=S.kills-k0;
    out.coreLost=Math.round(core0-S.core.hp);
    out.buildsLeft=S.buildings.filter(function(b){return !b.dead;}).length;
    out.buildsBroken=S.buildings.filter(function(b){return b.dead;}).length;
    out.aliens=S.aliens.length;
    out.phase=S.phase;

    // dawn: no aliens, resources bonus, players back up
    S.tLeft=0.4; for(i=0;i<20;i++) SIM.update(0.05);
    out.phaseDay=S.phase; out.aliensDay=S.aliens.length; out.nights=S.nights;
    p.x=c.x; p.y=c.y+96; RND.cam.x=c.x; RND.cam.y=c.y+40;
    for(i=0;i<2;i++) SIM.update(0.05);
    return JSON.stringify(out);
  })()`);
  console.log('PLAY', play);
  await sleep(500);
  await shot(pre + '-built');

  /* ---- win condition: surviving the third dawn ---- */
  const win = await evalJs(`(function(){
    var S=SG.S;
    S.over=false; S.win=false; S.nights=3; S.phase='night'; S.tLeft=0.3;
    for (var i=0;i<12;i++) SIM.update(0.05);
    return JSON.stringify({phase:S.phase, nights:S.nights, over:!!S.over, win:!!S.win});
  })()`);
  console.log('WIN', win);
  await sleep(900);
  await shot(pre + '-win');

  /* ---- lose condition: the core falls ---- */
  const lose = await evalJs(`(function(){
    var S=SG.S; S.over=false; S.win=false; S.phase='night'; S.tLeft=40;
    SIM.damageCore(99999);
    for (var i=0;i<6;i++) SIM.update(0.05);
    return JSON.stringify({over:!!S.over, win:!!S.win, hp:Math.round(S.core.hp)});
  })()`);
  console.log('LOSE', lose);
  await sleep(700);
  await shot(pre + '-lose');

  console.log(logs.length ? logs.join('\n') : 'no console errors');
  chrome.kill();
  process.exit(0);
})();
