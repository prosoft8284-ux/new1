/* Relay test for the LAN server: two clients, host election, broadcast, direct, re-election.
   node tools/net-test.js [ws://127.0.0.1:8080] */
'use strict';
const base = process.argv[2] || 'ws://127.0.0.1:8080';
const room = 'T' + Math.floor(Math.random() * 900 + 100);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fail = [];
const ok = (c, m) => { console.log((c ? 'ok  ' : 'FAIL') + ' ' + m); if (!c) fail.push(m); };

function client(name) {
  const ws = new WebSocket(base);
  const c = { name, ws, got: [], hello: null };
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === 'hello') c.hello = m;
    c.got.push(m);
  };
  return new Promise((res) => { ws.onopen = () => res(c); });
}
const send = (c, o) => c.ws.send(JSON.stringify(o));

(async () => {
  const a = await client('A');
  send(a, { t: 'join', room, name: 'میزبان', skin: 0 });
  await sleep(300);
  ok(a.hello && a.hello.host === true, 'first joiner becomes host');

  const b = await client('B');
  send(b, { t: 'join', room, name: 'یار', skin: 2 });
  await sleep(400);
  ok(b.hello && b.hello.host === false, 'second joiner is a client');
  ok(b.hello && b.hello.count === 2, 'room count is 2');
  const roster = a.got.filter((m) => m.t === 'room').pop();
  ok(!!roster && roster.players.length === 2, 'host receives the updated roster');
  ok(!!roster && roster.players.filter((p) => p.host).length === 1, 'roster has exactly one host');

  a.got.length = 0; b.got.length = 0;
  send(a, { t: 'bc', d: { k: 'snap', v: 1 } });
  await sleep(300);
  const relayed = b.got.find((m) => m.t === 'msg' && m.d && m.d.k === 'snap');
  ok(!!relayed, 'broadcast reaches the peer');
  ok(!!relayed && relayed.from === a.hello.id, 'broadcast carries the sender id');
  ok(!a.got.some((m) => m.t === 'msg'), 'broadcast is not echoed to the sender');

  b.got.length = 0; a.got.length = 0;
  send(b, { t: 'to', to: a.hello.id, d: { k: 'in', mx: 1, my: 0 } });
  await sleep(300);
  ok(a.got.some((m) => m.t === 'msg' && m.d && m.d.k === 'in'), 'direct message reaches the host');

  // host drops -> the remaining player takes over
  b.got.length = 0;
  a.ws.close();
  await sleep(600);
  ok(b.got.some((m) => m.t === 'hello' && m.host === true), 'host election hands over when the host leaves');

  b.ws.close();
  await sleep(200);
  console.log(fail.length ? '\n' + fail.length + ' FAILED' : '\nall relay checks passed');
  process.exit(fail.length ? 1 : 0);
})();
