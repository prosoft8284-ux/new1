import os
import sys
import zipfile

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ver = sys.argv[1] if len(sys.argv) > 1 else "1.1"
out = os.path.join(root, "dist", "bermuda-siege-v%s-src.zip" % ver)
skip = {"shots", "dist", "assets", ".build", "node_modules", ".git",
        ".agents", ".claude", ".codegraph"}

files = []
for d, dirs, fs in os.walk(root):
    dirs[:] = [x for x in dirs if x not in skip]
    for f in fs:
        full = os.path.join(d, f)
        rel = os.path.relpath(full, root).replace(os.sep, "/")
        if rel.startswith("dist/") or rel.startswith("shots/"):
            continue
        if rel.endswith(".apk") or rel.endswith(".zip") or rel.startswith("probe."):
            continue
        files.append(rel)

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in files:
        z.write(os.path.join(root, rel), "bermuda-siege/" + rel)

print(out, len(files), "files", round(os.path.getsize(out) / 1024), "KB")
