/* Two-tab LAN test: one host tab, one client tab, over the real server.
   node tools/two-tab.js [http://127.0.0.1:8080] */
'use strict';
const { spawn } = require('child_process');
const CHROME = process.env.CHROME || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const base = process.argv[2] || 'http://127.0.0.1:8080';
const PORT = 9500 + Math.floor(Math.random() * 40);
const room = 'Q' + ((Math.random() * 900 + 100) | 0);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fail = [];
const ok = (c, m) => { console.log((c ? 'ok  ' : 'FAIL') + ' ' + m); if (!c) fail.push(m); };

async function tab(url) {
  const t = await (await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(url)}`, { method: 'PUT' })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  let id = 0; const pend = new Map(); const errs = [];
  const send = (method, params) => new Promise((res) => { const i = ++id; pend.set(i, res); ws.send(JSON.stringify({ id: i, method, params: params || {} })); });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { pend.get(m.id)(m.result); pend.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') errs.push((m.params.exceptionDetails.exception || {}).description || m.params.exceptionDetails.text);
  };
  await new Promise((r) => { ws.onopen = r; });
  await send('Runtime.enable');
  const ev = async (e) => {
    const r = await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true });
    if (r && r.exceptionDetails) return 'EXC ' + (r.exceptionDetails.exception || {}).description;
    return r && r.result ? r.result.value : undefined;
  };
  return { ev, errs, close: () => ws.close() };
}

(async () => {
  const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-first-run', '--window-size=1000,560',
    '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
    '--disable-backgrounding-occluded-windows',
    `--remote-debugging-port=${PORT}`, 'about:blank'], { stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { await sleep(250); try { await fetch(`http://127.0.0.1:${PORT}/json/version`); break; } catch (e) {} }

  const waitFor = async (t, expr, ms) => {
    const end = Date.now() + (ms || 30000);
    let v;
    while (Date.now() < end) {
      v = await t.ev(expr);
      if (v && v !== 'EXC' && !String(v).startsWith('EXC')) return v;
      await sleep(400);
    }
    return v;
  };

  const q = `play.html?mode=`;
  const host = await tab(`${base}/${q}host&room=${room}&name=میزبان&skin=0&srv=127.0.0.1:8080`);
  ok((await waitFor(host, 'SG.S.ready ? "1" : ""', 60000)) === '1', 'host finished baking the island');
  ok((await waitFor(host, '(SG.S.mode === "host") ? "host" : ""')) === 'host', 'host tab runs the simulation');
  await host.ev('(function(){SIM.start(); return SG.S.started})()');
  // headless background tabs do not paint, so pump the host clock by hand
  await host.ev(`(function(){ if (window.__pump) return 1;
    window.__pump = setInterval(function(){ try { SIM.update(1/30); } catch(e){} }, 33); return 1; })()`);

  const cli = await tab(`${base}/${q}client&room=${room}&name=یار&skin=2&srv=127.0.0.1:8080`);
  ok((await waitFor(cli, 'SG.S.ready ? "1" : ""', 60000)) === '1', 'client finished baking the island');
  ok((await waitFor(cli, '(SG.S.mode === "client") ? "client" : ""')) === 'client', 'client tab joins as client');
  ok((await waitFor(host, 'SG.S.players.length === 2 ? "2" : ""')) === '2', 'host sees two survivors');

  const hCore = await host.ev('Math.round(SG.S.core.hp)');
  await sleep(1500);
  await waitFor(cli, 'SG.S.started ? "1" : ""', 15000);
  const cSeen = await cli.ev('JSON.stringify({core:Math.round(SG.S.core.hp),players:SG.S.players.length,started:SG.S.time>0})');
  const seen = JSON.parse(cSeen);
  ok(seen.players === 2, 'client receives the roster in snapshots ' + cSeen);
  const t1 = await cli.ev('Math.round(SG.S.tLeft)');
  await sleep(1200);
  const t2 = await cli.ev('Math.round(SG.S.tLeft)');
  ok(t2 !== t1, 'phase clock ticks on the client (' + t1 + ' -> ' + t2 + ')');

  // client input must reach the host: walk right for a moment
  const bx = await cli.ev('Math.round(SG.me().x)');
  await cli.ev(`(function(){SG.me().in.mx=1; SG.me().in.my=0; return 1;})()`);
  await sleep(1200);
  const moved = await host.ev('JSON.stringify(SG.S.players.map(function(p){return Math.round(p.x)}))');
  await cli.ev(`(function(){SG.me().in.mx=0; SG.me().in.my=0; return 1;})()`);
  ok(moved !== null && bx !== undefined, 'client sends input to the host (' + bx + ' -> ' + moved + ')');
  ok(!JSON.parse(moved).every((x) => x === bx), 'host actually moved the client survivor');

  const errs = host.errs.concat(cli.errs);
  ok(errs.length === 0, 'no runtime exceptions in either tab' + (errs.length ? ': ' + errs[0] : ''));

  host.close(); cli.close(); chrome.kill();
  console.log(fail.length ? '\n' + fail.length + ' FAILED' : '\nall two-tab checks passed');
  process.exit(fail.length ? 1 : 0);
})();
