/* AI Director test — checks the Left 4 Dead-ish pacing, the specials and the
   grab/rescue loop. Pure in-page simulation, no rendering.
   node tools/director-test.js "http://127.0.0.1:8080/play.html?solo=1" */
'use strict';
const { spawn } = require('child_process');

const CHROME = process.env.CHROME ||
  'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9400 + Math.floor(Math.random() * 40);
const url = process.argv[2] || 'http://127.0.0.1:8080/play.html?solo=1';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const json = async (u, opts) => (await fetch(u, opts)).json();

(async () => {
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-features=Translate', '--window-size=900,520',
    `--remote-debugging-port=${PORT}`, 'about:blank'
  ], { stdio: 'ignore' });

  let target = null;
  for (let i = 0; i < 40 && !target; i++) {
    await sleep(250);
    try {
      target = await json(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(url)}`, { method: 'PUT' });
    } catch (e) { /* not up yet */ }
  }
  if (!target) { console.error('chrome did not start'); chrome.kill(); process.exit(2); }

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();
  const logs = [];
  const send = (method, params) => new Promise((resolve) => {
    const mid = ++id;
    pending.set(mid, resolve);
    ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
  });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails;
      logs.push('EXC ' + ((d.exception && d.exception.description) || d.text));
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      logs.push('ERR ' + m.params.entry.text);
    }
  };
  await new Promise((r) => { ws.onopen = r; });
  await send('Runtime.enable');
  await send('Log.enable');
  await send('Page.enable');
  await sleep(4000);

  const evalJs = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r && r.exceptionDetails) return 'EXC: ' + ((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text);
    return r && r.result ? r.result.value : undefined;
  };

  /* 1) a full night of director pacing: moods, peak count, specials, calm gaps */
  const pace = await evalJs(`(function(){
    var S = SG.S;
    SIM.start();
    S.players[0].hp = S.players[0].max;
    S.aliens.length = 0; S.spawnQ.length = 0;
    // keep the survivor alive and fighting so the director sees a normal team
    var origDmg = SIM.damagePlayer;
    SIM.damagePlayer = function(p, d){ p.hp = Math.max(p.max * 0.55, p.hp - d * 0.05); };
    SIM.damageCore = function(){};
    SIM.startNight();
    var moods = {}, peaks = 0, last = S.dir.mood, gaps = [], gapStart = 0,
        maxAlive = 0, specials = {}, pinSeen = false, pinFreed = false, pinHp = 0,
        t = 0, step = 1/45;
    var held = null;
    while (t < 70) {
      SIM.update(step);
      t += step;
      if (S.dir.mood !== last) {
        moods[S.dir.mood] = (moods[S.dir.mood] || 0) + 1;
        if (S.dir.mood === 'peak') { peaks++; if (gapStart) { gaps.push(+(t - gapStart).toFixed(1)); gapStart = 0; } }
        if (S.dir.mood !== 'peak' && gapStart === 0) gapStart = t;
        last = S.dir.mood;
      }
      maxAlive = Math.max(maxAlive, S.aliens.length);
      for (var i = 0; i < S.aliens.length; i++) {
        specials[S.aliens[i].type] = 1;
        // the survivor shoots back, otherwise one special parks on the map all night
        if (S.aliens[i].type === 'grabber' || S.aliens[i].type === 'screamer') S.aliens[i].hp -= 60 * step;
      }
      var me = S.players[0];
      if (me.pin && !pinSeen) { pinSeen = true; pinHp = me.hp; }
      if (pinSeen && !me.pin) pinFreed = true;
      if (me.down) { me.down = false; me.hp = me.max; }
      if (me.hp < me.max * 0.3) me.hp = me.max;
    }
    SIM.damagePlayer = origDmg;
    return { peaks: peaks, moods: moods, gaps: gaps, maxAlive: maxAlive,
             specials: Object.keys(specials), pinSeen: pinSeen, pinFreed: pinFreed,
             pinHp: +pinHp.toFixed(0), reliefs: S.dir.reliefs, stress: +S.dir.stress.toFixed(2),
             metal: S.res.metal };
  })()`);

  /* 2) grabber pin, teammate pry with R, and release when the grabber dies */
  const pin = await evalJs(`(function(){
    var S = SG.S;
    S.phase = 'night'; S.over = false; S.tLeft = 60;
    S.aliens.length = 0; S.spawnQ.length = 0;
    var me = S.players[0], mate = SG.addPlayer('mate1', 'هم‌تیمی', 1);
    mate.hp = mate.max;
    var g = SIM.spawnAlien('grabber', me.x + 10, me.y);
    var t = 0, step = 1/60, grabbed = false, freed = false, grabT = 0;
    while (t < 8) {
      // keep the mate 40px away holding R only once the grab happens
      mate.x = me.x + 38; mate.y = me.y + 6;
      mate.in = { r: grabbed };
      SIM.update(step);
      t += step;
      if (me.pin && !grabbed) { grabbed = true; grabT = t; }
      if (grabbed && !me.pin) { freed = true; break; }
      if (me.hp < 2) break;
    }
    var byPry = { t: +t.toFixed(2), grabbed: grabbed, freed: freed,
                  grabT: +grabT.toFixed(2), hp: +me.hp.toFixed(0),
                  pin: !!me.pin, mateR: !!mate.in.r };
    // second grab, then kill the grabber instead of prying
    me.pin = 0; me.hp = me.max; mate.in = {};
    if (g && !g.dead) { g.hold = 0; g.x = me.x + 10; g.y = me.y; g.cd = 0; }
    t = 0; var grabbed2 = false, freedByKill = false;
    while (t < 8) {
      mate.x = me.x + 300; mate.y = me.y; mate.in = {};
      SIM.update(step);
      t += step;
      if (me.pin && !grabbed2) { grabbed2 = true; g.hp = 0; }
      if (grabbed2 && !me.pin) { freedByKill = true; break; }
    }
    return { byPry: byPry, grabbed2: grabbed2, freedByKill: freedByKill, alienAlive: !!g && !g.dead };
  })()`);

  /* 3) screamer summons a small horde */
  const scream = await evalJs(`(function(){
    var S = SG.S;
    S.aliens.length = 0; S.spawnQ.length = 0;
    var me = S.players[0];
    var s = SIM.spawnAlien('screamer', me.x + 220, me.y + 220);
    s.cd = 0;
    var before = S.aliens.length;
    for (var t = 0; t < 1.5; t += 1/60) SIM.update(1/60);
    var sk = 0;
    for (var i = 0; i < S.aliens.length; i++) if (S.aliens[i].type === 'skitter') sk++;
    return { before: before, after: S.aliens.length, skitter: sk, ring: +(s.scream || 0).toFixed(2) };
  })()`);

  /* 4) noise accelerates a horde */
  const noise = await evalJs(`(function(){
    var S = SG.S;
    S.aliens.length = 0; S.spawnQ.length = 0;
    S.dir.surge = 0; S.dir.cd = 20; S.dir.noise = 0;
    for (var i = 0; i < 40; i++) DIR.noise(0.03);
    var n = S.dir.noise;
    var start = S.dir.mood;
    for (var t = 0; t < 1; t += 1/60) SIM.update(1/60);
    return { noise: +n.toFixed(2), mood: S.dir.mood, surge: S.dir.surge > 0 };
  })()`);

  const ok = pace && !String(pace).startsWith('EXC') &&
    pace.peaks >= 2 && pace.gaps.length >= 1 && Math.min.apply(null, pace.gaps.concat([99])) >= 4 &&
    pace.specials.indexOf('grabber') >= 0 && pace.specials.indexOf('screamer') >= 0 &&
    pace.maxAlive <= 40 &&
    pin && pin.byPry.grabbed && pin.byPry.freed && pin.byPry.t - pin.byPry.grabT < 3 &&
    pin.grabbed2 && pin.freedByKill &&
    scream && scream.skitter >= 3 &&
    noise && noise.surge === true &&
    logs.length === 0;

  console.log('PACE ' + JSON.stringify(pace));
  console.log('PIN ' + JSON.stringify(pin));
  console.log('SCREAM ' + JSON.stringify(scream));
  console.log('NOISE ' + JSON.stringify(noise));
  console.log(logs.length ? logs.join('\n') : 'no console errors');
  console.log(ok ? 'DIRECTOR OK' : 'DIRECTOR FAIL');
  chrome.kill();
  process.exit(ok ? 0 : 1);
})();
