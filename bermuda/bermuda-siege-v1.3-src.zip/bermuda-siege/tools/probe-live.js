'use strict';
const { spawn } = require('child_process');
const CHROME = process.env.CHROME || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const PORT = 9400 + Math.floor(Math.random() * 30);
const url = process.argv[2];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-first-run',
    '--window-size=1000,560', `--remote-debugging-port=${PORT}`, 'about:blank'], { stdio: 'ignore' });
  let t = null;
  for (let i = 0; i < 40 && !t; i++) {
    await sleep(250);
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(url)}`, { method: 'PUT' });
      t = await r.json();
    } catch (e) {}
  }
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  let id = 0; const pend = new Map(); const logs = [];
  const send = (m, p) => new Promise((res) => { const i = ++id; pend.set(i, res); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { pend.get(m.id)(m.result); pend.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') logs.push('EXC ' + (m.params.exceptionDetails.exception || {}).description);
    if (m.method === 'Runtime.consoleAPICalled') logs.push('LOG ' + m.params.args.map(a => a.value !== undefined ? a.value : a.description).join(' '));
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') logs.push('ERR ' + m.params.entry.text + ' ' + (m.params.entry.url || ''));
  };
  await new Promise((r) => { ws.onopen = r; });
  await send('Runtime.enable'); await send('Log.enable'); await send('Page.enable');
  await sleep(6000);
  const ev = async (e) => (await send('Runtime.evaluate', { expression: e, returnByValue: true })).result;
  for (const q of ['location.href', 'document.readyState', 'document.title',
    'typeof SG', 'typeof BS', 'typeof SW', 'typeof SIM', 'typeof FRAME',
    'document.querySelectorAll("script").length',
    '(function(){try{return SG.S.ready}catch(e){return "err:"+e.message}})()']) {
    const r = await ev(q);
    console.log(q, '=>', JSON.stringify(r && r.value !== undefined ? r.value : r));
  }
  console.log(logs.join('\n') || '(no logs)');
  chrome.kill(); process.exit(0);
})();
