/* ============================================================
   BERMUDA SIEGE — AI DIRECTOR
   Left 4 Dead 2 thinking, ported to a siege: the game does not
   pour aliens at you on a fixed timer. It watches how the team is
   doing (health, core, ammo, how many are already down), then picks
   a mood — calm, build-up, peak, relief — and spends a limited
   "population budget" on bursts of pressure, with two special
   aliens that exist purely to punish a team that is too comfortable.
   ============================================================ */
window.DIR = (function () {
  'use strict';

  var S = SG.S;
  var clamp = SG.clamp;

  function alive() {
    var n = 0;
    for (var i = 0; i < S.aliens.length; i++) if (!S.aliens[i].dead) n++;
    return n;
  }

  function specialsAlive() {
    var n = 0;
    for (var i = 0; i < S.aliens.length; i++) {
      var a = S.aliens[i];
      if (!a.dead && (a.type === 'grabber' || a.type === 'screamer')) n++;
    }
    return n;
  }

  /* 0 = comfortable, 1 = the team is drowning */
  function stress(now) {
    var team = S.players, up = 0, hpSum = 0, total = 0, lowAmmo = 0;
    for (var i = 0; i < team.length; i++) {
      var p = team[i];
      total++;
      if (p.down) continue;
      up++;
      hpSum += p.hp / p.max;
      var mag = p.mag === undefined ? SG.AMMO.max : p.mag;
      if (mag <= 6) lowAmmo++;
    }
    var hpFrac = up ? hpSum / up : 0;
    var downFrac = total ? (total - up) / total : 0;
    var coreFrac = S.core.max ? S.core.hp / S.core.max : 1;
    // being pinned is exactly the moment the director should ease off
    var pinned = 0;
    for (i = 0; i < team.length; i++) if (team[i].pin) pinned++;
    var crowd = alive() / Math.max(6, S.dir.budget);

    var s = 0.34 * (1 - hpFrac) + 0.30 * (1 - coreFrac) +
      0.20 * downFrac + 0.10 * Math.min(1, pinned) +
      0.06 * Math.min(1, crowd) + 0.05 * (total ? lowAmmo / total : 0);
    return clamp(s, 0, 1);
  }

  function budget() {
    // how many aliens may exist at once: scales with the night and the team size
    var night = Math.max(1, S.nights);
    var b = 9 + night * 4 + Math.max(0, S.players.length - 1) * 4;
    return Math.min(34, Math.round(b));
  }

  function spawnAt(type) {
    var portals = SW.portals();
    if (!portals.length) return null;
    var p = portals[(Math.random() * portals.length) | 0];
    // pick the portal on the side the team is *not* looking at, like a director would
    var best = p, bestScore = -1;
    for (var i = 0; i < portals.length; i++) {
      var q = portals[i], score = 0;
      for (var k = 0; k < S.players.length; k++) {
        var pl = S.players[k];
        if (pl.down) continue;
        var d = SG.dist(q.x, q.y, pl.x, pl.y);
        var away = Math.abs(Math.atan2(q.y - pl.y, q.x - pl.x) - Math.PI / 2);
        score += d / 1200 + Math.min(1, Math.abs(Math.cos(away))) * 0.4;
      }
      if (score > bestScore) { bestScore = score; best = q; }
    }
    return SIM.spawnAlien(type, best.x + (Math.random() - 0.5) * 90, best.y + (Math.random() - 0.5) * 90);
  }

  function weakerType() {
    var r = Math.random();
    if (S.nights <= 1) return r < 0.62 ? 'runner' : r < 0.88 ? 'skitter' : 'warrior';
    if (S.nights === 2) return r < 0.38 ? 'runner' : r < 0.54 ? 'skitter' : r < 0.72 ? 'warrior' : r < 0.86 ? 'neural' : 'bomber';
    return r < 0.30 ? 'runner' : r < 0.42 ? 'skitter' : r < 0.60 ? 'warrior' : r < 0.72 ? 'brute' : r < 0.86 ? 'neural' : 'bomber';
  }

  function trickle(dt) {
    // during calm the island still breathes: a lone bug every few seconds
    S.dir.trickle = (S.dir.trickle || 0) + dt;
    if (S.dir.trickle > 2.6 && alive() < 4) {
      S.dir.trickle = 0;
      spawnAt(weakerType());
    }
  }

  function beginSurge() {
    var st = S.dir.stress;
    // the less pressure the team is under, the longer and heavier the peak
    S.dir.surge = clamp(4.6 + 5.4 * (1 - st), 4.2, 10.5);
    S.dir.peaks++;
    S.dir.noise = 0;
    if (window.HUD) HUD.toast(S.dir.surge > 8 ? 'هجوم سنگین — پشت دیوار بمانید' : 'موج نزدیک می‌شود', '#ff9de0');
  }

  function endSurge() {
    S.dir.surge = 0;
    // L4D2 always answers a peak with a breather, not with another peak
    S.dir.cd = 9 + 13 * S.dir.stress;
    S.dir.reliefs++;
    relief();
  }

  function relief() {
    var healed = 0;
    for (var i = 0; i < S.players.length; i++) {
      var p = S.players[i];
      if (p.down || p.hp >= p.max) continue;
      p.hp = Math.min(p.max, p.hp + 14);
      healed++;
    }
    S.res.metal += 4;
    if (healed && window.HUD) HUD.toast('نفس بکشید — کمی ترمیم و ۴ فلز', '#8bff6a');
    if (window.SFX && SFX.dawn && healed) SFX.dawn();
  }

  function update(dt) {
    var D = S.dir;
    if (S.phase !== 'night' || S.over) { D.mood = 'calm'; return; }
    D.stress = stress();
    D.budget = budget();

    if (D.surge > 0) {
      D.mood = 'peak';
      D.surge -= dt;
      // during a peak the budget is spent as fast as it refills
      D.spawnAcc = (D.spawnAcc || 0) + dt * (1.7 + 2.1 * (1 - D.stress));
      var guard = 0;
      while (D.spawnAcc >= 1 && guard++ < 4) {
        D.spawnAcc -= 1;
        if (alive() >= D.budget) continue;
        spawnAt(weakerType());
      }
      specialTick(dt);
      if (D.surge <= 0) endSurge();
      return;
    }

    // calm / build-up
    D.mood = D.stress > 0.6 ? 'relief' : D.stress > 0.34 ? 'build' : 'calm';
    D.cd -= dt * (D.stress > 0.55 ? 0.75 : 1);      // a struggling team gets longer calm

    // noise: harvesting, shooting and building are loud, and loud pulls a horde
    D.noise = Math.max(0, D.noise - dt * 0.55);
    if (D.noise >= 1) { D.noise = 0; beginSurge(); return; }

    if (D.cd < 6 && D.mood === 'calm') D.mood = 'build';   // the calm before the burst reads as a warning
    if (D.cd <= 0) { beginSurge(); return; }
    trickle(dt);
    specialTick(dt);
  }

  /* the two specials are a seasoning, not the meal: they arrive a few times a night */
  function specialTick(dt) {
    var D = S.dir;
    if (D.specialCd > 0) { D.specialCd -= dt; return; }
    var maxSpecials = 1 + (S.players.length >= 3 ? 1 : 0);
    if (D.stress >= 0.66 || specialsAlive() >= maxSpecials) return;
    // alternate the two roles so the team cannot settle into one habit;
    // a downed player pulls the grabber, a healthy team gets the screamer
    var down = 0;
    for (var i = 0; i < S.players.length; i++) if (S.players[i].down) down++;
    var want = D.lastSpecial === 'grabber' ? 'screamer' : 'grabber';
    if (down || D.stress > 0.4) want = 'grabber';
    if (specialsAlive() && want === 'grabber') want = 'screamer';
    if (spawnAt(want)) {
      D.lastSpecial = want;
      D.specialCd = 20 + Math.random() * 10;
      if (window.HUD) HUD.toast(want === 'grabber' ? 'چنگ‌زن آمد — تنها نرید' : 'جیغ‌کش آمد — اول او را بزنید', '#7be0ff');
    } else {
      D.specialCd = 2;
    }
  }

  /* something loud happened (a kill, a tree falling, a wall going up) */
  function noise(amount) {
    var D = S.dir;
    if (S.phase !== 'night' || D.surge > 0) return;
    D.noise += amount * (1.15 - D.stress * 0.5);
  }

  function beginNight() {
    var D = S.dir;
    D.surge = 0; D.cd = 5 + Math.random() * 2; D.specialCd = 7 + Math.random() * 4;
    D.lastSpecial = Math.random() < 0.5 ? 'grabber' : 'screamer';
    D.noise = 0; D.spawnAcc = 0; D.trickle = 0;
    D.budget = budget();
    D.mood = 'build';
  }

  function clear() {
    var D = S.dir;
    D.surge = 0; D.mood = 'calm'; D.noise = 0; D.cd = 13;
    D.specialCd = 12; D.spawnAcc = 0; D.trickle = 0;
  }

  return {
    update: update, noise: noise, beginNight: beginNight, clear: clear,
    beginSurge: beginSurge, stress: stress, alive: alive, specialsAlive: specialsAlive,
    get mood() { return S.dir.mood; }, get stressNow() { return S.dir.stress; }
  };
})();
