/* ============================================================
   BERMUDA SIEGE — RENDER CORE (camera, terrain, base, structures)
   ============================================================ */
window.RND = (function () {
  'use strict';

  var S = SG.S, BUILD = SG.BUILD, clamp = SG.clamp;
  var cam = { x: 0, y: 0, z: 1.4, w: 800, h: 450 };
  var cv = null, ctx = null;
  var shakeT = 0, shakeA = 0;

  function attach(canvas) {
    cv = canvas;
    ctx = cv.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
  }

  function resize() {
    if (!cv) return;
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    var w = cv.clientWidth || window.innerWidth;
    var h = cv.clientHeight || window.innerHeight;
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);
    cam.w = w; cam.h = h;
    cam.z = clamp(h / 430, 1.15, 2.3) * (w / h > 2 ? 1.05 : 1);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    RND.dpr = dpr;
  }

  function shake(a) { shakeA = Math.max(shakeA, a); shakeT = 0.35; }

  function updateCam(dt) {
    var p = SG.me();
    if (!p) return;
    var tx = p.x, ty = p.y - 20;
    cam.x += (tx - cam.x) * Math.min(1, dt * 7);
    cam.y += (ty - cam.y) * Math.min(1, dt * 7);
    var hw = cam.w / cam.z / 2, hh = cam.h / cam.z / 2;
    var W = SW.W(), H = SW.H();
    cam.x = clamp(cam.x, hw - 40, W - hw + 40);
    cam.y = clamp(cam.y, hh - 40, H - hh + 40);
    if (shakeT > 0) { shakeT -= dt; if (shakeT <= 0) shakeA = 0; }
  }

  function worldToScreen(x, y) {
    return { x: (x - cam.x) * cam.z + cam.w / 2, y: (y - cam.y) * cam.z + cam.h / 2 };
  }

  /* ---------------- base dressing ---------------- */
  function drawZone() {
    var c = SW.core();
    ctx.save();
    ctx.strokeStyle = 'rgba(120,235,255,.20)';
    ctx.lineWidth = 2;
    ctx.setLineDash([9, 11]);
    ctx.beginPath(); ctx.arc(c.x, c.y, SG.BASE_R, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = 'rgba(120,235,255,.10)';
    ctx.beginPath(); ctx.arc(c.x, c.y, 150, 0, 6.2832); ctx.stroke();
    ctx.restore();
  }

  /* the thing you are defending: a crashed hulk with a live reactor */
  function drawCore(t) {
    var x = S.core.x, y = S.core.y;
    var hurt = 1 - S.core.hp / S.core.max;
    var pulse = 0.5 + 0.5 * Math.sin(t * 2.2);
    ctx.save();
    ctx.fillStyle = 'rgba(6,16,24,.34)';
    ctx.beginPath(); ctx.ellipse(x, y + 8, 74, 28, 0, 0, 6.2832); ctx.fill();

    // hull
    ctx.fillStyle = '#3d4750';
    ctx.beginPath();
    ctx.moveTo(x - 62, y + 4);
    ctx.lineTo(x - 46, y - 40);
    ctx.lineTo(x - 12, y - 58);
    ctx.lineTo(x + 34, y - 50);
    ctx.lineTo(x + 62, y - 16);
    ctx.lineTo(x + 48, y + 8);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#5b6a74';
    ctx.beginPath();
    ctx.moveTo(x - 40, y - 38);
    ctx.lineTo(x - 8, y - 54);
    ctx.lineTo(x + 8, y - 40);
    ctx.lineTo(x - 22, y - 26);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#222c33'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - 56, y - 6); ctx.lineTo(x + 44, y - 4);
    ctx.stroke();

    // reactor eye
    var g = ctx.createRadialGradient(x, y - 26, 2, x, y - 26, 34);
    g.addColorStop(0, 'rgba(150,245,255,' + (0.75 + pulse * 0.25) + ')');
    g.addColorStop(1, 'rgba(60,200,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y - 26, 34, 0, 6.2832); ctx.fill();
    ctx.fillStyle = hurt > 0.6 ? '#ff9d5b' : '#9ff2ff';
    ctx.beginPath(); ctx.arc(x, y - 26, 9 + pulse * 2, 0, 6.2832); ctx.fill();
    ctx.fillStyle = '#eafcff';
    ctx.beginPath(); ctx.arc(x, y - 26, 4, 0, 6.2832); ctx.fill();

    // damage scars
    if (hurt > 0.25) {
      ctx.strokeStyle = 'rgba(255,90,70,' + (hurt * 0.7) + ')';
      ctx.lineWidth = 2;
      for (var i = 0; i < 4; i++) {
        var a = i * 1.9 + 0.4;
        ctx.beginPath();
        ctx.moveTo(x + Math.cos(a) * 18, y - 20 + Math.sin(a) * 16);
        ctx.lineTo(x + Math.cos(a) * 46, y - 20 + Math.sin(a) * 32);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  /* ---------------- structures ---------------- */
  function drawBuilding(b, t) {
    var x = b.x, y = b.y, dead = b.hit > 0;
    ctx.save();
    ctx.fillStyle = 'rgba(6,16,24,.26)';
    ctx.beginPath(); ctx.ellipse(x, y + 6, 21, 9, 0, 0, 6.2832); ctx.fill();

    if (b.kind === 'wall') {
      ctx.fillStyle = '#5c4128';
      ctx.fillRect(x - 21, y - 35, 42, 42);
      ctx.fillStyle = '#7a5836';
      ctx.fillRect(x - 20, y - 34, 40, 40);
      ctx.fillStyle = '#8f6a42';
      for (var i = 0; i < 3; i++) ctx.fillRect(x - 19, y - 32 + i * 13, 38, 9);
      ctx.fillStyle = 'rgba(255,226,170,.22)';
      ctx.fillRect(x - 19, y - 34, 38, 3);
      ctx.fillStyle = '#4d3623';
      ctx.fillRect(x - 21, y - 38, 6, 46);
      ctx.fillRect(x + 15, y - 38, 6, 46);
      ctx.fillStyle = '#a8814f';
      ctx.fillRect(x - 21, y - 40, 6, 5); ctx.fillRect(x + 15, y - 40, 6, 5);
    } else if (b.kind === 'stone') {
      ctx.fillStyle = '#6f777c';
      ctx.fillRect(x - 21, y - 38, 42, 44);
      ctx.fillStyle = '#8b949a';
      ctx.fillRect(x - 19, y - 36, 18, 12);
      ctx.fillRect(x + 1, y - 36, 18, 12);
      ctx.fillRect(x - 19, y - 22, 18, 12);
      ctx.fillRect(x + 1, y - 22, 18, 12);
      ctx.fillRect(x - 19, y - 8, 38, 12);
      ctx.strokeStyle = '#4b5357'; ctx.lineWidth = 1.5;
      ctx.strokeRect(x - 21, y - 38, 42, 44);
    } else if (b.kind === 'spike') {
      ctx.fillStyle = '#2f3a40';
      ctx.fillRect(x - 20, y - 8, 40, 12);
      ctx.fillStyle = '#b9c7cd';
      for (var k = -1; k <= 1; k++) {
        ctx.beginPath();
        ctx.moveTo(x + k * 12 - 5, y - 8);
        ctx.lineTo(x + k * 12, y - 34);
        ctx.lineTo(x + k * 12 + 5, y - 8);
        ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = 'rgba(255,90,110,.55)';
      ctx.fillRect(x - 20, y - 10, 40, 3);
    } else if (b.kind === 'turret') {
      ctx.fillStyle = '#2b363d';
      ctx.beginPath();
      ctx.moveTo(x - 18, y); ctx.lineTo(x - 12, y - 20);
      ctx.lineTo(x + 12, y - 20); ctx.lineTo(x + 18, y);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ffd479';
      ctx.fillRect(x - 14, y - 12, 28, 3);
      ctx.fillStyle = '#4d5c64';
      ctx.beginPath(); ctx.arc(x, y - 26, 13, 0, 6.2832); ctx.fill();
      ctx.fillStyle = '#6f858e';
      ctx.beginPath(); ctx.arc(x - 3, y - 29, 8, 0, 6.2832); ctx.fill();
      ctx.strokeStyle = '#26323a'; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(x, y - 26, 13, 0, 6.2832); ctx.stroke();
      ctx.save();
      ctx.translate(x, y - 26);
      ctx.rotate(b.aim);
      ctx.fillStyle = '#8fa3ab';
      ctx.fillRect(0, -4, 24, 8);
      ctx.fillStyle = '#ffd479';
      ctx.fillRect(20, -2, 4, 4);
      ctx.restore();
      ctx.fillStyle = '#64e0ff';
      ctx.beginPath(); ctx.arc(x, y - 26, 4, 0, 6.2832); ctx.fill();
      if (b.flash > 0) {
        var fk = clamp(b.flash / 0.09, 0, 1), mx2 = x + Math.cos(b.aim) * 24, my2 = y - 26 + Math.sin(b.aim) * 24;
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        var gf = ctx.createRadialGradient(mx2, my2, 0, mx2, my2, 20 * fk);
        gf.addColorStop(0, 'rgba(200,240,255,' + (0.9 * fk) + ')');
        gf.addColorStop(1, 'rgba(90,180,255,0)');
        ctx.fillStyle = gf;
        ctx.beginPath(); ctx.arc(mx2, my2, 20 * fk, 0, 6.2832); ctx.fill();
        ctx.restore();
      }
    } else if (b.kind === 'lamp') {
      ctx.fillStyle = '#5a4330';
      ctx.fillRect(x - 2, y - 34, 4, 34);
      ctx.fillStyle = '#8a6a44';
      ctx.fillRect(x - 7, y - 2, 14, 4);
      var fl = 0.75 + 0.25 * Math.sin(t * 9 + b.x);
      var g2 = ctx.createRadialGradient(x, y - 38, 1, x, y - 38, 26 * fl);
      g2.addColorStop(0, 'rgba(255,220,140,.95)');
      g2.addColorStop(1, 'rgba(255,150,60,0)');
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(x, y - 38, 26 * fl, 0, 6.2832); ctx.fill();
    }

    if (dead) {
      ctx.fillStyle = 'rgba(255,255,255,' + (0.2 + 0.45 * clamp(b.hit / 0.15, 0, 1)) + ')';
      ctx.fillRect(x - 20, y - 36, 40, 40);
    }
    if (b.hp < b.max) {
      var w = 38, f = Math.max(0, b.hp / b.max);
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillRect(x - w / 2, y - 46, w, 5);
      ctx.fillStyle = f > 0.5 ? '#8bff6a' : f > 0.22 ? '#ffd479' : '#ff5b6e';
      ctx.fillRect(x - w / 2, y - 46, w * f, 5);
    }
    ctx.restore();
  }

  /* ---------------- build preview ---------------- */
  function drawGhost(kind, cx, cy) {
    if (!kind) return;
    var chk = SIM.placeOk(kind, cx, cy);
    ctx.save();
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = chk.ok ? 'rgba(120,255,170,.55)' : 'rgba(255,90,90,.45)';
    ctx.fillRect(cx - 20, cy - 36, 40, 40);
    ctx.strokeStyle = chk.ok ? '#8bff6a' : '#ff5b6e';
    ctx.lineWidth = 2;
    ctx.strokeRect(cx - 20, cy - 36, 40, 40);
    ctx.globalAlpha = 1;
    ctx.fillStyle = chk.ok ? '#bfffd4' : '#ffb3b3';
    ctx.font = '11px Vazirmatn, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(chk.ok ? BUILD[kind].name : (chk.why || ''), cx, cy + 18);
    ctx.restore();
  }

  return {
    cam: cam, attach: attach, resize: resize, updateCam: updateCam, shake: shake,
    worldToScreen: worldToScreen,
    drawZone: drawZone, drawCore: drawCore, drawBuilding: drawBuilding, drawGhost: drawGhost,
    get ctx() { return ctx; }
  };
})();
