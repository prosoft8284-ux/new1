/* BERMUDA SIEGE — LAN transport (WebSocket, no dependencies) */
window.NET = (function () {
  'use strict';
  var ws = null;
  var id = 0;
  var isHost = false;
  var room = '';
  var handlers = {};
  var status = 'idle';        // idle | connecting | waiting | playing | error
  var errMsg = '';

  function emit(type, data) {
    (handlers[type] || []).forEach(function (fn) { try { fn(data); } catch (e) { console.error(e); } });
  }
  function on(type, fn) {
    (handlers[type] = handlers[type] || []).push(fn);
  }

  var serverAddr = '';

  /* "192.168.1.20", "192.168.1.20:8080" and "ws://host:port" all work */
  function setServer(addr) {
    serverAddr = String(addr || '').trim();
  }

  function wsUrl() {
    var p = location.protocol === 'https:' ? 'wss://' : 'ws://';
    var a = serverAddr.replace(/^wss?:\/\//i, '').replace(/\/$/, '');
    if (!a) a = location.hostname || '127.0.0.1';
    if (a.indexOf(':') < 0) a += ':8080';
    return p + a;
  }

  function connect(cb) {
    if (ws && (ws.readyState === 0 || ws.readyState === 1)) { cb && cb(); return; }
    status = 'connecting';
    try { ws = new WebSocket(wsUrl()); } catch (e) {
      status = 'error'; errMsg = 'اتصال به سرور ممکن نشد';
      emit('status', { status: status, err: errMsg });
      return;
    }
    ws.onopen = function () { cb && cb(); };
    ws.onclose = function () {
      status = 'error'; errMsg = 'ارتباط با سرور قطع شد';
      emit('status', { status: status, err: errMsg });
    };
    ws.onerror = function () {
      status = 'error'; errMsg = 'سرور در دسترس نیست — مطمئن شوید هر دو دستگاه به یک وای‌فای وصل‌اند';
      emit('status', { status: status, err: errMsg });
    };
    ws.onmessage = function (ev) {
      var m;
      try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.t === 'hello') {
        id = m.id; isHost = !!m.host; room = m.room;
        status = 'waiting';
        emit('hello', m);
        emit('status', { status: status, err: '' });
      } else if (m.t === 'room') {
        emit('room', m);
      } else if (m.t === 'msg') {
        emit('msg', { from: m.from, d: m.d });
      } else if (m.t === 'err') {
        errMsg = m.msg || 'خطای شبکه';
        emit('status', { status: 'error', err: errMsg });
      }
    };
  }

  function makeCode() {
    var abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    var s = '';
    for (var i = 0; i < 4; i++) s += abc[(Math.random() * abc.length) | 0];
    return s;
  }

  function join(code, name, skin) {
    room = code;
    send({ t: 'join', room: code, name: name, skin: skin || 0 });
    status = 'waiting';
  }

  function send(obj) {
    if (!ws || ws.readyState !== 1) return false;
    obj.from = id;
    ws.send(JSON.stringify(obj));
    return true;
  }

  function sendTo(uid, d) {
    return send({ t: 'to', to: uid, d: d });
  }

  function broadcast(d) {
    return send({ t: 'bc', d: d });
  }

  function setStatus(s, msg) {
    status = s;
    if (msg) errMsg = msg;
    emit('status', { status: status, err: errMsg });
  }

  return {
    connect: connect, join: join, setServer: setServer, wsUrl: wsUrl, send: send, sendTo: sendTo, broadcast: broadcast,
    on: on, makeCode: makeCode, setStatus: setStatus,
    get id() { return id; },
    get host() { return isHost; },
    get room() { return room; },
    get status() { return status; },
    get err() { return errMsg; },
    set room(v) { room = v; }
  };
})();
