/* ============================================================
   BERMUDA SIEGE — COMBAT
   Aliens walk the island, break whatever stands between them and the
   core, and the things you built answer back.
   ============================================================ */
window.CMB = (function () {
  'use strict';

  var S = SG.S, BUILD = SG.BUILD, ALIEN = SG.ALIEN;
  var clamp = SG.clamp, dist = SG.dist;

  /* ---------------- targeting ---------------- */
  function coreTarget() {
    return { x: S.core.x, y: S.core.y, r: S.core.r, core: true };
  }

  function pickTarget(a) {
    var best = null, bd = 900;
    for (var i = 0; i < S.players.length; i++) {
      var p = S.players[i];
      if (p.down) continue;
      var d = dist(a.x, a.y, p.x, p.y);
      if (d < bd) { bd = d; best = p; }
    }
    if (best) return best;
    return coreTarget();
  }

  /* ---------------- death ---------------- */
  function die(a, byPlayer) {
    if (a.hold) freePlayer(a);
    a.dead = true;
    S.kills++;
    var d = ALIEN[a.type];
    if (window.DIR && d.bounty) DIR.noise(0.05);
    S.res.metal += d.bounty || 1;
    SG.part(a.x, a.y, '#c48bff', d.boss ? 40 : 10, d.boss ? 240 : 130, 0.7, d.boss ? 4 : 3);
    if (d.boss) {
      SG.popText(a.x, a.y - 40, '+25 فلز', '#9fd8ff');
      if (window.HUD) HUD.banner('مادر افتاد', 'آخرین موج شکست. تا سپیده دوام بیاورید.', '#8bff6a');
    }
    if (window.SFX) SFX.kill && SFX.kill(a.x, a.y);
  }

  /* ---------------- alien senses ---------------- */
  function dmgOf(a, def) { return (def.dmg || 10) * (a.dmgMul === undefined ? 1 : a.dmgMul); }

  function attackBuilding(a, b, d) {
    var dmg = dmgOf(a, ALIEN[a.type]) * (ALIEN[a.type].siege || 1);
    SIM.hurtBuilding(b, dmg);
    a.swing = 0.2;
    SG.part(b.x + (Math.random() - 0.5) * 30, b.y - 10, '#e8d3a8', 4, 80, 0.3, 2);
    if (window.SFX) SFX.hit && SFX.hit(b.x, b.y);
  }

  /* ---------------- specials ---------------- */
  function freePlayer(a) {
    var p = a.hold ? SG.playerById(a.hold) : null;
    if (p) {
      p.pin = 0; p.pinT = 0; p.cd = 0.35;
      SG.popText(p.x, p.y - 30, 'آزاد شد', '#8bff6a');
    }
    a.hold = 0; a.pry = 0;
  }

  function grabTick(a, def, t, d, dt) {
    var p = a.hold ? SG.playerById(a.hold) : null;
    if (p && p.down) { freePlayer(a); p = null; }

    if (p) {
      /* it does not kill you — it holds you while the rest of the night arrives */
      p.pinT -= dt;
      p.hp = Math.max(1, p.hp - dmgOf(a, def) * dt * 0.85);
      p.hit = 0.18;
      a.x = p.x; a.y = p.y - 4;
      a.aim = p.aim;
      a.pry = a.pry || 0;
      for (var i = 0; i < S.players.length; i++) {
        var o = S.players[i];
        if (o.id === p.id || o.down) continue;
        if (dist(o.x, o.y, p.x, p.y) < 64 && o.in && o.in.r) a.pry += dt;
      }
      if (a.pry >= 1.1) {
        freePlayer(a);
        SG.part(p.x, p.y, '#8bff6a', 16, 130, 0.6, 3);
      } else if (p.pinT <= 0) {
        SIM.damagePlayer(p, 20);
        freePlayer(a);
      }
      return;
    }

    a.aim = Math.atan2(t.y - a.y, t.x - a.x);
    if (t.core) {
      var dc = dist(a.x, a.y, S.core.x, S.core.y);
      if (dc > S.core.r + def.r + 6) {
        SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
      } else if (a.cd <= 0) {
        a.cd = def.atk;
        SIM.damageCore(dmgOf(a, def));
      }
      return;
    }
    if (d > def.r + 14) {
      SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
    } else if (a.cd <= 0) {
      a.cd = 7;
      t.pin = a.id; t.pinT = 9;
      a.hold = t.id; a.pry = 0;
      a.swing = 0.2;
      SG.part(t.x, t.y - 14, '#7be0ff', 12, 110, 0.6, 3);
      if (window.HUD) HUD.banner('چنگ زد!', 'کنار هم‌تیمی بروید و R را نگه دارید، یا چنگ‌زن را بزنید.', '#ff5b6e');
      if (window.SFX) SFX.hit && SFX.hit(t.x, t.y);
    }
  }

  function screamTick(a, def, d, dt) {
    var t = pickTarget(a);
    a.aim = Math.atan2(t.y - a.y, t.x - a.x);
    if (d > 300) {
      SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
    } else if (d < 190) {
      SIM.moveActor(a, -Math.cos(a.aim) * def.speed * 0.9, -Math.sin(a.aim) * def.speed * 0.9, dt, def.r, true);
    }
    if (a.cd <= 0) {
      a.cd = def.atk + 8;
      a.scream = 0.9;
      var n = 3;
      for (var i = 0; i < n; i++) {
        SIM.spawnAlien('skitter', a.x + (Math.random() - 0.5) * 90, a.y + (Math.random() - 0.5) * 90);
      }
      SG.part(a.x, a.y - 10, '#ff8af0', 22, 200, 0.8, 4);
      if (window.SFX) SFX.howl && SFX.howl(a.x, a.y);
      if (window.HUD) HUD.toast('جیغ‌کش کمک خواست — اول او را بزنید', '#ff8af0');
    }
  }

  /* ---------------- main alien loop ---------------- */
  function update(dt) {
    var i, j, a;
    for (i = S.aliens.length - 1; i >= 0; i--) {
      a = S.aliens[i];
      if (a.hp <= 0 || a.dead) {
        if (a.hold) freePlayer(a);       // a dead grabber lets go
        S.aliens.splice(i, 1);
        continue;
      }
      if (a.hit > 0) a.hit -= dt;
      if (a.swing > 0) a.swing -= dt;
      if (a.scream > 0) a.scream -= dt;
      a.cd -= dt;
      var def = ALIEN[a.type];
      var t = pickTarget(a);
      var d = dist(a.x, a.y, t.x, t.y);
      a.aim = Math.atan2(t.y - a.y, t.x - a.x);

      /* siege the core when it is the last thing in reach */
      if (t.core) {
        var dc = dist(a.x, a.y, S.core.x, S.core.y);
        if (dc < S.core.r + def.r + 4) {
          if (a.cd <= 0) {
            a.cd = def.atk;
            SIM.damageCore(dmgOf(a, def) * (def.siege || 1));
            SG.part(S.core.x + (Math.random() - 0.5) * 40, S.core.y + (Math.random() - 0.5) * 40, '#ff8a5b', 6, 90, 0.4, 3);
            if (window.SFX) SFX.hit && SFX.hit(S.core.x, S.core.y);
          }
          continue;
        }
      }

      /* --- grabber: closes in and pins someone until the team reacts --- */
      if (def.grab) { grabTick(a, def, t, d, dt); continue; }
      /* --- screamer: hangs back and keeps calling friends --- */
      if (def.scream) { screamTick(a, def, d, dt); continue; }

      /* ranged bugs keep their distance and spit */
      if (def.ranged) {
        if (d > def.range * 0.85) {
          SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
        } else if (d < def.range * 0.45) {
          SIM.moveActor(a, -Math.cos(a.aim) * def.speed * 0.8, -Math.sin(a.aim) * def.speed * 0.8, dt, def.r, true);
        }
        if (a.cd <= 0 && d < def.range) {
          a.cd = def.atk;
          S.ebullets.push({
            x: a.x, y: a.y - 14,
            vx: Math.cos(a.aim) * 380, vy: Math.sin(a.aim) * 380,
            life: 1.5, dmg: dmgOf(a, def)
          });
          if (window.SFX) SFX.eShot && SFX.eShot(a.x, a.y, false);
        }
        continue;
      }

      /* suicide sack: run in and pop */
      if (def.suicide) {
        if (d > def.r + 26) {
          SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
        } else {
          explode(a);
          continue;
        }
      } else if (d > def.r + 18) {
        SIM.moveActor(a, Math.cos(a.aim) * def.speed, Math.sin(a.aim) * def.speed, dt, def.r, true);
      }

      /* whatever wall is in the way gets beaten down first */
      var fx = a.x + Math.cos(a.aim) * (def.r + 16);
      var fy = a.y + Math.sin(a.aim) * (def.r + 16);
      var wall = SIM.blockAt(fx, fy, def.r);
      if (wall && d > 40) {
        if (a.cd <= 0) { a.cd = def.atk; attackBuilding(a, wall, d); }
        continue;
      }

      /* melee on the target when close enough */
      if (!t.core && d < def.r + 18 + 14) {
        if (a.cd <= 0) {
          a.cd = def.atk;
          SIM.damagePlayer(t, dmgOf(a, def));
          a.swing = 0.2;
          SG.part(t.x, t.y - 16, '#ff5b6e', 3, 70, 0.3, 2);
        }
      }

      /* the mother keeps the pressure up */
      if (def.spawner) {
        a.sp -= dt;
        if (a.sp <= 0 && S.aliens.length < 55) {
          a.sp = 5.5;
          for (j = 0; j < 2; j++) {
            var sk = SIM.spawnAlien('skitter', a.x + (Math.random() - 0.5) * 70, a.y + (Math.random() - 0.5) * 70);
            if (sk) sk.hp = sk.max = 20;
          }
        }
      }
    }

    separate(dt);
    updBuildings(dt);
    updBullets(dt);
  }

  function explode(a) {
    var def = ALIEN[a.type];
    SG.part(a.x, a.y, '#ffb03a', 26, 220, 0.8, 4);
    if (window.SFX) SFX.explosion && SFX.explosion(a.x, a.y, false);
    var i;
    for (i = 0; i < S.players.length; i++) {
      if (S.players[i].down) continue;
      if (dist(a.x, a.y, S.players[i].x, S.players[i].y) < 92) SIM.damagePlayer(S.players[i], dmgOf(a, def));
    }
    for (i = 0; i < S.buildings.length; i++) {
      var b = S.buildings[i];
      if (dist(a.x, a.y, b.x, b.y) < 110) SIM.hurtBuilding(b, 95);
    }
    if (dist(a.x, a.y, S.core.x, S.core.y) < S.core.r + 96) SIM.damageCore(dmgOf(a, def));
    a.hp = 0;
  }

  /* keep the herd from stacking into one pixel */
  function separate(dt) {
    var n = S.aliens.length, i, j;
    for (i = 0; i < n; i++) {
      var a = S.aliens[i], def = ALIEN[a.type];
      for (j = i + 1; j < n; j++) {
        var b = S.aliens[j];
        var dx = b.x - a.x, dy = b.y - a.y;
        var dd = Math.hypot(dx, dy);
        var min = def.r + ALIEN[b.type].r;
        if (dd > 0.001 && dd < min) {
          var push = (min - dd) * 0.5;
          dx /= dd; dy /= dd;
          a.x -= dx * push; a.y -= dy * push;
          b.x += dx * push; b.y += dy * push;
        }
      }
    }
  }

  /* ---------------- bullets ---------------- */
  function updBullets(dt) {
    var i, j, b, a;
    for (i = S.bullets.length - 1; i >= 0; i--) {
      b = S.bullets[i];
      b.life -= dt;
      var steps = 3;
      var hit = false;
      for (var s = 0; s < steps && !hit; s++) {
        b.x += b.vx * dt / steps;
        b.y += b.vy * dt / steps;
        for (j = 0; j < S.aliens.length; j++) {
          a = S.aliens[j];
          var r = ALIEN[a.type].r + 5;
          if (Math.abs(b.x - a.x) < r && Math.abs(b.y - a.y) < r) {
            a.hp -= b.dmg;
            a.hit = 0.12;
            a.kx = b.vx * 0.01;
            SG.part(b.x, b.y, '#ffd0a0', 4, 110, 0.25, 2);
            if (window.SFX) SFX.hit && SFX.hit(a.x, a.y);
            if (a.hp <= 0) { die(a, b.owner); S.aliens.splice(j, 1); }
            hit = true;
            break;
          }
        }
      }
      if (hit || b.life <= 0) S.bullets.splice(i, 1);
    }

    for (i = S.ebullets.length - 1; i >= 0; i--) {
      b = S.ebullets[i];
      b.life -= dt;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      var gone = b.life <= 0;
      if (!gone) {
        for (j = 0; j < S.players.length; j++) {
          var p = S.players[j];
          if (p.down) continue;
          if (dist(b.x, b.y, p.x, p.y - 14) < 20) {
            SIM.damagePlayer(p, b.dmg);
            gone = true;
            break;
          }
        }
      }
      if (!gone) {
        var w = SIM.blockAt(b.x, b.y, 2);
        if (w) { SIM.hurtBuilding(w, b.dmg); gone = true; }
      }
      if (!gone && dist(b.x, b.y, S.core.x, S.core.y) < S.core.r) {
        SIM.damageCore(b.dmg * 0.6);
        gone = true;
      }
      if (gone) {
        SG.part(b.x, b.y, '#ff8af0', 5, 90, 0.3, 2);
        S.ebullets.splice(i, 1);
      }
    }
  }

  /* ---------------- what the survivors built ---------------- */
  function updBuildings(dt) {
    var i, j, b, a;
    for (i = 0; i < S.buildings.length; i++) {
      b = S.buildings[i];
      if (b.kind === 'turret') {
        b.cd -= dt;
        var best = null, bd = 400;
        for (j = 0; j < S.aliens.length; j++) {
          a = S.aliens[j];
          var d = dist(b.x, b.y, a.x, a.y);
          if (d < bd) { bd = d; best = a; }
        }
        if (best) {
          b.aim = Math.atan2(best.y - b.y, best.x - b.x);
          if (b.cd <= 0) {
            b.cd = 0.52;
            b.flash = 0.09;
            var ang = b.aim + (Math.random() - 0.5) * 0.06;
            S.bullets.push({
              x: b.x + Math.cos(ang) * 16, y: b.y - 24 + Math.sin(ang) * 16,
              vx: Math.cos(ang) * 980, vy: Math.sin(ang) * 980,
              life: 0.55, dmg: 17, owner: 0, hit: 0
            });
            if (window.SFX) SFX.shot && SFX.shot('pistol');
          }
        }
      } else if (b.kind === 'spike') {
        for (j = 0; j < S.aliens.length; j++) {
          a = S.aliens[j];
          if (Math.abs(a.x - b.x) < 30 && Math.abs(a.y - b.y) < 30) {
            a.hp -= 48 * dt;
            a.hit = Math.max(a.hit || 0, 0.05);
            if (Math.random() < 0.12) SG.part(a.x, a.y, '#ff5b6e', 1, 50, 0.3, 2);
            if (a.hp <= 0) { die(a, 0); }
          }
        }
      }
      if (b.hit > 0) b.hit -= dt;
      if (b.flash > 0) b.flash -= dt;
    }
    // sweep corpses of things killed by spikes
    for (i = S.aliens.length - 1; i >= 0; i--) if (S.aliens[i].hp <= 0) S.aliens.splice(i, 1);
  }

  return { update: update, pickTarget: pickTarget, die: die };
})();
