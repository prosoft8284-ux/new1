/* ============================================================
   BERMUDA SIEGE — WORLD LAYER
   The v1.1 island (4096x2304) reused as the battlefield: terrain is the
   baked base canvas, every tree/boulder/wreck near the base becomes a
   harvestable node, and the whole thing is drawn depth-sorted with the
   actors so a survivor can walk behind a palm.
   ============================================================ */
window.SW = (function () {
  'use strict';

  var W = 4096, H = 2304;
  var base = null;                 // {x, y, r}  defence zone
  var core = { x: 0, y: 0 };
  var nodes = [];                  // harvestable things
  var portals = [];                // where the night waves walk in from
  var decor = [];                  // trees that are only scenery
  var ready = false;

  var BASE_POI = { x: 1010, y: 1510 };   // the old military base
  var BASE_R = 520;                      // build radius
  var NODE_R = 1500;                     // how far resources are worth the walk

  /* ---------------- helpers ---------------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function rnd(seed) {
    var a = seed | 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function flat(x, y) {
    return BS.isLand(x, y) && BS.elev(x, y) < 0.5;
  }

  /* ---------------- boot ---------------- */
  function boot(onStep, done) {
    BS.build(onStep, function () {
      W = BS.W; H = BS.H;
      BS.buildBase();
      base = findBase();
      paintBaseCamp();
      core.x = base.x; core.y = base.y;
      buildNodes();
      buildPortals();
      ready = true;
      if (done) done();
    });
  }

  /* the military base is the theme; nudge it to the flattest dry patch */
  function findBase() {
    var best = null;
    for (var ry = -3; ry <= 3; ry++) {
      for (var rx = -3; rx <= 3; rx++) {
        var x = BASE_POI.x + rx * 70, y = BASE_POI.y + ry * 70;
        if (!flat(x, y)) continue;
        var score = 0;
        for (var a = 0; a < 8; a++) {
          var ang = a * 0.7854;
          for (var d = 60; d <= 320; d += 65) {
            if (flat(x + Math.cos(ang) * d, y + Math.sin(ang) * d)) score++;
          }
        }
        score -= Math.hypot(rx, ry) * 0.6;
        if (!best || score > best.score) best = { x: x, y: y, score: score };
      }
    }
    if (!best) best = { x: BASE_POI.x, y: BASE_POI.y, score: 0 };
    return { x: best.x, y: best.y, r: BASE_R };
  }

  /* the base camp gets its own clearing so the defence is readable */
  function paintBaseCamp() {
    var ctx = BS.baseCtx;
    if (!ctx) return;
    var x = base.x, y = base.y, r = 260;
    ctx.save();
    var g = ctx.createRadialGradient(x, y, r * 0.18, x, y, r);
    g.addColorStop(0, 'rgba(126,104,70,0.92)');
    g.addColorStop(0.55, 'rgba(112,94,64,0.72)');
    g.addColorStop(0.82, 'rgba(96,86,58,0.30)');
    g.addColorStop(1, 'rgba(90,80,54,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r * 0.78, 0, 0, 6.2832);
    ctx.fill();

    // tyre ruts and crates marks for a lived-in camp
    ctx.globalAlpha = 0.16;
    ctx.strokeStyle = '#3a3122';
    ctx.lineWidth = 7;
    for (var i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.ellipse(x, y, 90 + i * 52, 70 + i * 40, 0.15, 0.4, 3.6);
      ctx.stroke();
    }
    ctx.globalAlpha = 0.5;
    var R = rnd(4242);
    for (i = 0; i < 90; i++) {
      var a = R() * 6.2832, d = Math.sqrt(R()) * r * 0.92;
      var px = x + Math.cos(a) * d, py = y + Math.sin(a) * d * 0.8;
      ctx.fillStyle = R() < 0.5 ? 'rgba(70,62,44,.5)' : 'rgba(150,134,102,.4)';
      var s = 1.5 + R() * 3;
      ctx.fillRect(px, py, s, s * 0.7);
    }
    ctx.restore();
  }

  /* ---------------- harvestable nodes ---------------- */
  function nodeHp(type) { return type === 'tree' ? 90 : type === 'rock' ? 150 : 210; }

  function buildNodes() {
    nodes = [];
    var i, t, d, x, y;
    var trees = BS.world.trees || [];
    for (i = 0; i < trees.length; i++) {
      t = trees[i];
      d = Math.hypot(t.x - core.x, t.y - core.y);
      if (d > NODE_R) continue;
      if (!flat(t.x, t.y)) continue;
      if (d < 228) continue;                        // keep the camp clearing open
      var type = t.t === 'rock' ? 'rock' : 'tree';
      nodes.push({
        id: 'n' + i, type: type, x: t.x, y: t.y,
        s: t.s || 14, hp: nodeHp(type), max: nodeHp(type),
        r: type === 'rock' ? 16 : 20, alive: true,
        seed: (i * 2654435761) % 1000
      });
    }
    // wrecks are the only metal on the island
    var wrecks = BS.world.wrecks || [];
    for (i = 0; i < wrecks.length; i++) {
      var w = wrecks[i];
      d = Math.hypot(w.x - core.x, w.y - core.y);
      if (d > NODE_R + 500) continue;
      nodes.push({
        id: 'w' + i, type: 'wreck', x: w.x, y: w.y, s: w.s || 1,
        hp: nodeHp('wreck'), max: nodeHp('wreck'), r: 30, alive: true, seed: i * 37
      });
    }
    // guarantee a starter patch of everything within a short walk
    ensureRing('rock', 3, 250, 380);
    ensureRing('tree', 8, 240, 470);
    ensureRing('wreck', 1, 300, 500);

    // every tree outside the harvest ring is pure scenery
    decor = [];
    for (i = 0; i < trees.length; i++) {
      t = trees[i];
      var dd = Math.hypot(t.x - core.x, t.y - core.y);
      if (dd > NODE_R || dd < 235) continue;   // keep the camp clearing open
      if (!flat(t.x, t.y)) continue;
      decor.push(t);
    }
  }

  var nodeSeq = 0;

  function ensureRing(type, need, r0, r1) {
    var have = 0, i;
    for (i = 0; i < nodes.length; i++) if (nodes[i].alive && nodes[i].type === type &&
      Math.hypot(nodes[i].x - core.x, nodes[i].y - core.y) < r1) have++;
    if (have >= need) return;
    var R = rnd(type.length * 977 + 13);
    for (var guard = 0; guard < 400 && have < need; guard++) {
      var a = R() * 6.2832, d = r0 + R() * (r1 - r0);
      var x = core.x + Math.cos(a) * d, y = core.y + Math.sin(a) * d;
      if (!flat(x, y)) continue;
      // do not stack on an existing node
      var busy = false;
      for (i = 0; i < nodes.length; i++) {
        if (Math.hypot(nodes[i].x - x, nodes[i].y - y) < 54) { busy = true; break; }
      }
      if (busy) continue;
      nodes.push({
        id: 'x' + type + (nodeSeq++), type: type, x: x, y: y, s: type === 'rock' ? 12 : 16,
        hp: nodeHp(type), max: nodeHp(type), r: type === 'rock' ? 16 : 20,
        alive: true, seed: (have * 313 + 7) % 1000
      });
      have++;
    }
  }

  /* dawn brings a few fresh trees/rocks near camp so the loop never starves */
  function respawn() {
    ensureRing('tree', 14, 240, 560);
    ensureRing('rock', 6, 250, 520);
    ensureRing('wreck', 2, 320, 620);
  }

  /* ---------------- night portals ---------------- */
  function buildPortals() {
    portals = [];
    var angles = [0.35, 2.2, 4.1, 5.35];
    for (var i = 0; i < angles.length; i++) {
      var found = null;
      for (var d = 1050; d <= 1500 && !found; d += 60) {
        for (var k = 0; k < 8 && !found; k++) {
          var a = angles[i] + k * 0.22;
          var x = core.x + Math.cos(a) * d, y = core.y + Math.sin(a) * d;
          if (flat(x, y) && x > 120 && y > 120 && x < W - 120 && y < H - 120) found = { x: x, y: y, a: a };
        }
      }
      if (found) portals.push({ id: 'p' + i, x: found.x, y: found.y, ang: found.a });
    }
    if (!portals.length) portals.push({ id: 'p0', x: core.x + 900, y: core.y, ang: 0 });
  }

  /* ---------------- collision ---------------- */
  function walkable(x, y) {
    return BS.isLand(x, y) && BS.elev(x, y) < 0.62;
  }

  /* ---------------- sprites (drawn, not loaded) ---------------- */
  function hash(x, y) {
    var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  function treeColor(node) {
    if (node.type === 'rock') return null;
    var v = hash(node.x, node.y);
    return v < 0.33 ? '#2f6b34' : v < 0.66 ? '#3a7d3c' : '#275c30';
  }

  function drawTree(ctx, n, t) {
    var v = hash(n.x, n.y);
    var s = n.s;
    if (n.type === 'rock') {
      ctx.fillStyle = 'rgba(8,20,14,.28)';
      ctx.beginPath(); ctx.ellipse(n.x, n.y + 3, s * 1.1, s * 0.45, 0, 0, 6.2832); ctx.fill();
      ctx.fillStyle = '#8d8a80';
      ctx.beginPath();
      ctx.moveTo(n.x - s, n.y + 2);
      ctx.lineTo(n.x - s * 0.55, n.y - s * 0.85);
      ctx.lineTo(n.x + s * 0.15, n.y - s * 1.15);
      ctx.lineTo(n.x + s * 0.9, n.y - s * 0.4);
      ctx.lineTo(n.x + s * 0.7, n.y + 4);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.14)';
      ctx.beginPath();
      ctx.moveTo(n.x - s * 0.55, n.y - s * 0.85);
      ctx.lineTo(n.x + s * 0.15, n.y - s * 1.15);
      ctx.lineTo(n.x + s * 0.1, n.y - s * 0.55);
      ctx.closePath(); ctx.fill();
      return;
    }
    var col = treeColor(n);
    var sway = Math.sin(t * 0.0012 + n.x * 0.01) * 1.4;
    // trunk
    ctx.fillStyle = '#4a3524';
    ctx.fillRect(n.x - 2, n.y - s * 0.5, 4, s * 0.55);
    // canopy: three overlapping blobs, lighter on top
    ctx.fillStyle = 'rgba(10,26,16,.30)';
    ctx.beginPath(); ctx.ellipse(n.x + 3, n.y + 2, s * 1.05, s * 0.42, 0, 0, 6.2832); ctx.fill();
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.arc(n.x - s * 0.35 + sway, n.y - s * 0.85, s * 0.72, 0, 6.2832); ctx.fill();
    ctx.beginPath(); ctx.arc(n.x + s * 0.38 + sway, n.y - s * 0.80, s * 0.66, 0, 6.2832); ctx.fill();
    ctx.beginPath(); ctx.arc(n.x + sway, n.y - s * 1.25, s * 0.78, 0, 6.2832); ctx.fill();
    ctx.fillStyle = 'rgba(160,220,140,.20)';
    ctx.beginPath(); ctx.arc(n.x - s * 0.2 + sway, n.y - s * 1.45, s * 0.42, 0, 6.2832); ctx.fill();
  }

  function drawWreck(ctx, n) {
    var s = n.s;
    ctx.save();
    ctx.translate(n.x, n.y);
    ctx.fillStyle = 'rgba(8,20,14,.28)';
    ctx.beginPath(); ctx.ellipse(0, 4, 40 * s, 14 * s, 0, 0, 6.2832); ctx.fill();
    ctx.fillStyle = '#6d7476';
    ctx.beginPath();
    ctx.moveTo(-40 * s, 0); ctx.quadraticCurveTo(-20 * s, -13 * s, 22 * s, -10 * s);
    ctx.quadraticCurveTo(40 * s, -7 * s, 43 * s, 0);
    ctx.quadraticCurveTo(28 * s, 12 * s, -14 * s, 11 * s);
    ctx.quadraticCurveTo(-32 * s, 9 * s, -40 * s, 0); ctx.fill();
    ctx.strokeStyle = 'rgba(160,168,166,.45)'; ctx.lineWidth = 1;
    for (var k = -28; k < 26; k += 9) {
      ctx.beginPath(); ctx.moveTo(k * s, -9 * s); ctx.lineTo(k * s, 9 * s); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(48,56,58,.9)';
    ctx.fillRect(-14 * s, -18 * s, 18 * s, 10 * s);
    ctx.restore();
  }

  /* a node shows cracks / chips as it is harvested */
  function drawNodeDamage(ctx, n) {
    if (n.hp >= n.max) return;
    var f = 1 - n.hp / n.max;
    ctx.globalAlpha = 0.5 * f;
    ctx.strokeStyle = '#ffd479';
    ctx.lineWidth = 1.2;
    for (var i = 0; i < 3; i++) {
      var a = i * 2.1 + n.seed;
      ctx.beginPath();
      ctx.moveTo(n.x - Math.cos(a) * n.r * 0.7, n.y - n.s * 0.7 - Math.sin(a) * n.r * 0.5);
      ctx.lineTo(n.x + Math.cos(a) * n.r * 0.5, n.y - n.s * 0.9 - Math.sin(a) * n.r * 0.3);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------- draw ---------------- */
  var treeScratch = [];
  function drawGround(ctx, cam) {
    var sw = cam.w / cam.z, sh = cam.h / cam.z;
    var sx = clamp(cam.x - sw / 2, 0, W - 1), sy = clamp(cam.y - sh / 2, 0, H - 1);
    sw = Math.min(sw + 4, W - sx); sh = Math.min(sh + 4, H - sy);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'medium';
    ctx.drawImage(BS.baseCanvas, sx, sy, sw, sh, sx, sy, sw, sh);
  }

  /* everything that sorts by y: trees, nodes, wrecks, actors, buildings */
  function collectVisible(cam, extra) {
    var out = treeScratch;
    out.length = 0;
    var vw = cam.w / cam.z, vh = cam.h / cam.z;
    var x0 = cam.x - vw / 2 - 90, x1 = cam.x + vw / 2 + 90;
    var y0 = cam.y - vh / 2 - 160, y1 = cam.y + vh / 2 + 160;
    var i;
    for (i = 0; i < decor.length; i++) {
      var d = decor[i];
      if (d.x < x0 || d.x > x1 || d.y < y0 || d.y > y1) continue;
      out.push({ y: d.y, kind: 'decor', ref: d });
    }
    for (i = 0; i < extra.length; i++) out.push(extra[i]);
    out.sort(function (a, b) { return a.y - b.y; });
    return out;
  }

  function drawSceneryItem(ctx, it, t) {
    if (it.kind === 'decor') {
      var d = it.ref;
      drawTree(ctx, { x: d.x, y: d.y, s: d.s, type: d.t === 'rock' ? 'rock' : 'tree' }, t);
    } else if (it.kind === 'node') {
      var n = it.ref;
      if (!n.alive) return;
      if (n.type === 'wreck') drawWreck(ctx, n); else drawTree(ctx, n, t);
      drawNodeDamage(ctx, n);
    }
  }

  /* ---------------- minimap ---------------- */
  function drawMinimap(ctx, w, h, dots) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#07131c';
    ctx.fillRect(0, 0, w, h);
    if (BS.baseCanvas) ctx.drawImage(BS.baseCanvas, 0, 0, w, h);
    var sx = w / W, sy = h / H, i;
    // base zone
    ctx.strokeStyle = 'rgba(140,240,255,.75)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(core.x * sx, core.y * sy, BASE_R * sx, 0, 6.2832); ctx.stroke();
    // portals
    ctx.fillStyle = 'rgba(200,120,255,.9)';
    for (i = 0; i < portals.length; i++) {
      ctx.beginPath(); ctx.arc(portals[i].x * sx, portals[i].y * sy, 2.4, 0, 6.2832); ctx.fill();
    }
    if (!dots) return;
    for (i = 0; i < dots.length; i++) {
      var d2 = dots[i];
      ctx.fillStyle = d2.color;
      ctx.fillRect(d2.x * sx - 1.5, d2.y * sy - 1.5, 3, 3);
    }
  }

  return {
    boot: boot,
    get ready() { return ready; },
    W: function () { return W; }, H: function () { return H; },
    base: function () { return base; }, core: function () { return core; },
    baseR: function () { return BASE_R; },
    nodes: function () { return nodes; }, portals: function () { return portals; },
    respawn: respawn,
    walkable: walkable,
    drawGround: drawGround, collectVisible: collectVisible, drawSceneryItem: drawSceneryItem,
    drawTree: drawTree, drawWreck: drawWreck, drawMinimap: drawMinimap
  };
})();
