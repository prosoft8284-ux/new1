/* BERMUDA SIEGE — DOM HUD */
window.HUD = (function () {
  'use strict';
  var S = SG.S;
  var el = {};
  var sel = null;
  var selKind = null;
  var fa = '۰۱۲۳۴۵۶۷۸۹';

  function digits(n) {
    return String(Math.max(0, Math.round(n))).replace(/\d/g, function (d) { return fa[+d]; });
  }
  function mmss(sec) {
    sec = Math.max(0, sec);
    var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return digits(m) + ':' + (s < 10 ? '۰' : '') + digits(s);
  }

  function init() {
    ['boot', 'bootMsg', 'bootFill', 'hud', 'cv', 'clock', 'clockChip', 'phaseIcon', 'phaseName',
      'coreChip', 'coreFill', 'coreTxt', 'ammoChip', 'ammoFill', 'ammoTxt',
      'rWood', 'rStone', 'rMetal', 'waveChip', 'netChip',
      'bar', 'banner', 'toast', 'mute', 'exit', 'squad', 'mm', 'hint', 'btnGather', 'btnRepair'
    ].forEach(function (id) { el[id] = document.getElementById(id); });

    buildBar();
    el.mute.onclick = function () {
      var m = SFX.toggle();
      el.mute.textContent = m ? '🔇' : '🔊';
    };
    el.exit.onclick = function () { location.href = 'index.html'; };
    el.mm.width = 190; el.mm.height = 107;
    el.mmCtx = el.mm.getContext('2d');
    if ('ontouchstart' in window) el.hint && (el.hint.textContent = 'انگشت چپ: حرکت • انگشت راست: نشانه و شلیک');
  }

  function buildBar() {
    var html = '';
    SG.BUILD_ORDER.forEach(function (k) {
      var d = SG.BUILD[k];
      var cost = [];
      for (var c in d.cost) cost.push(d.cost[c] + (c === 'wood' ? 'چوب' : c === 'stone' ? 'سنگ' : 'فلز'));
      html += '<div class="bcard" data-kind="' + k + '">' +
        '<span class="kx">' + d.key + '</span>' +
        '<span class="ic">' + d.icon + '</span>' +
        '<div>' + d.short + '</div>' +
        '<div class="ct">' + cost.join('+') + '</div></div>';
    });
    el.bar.innerHTML = html;
    Array.prototype.forEach.call(el.bar.querySelectorAll('.bcard'), function (node) {
      node.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleSelect(node.dataset.kind);
      });
    });
  }

  function toggleSelect(kind) {
    selKind = (selKind === kind) ? null : kind;
    if (!selKind) { FRAME.clearGhost(); }
    Array.prototype.forEach.call(el.bar.querySelectorAll('.bcard'), function (n) {
      n.classList.toggle('on', n.dataset.kind === selKind);
    });
    if (selKind) toast(SG.BUILD[selKind].desc);
  }
  function selected() { return selKind; }
  function clearSelect() { toggleSelect(selKind); }

  function banner(title, sub, color) {
    el.banner.classList.remove('hide');
    el.banner.querySelector('h2').textContent = title;
    el.banner.querySelector('h2').style.color = color || '#fff';
    el.banner.querySelector('p').textContent = sub || '';
    clearTimeout(el.banner._t);
    el.banner._t = setTimeout(function () { el.banner.classList.add('hide'); }, 4200);
  }

  function toast(msg) {
    el.toast.textContent = msg;
    el.toast.classList.add('on');
    clearTimeout(el.toast._t);
    el.toast._t = setTimeout(function () { el.toast.classList.remove('on'); }, 2200);
  }

  function shake(a) { RND.shake(a); }

  function update(dt) {
    if (!S.ready) return;
    var night = S.phase === 'night';
    el.clock.textContent = mmss(S.tLeft);
    el.phaseIcon.textContent = night ? '🌙' : (S.tLeft < 18 ? '🌇' : '☀');
    el.phaseName.textContent = night ? ('شب ' + digits(S.nights) + ' از ' + digits(SG.WIN_NIGHTS)) : ('روز ' + digits(S.day));
    el.clockChip.classList.toggle('night', night);

    var f = S.core.hp / S.core.max;
    el.coreFill.style.width = (f * 100).toFixed(1) + '%';
    el.coreTxt.textContent = digits(S.core.hp);
    el.coreChip.classList.toggle('low', f < 0.35);

    var me = SG.me();
    if (me && el.ammoFill) {
      var mag = me.mag === undefined ? SG.AMMO.max : me.mag;
      var mm = me.magMax || SG.AMMO.max;
      el.ammoFill.style.width = Math.max(0, (mag / mm) * 100) + '%';
      el.ammoTxt.textContent = me.rl > 0 ? '…' : digits(mag);
      el.ammoChip.classList.toggle('rl', me.rl > 0);
    }

    el.rWood.textContent = digits(S.res.wood);
    el.rStone.textContent = digits(S.res.stone);
    el.rMetal.textContent = digits(S.res.metal);

    if (night) {
      var left = S.aliens.length + S.spawnQ.length;
      var mood = (S.dir && S.dir.mood) || 'calm';
      var moodFa = mood === 'peak' ? 'هجوم' : mood === 'relief' ? 'نفس بکشید'
        : mood === 'build' ? 'آماده باشید' : 'آرام';
      el.waveChip.textContent = 'شب ' + digits(S.nights) + ' • ' + moodFa + ' — ' + digits(left);
      el.waveChip.classList.add('night');
      el.waveChip.classList.toggle('peak', mood === 'peak');
    } else {
      el.waveChip.textContent = 'تا شب ' + mmss(S.tLeft);
      el.waveChip.classList.remove('night');
      el.waveChip.classList.remove('peak');
    }

    Array.prototype.forEach.call(el.bar.querySelectorAll('.bcard'), function (n) {
      var d = SG.BUILD[n.dataset.kind];
      n.classList.toggle('poor', !SG.canAfford(d.cost));
    });

    drawSquad();
    drawMinimap();
  }

  function drawSquad() {
    var html = '';
    for (var i = 0; i < S.players.length; i++) {
      var p = S.players[i];
      var cls = p.down ? 'sq down' : 'sq';
      var tag = p.down ? ' ⏳' + digits(Math.ceil(p.rt)) : '';
      html += '<div class="' + cls + '"><i style="background:' + p.color + '"></i>' +
        '<span>' + p.name + tag + '</span>' +
        '<span class="hp"><b style="width:' + Math.max(0, (p.hp / p.max) * 100) + '%"></b></span></div>';
    }
    if (el.squad._html !== html) { el.squad.innerHTML = html; el.squad._html = html; }
  }

  function drawMinimap() {
    var ctx = el.mmCtx, w = el.mm.width, h = el.mm.height;
    var dots = [];
    for (var i = 0; i < S.players.length; i++) {
      var p = S.players[i];
      dots.push({ x: p.x, y: p.y, color: p.id === S.localId ? '#ffffff' : p.color });
    }
    for (i = 0; i < S.aliens.length; i++) dots.push({ x: S.aliens[i].x, y: S.aliens[i].y, color: '#ff5b6e' });
    SW.drawMinimap(ctx, w, h, dots);
  }

  function setNet(txt, on) {
    el.netChip.textContent = txt;
    el.netChip.classList.toggle('on', !!on);
  }

  function bootProgress(msg, pct) {
    if (el.bootMsg) el.bootMsg.textContent = msg;
    if (el.bootFill && pct != null) el.bootFill.style.width = SG.clamp(pct * 100, 4, 100) + '%';
  }
  function bootDone() {
    if (el.boot) el.boot.classList.add('hide');
    if (el.hud) el.hud.classList.remove('hide');
  }

  return {
    init: init, update: update, banner: banner, toast: toast, shake: shake,
    selected: selected, clearSelect: clearSelect, toggleSelect: toggleSelect,
    setNet: setNet, bootProgress: bootProgress, bootDone: bootDone,
    el: el, digits: digits
  };
})();
