/* BERMUDA SIEGE — one frame: depth-sorted world, then the dark */
window.FRAME = (function () {
  'use strict';
  var S = SG.S, cam = RND.cam;
  var darkCv = null, darkCtx = null;
  var ghostKind = null, ghostX = 0, ghostY = 0;

  function ensureDark(w, h) {
    if (!darkCv) {
      darkCv = document.createElement('canvas');
      darkCtx = darkCv.getContext('2d');
    }
    if (darkCv.width !== Math.round(w) || darkCv.height !== Math.round(h)) {
      darkCv.width = Math.round(w);
      darkCv.height = Math.round(h);
    }
  }

  function scr(x, y) { return RND.worldToScreen(x, y); }

  /* ---------------- daylight / night ---------------- */
  function night(t) {
    var ctx = RND.ctx;
    var lv = S.light;
    if (lv < 0.03) return;
    var w = cam.w, h = cam.h;
    ensureDark(w, h);
    darkCtx.setTransform(1, 0, 0, 1, 0, 0);
    darkCtx.globalCompositeOperation = 'source-over';
    darkCtx.clearRect(0, 0, w, h);
    darkCtx.fillStyle = 'rgba(4,9,26,' + (0.92 * lv).toFixed(3) + ')';
    darkCtx.fillRect(0, 0, w, h);

    darkCtx.globalCompositeOperation = 'destination-out';
    var lights = [];
    var i, p;
    lights.push({ x: S.core.x, y: S.core.y - 26, r: 380 });
    for (i = 0; i < S.players.length; i++) {
      p = S.players[i];
      lights.push({ x: p.x, y: p.y - 14, r: p.down ? 130 : 235 });
    }
    for (i = 0; i < S.buildings.length; i++) {
      var b = S.buildings[i];
      if (b.kind === 'lamp') lights.push({ x: b.x, y: b.y - 34, r: 190 });
      else if (b.kind === 'turret') lights.push({ x: b.x, y: b.y - 24, r: 110 });
    }
    for (i = 0; i < SW.portals().length; i++) {
      var po = SW.portals()[i];
      lights.push({ x: po.x, y: po.y, r: 135 });
    }
    for (i = 0; i < S.aliens.length; i++) lights.push({ x: S.aliens[i].x, y: S.aliens[i].y - 12, r: 44 });

    for (i = 0; i < lights.length; i++) {
      var L = lights[i], s = scr(L.x, L.y);
      var rr = L.r * cam.z * (0.85 + lv * 0.25);
      if (s.x + rr < 0 || s.x - rr > w || s.y + rr < 0 || s.y - rr > h) continue;
      var g = darkCtx.createRadialGradient(s.x, s.y, rr * 0.1, s.x, s.y, rr);
      g.addColorStop(0, 'rgba(0,0,0,0.86)');
      g.addColorStop(0.55, 'rgba(0,0,0,0.48)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      darkCtx.fillStyle = g;
      darkCtx.beginPath(); darkCtx.arc(s.x, s.y, rr, 0, 6.2832); darkCtx.fill();
    }
    darkCtx.globalCompositeOperation = 'source-over';
    ctx.drawImage(darkCv, 0, 0, w, h);

    // warm spill so lamps read as light sources, not holes
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (i = 0; i < S.buildings.length; i++) {
      if (S.buildings[i].kind !== 'lamp') continue;
      var lb = S.buildings[i], ls = scr(lb.x, lb.y - 34);
      var lg = ctx.createRadialGradient(ls.x, ls.y, 2, ls.x, ls.y, 130 * cam.z);
      lg.addColorStop(0, 'rgba(255,190,110,' + (0.20 * lv).toFixed(3) + ')');
      lg.addColorStop(1, 'rgba(255,150,60,0)');
      ctx.fillStyle = lg;
      ctx.beginPath(); ctx.arc(ls.x, ls.y, 130 * cam.z, 0, 6.2832); ctx.fill();
    }
    ctx.restore();
  }

  /* ---------------- the frame ---------------- */
  function draw(dt, t) {
    var ctx = RND.ctx;
    if (!ctx) return;
    RND.updateCam(dt);
    var dpr = RND.dpr || 1;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#081a24';
    ctx.fillRect(0, 0, cam.w, cam.h);

    ctx.save();
    ctx.translate(cam.w / 2, cam.h / 2);
    ctx.scale(cam.z, cam.z);
    ctx.translate(-cam.x, -cam.y);

    SW.drawGround(ctx, cam);
    RND.drawZone();

    var extra = [], i;
    for (i = 0; i < S.aliens.length; i++) extra.push({ y: S.aliens[i].y, k: 'a', r: S.aliens[i] });
    for (i = 0; i < S.players.length; i++) extra.push({ y: S.players[i].y, k: 'p', r: S.players[i] });
    for (i = 0; i < S.buildings.length; i++) extra.push({ y: S.buildings[i].y, k: 'b', r: S.buildings[i] });
    for (i = 0; i < S.nodes.length; i++) {
      if (S.nodes[i].alive) extra.push({ y: S.nodes[i].y, k: 'n', r: S.nodes[i] });
    }
    extra.push({ y: S.core.y + 12, k: 'core', r: null });

    var items = SW.collectVisible(cam, extra);
    for (i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.k === 'a') ACT.drawAlien(it.r, t);
      else if (it.k === 'p') ACT.drawPlayer(it.r, t);
      else if (it.k === 'b') RND.drawBuilding(it.r, t);
      else if (it.k === 'core') RND.drawCore(t);
      else SW.drawSceneryItem(ctx, it, t);
    }

    ACT.drawBullets();
    ACT.drawParts();
    if (ghostKind && S.mode !== 'client') RND.drawGhost(ghostKind, ghostX, ghostY);
    ACT.drawTexts();
    ctx.restore();

    night(t);
  }

  function setGhost(kind, x, y) { ghostKind = kind; ghostX = x; ghostY = y; }
  function clearGhost() { ghostKind = null; }

  return { draw: draw, setGhost: setGhost, clearGhost: clearGhost };
})();
