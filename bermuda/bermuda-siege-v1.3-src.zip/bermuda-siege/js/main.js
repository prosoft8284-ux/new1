/* BERMUDA SIEGE — boot, session glue, loop */
(function () {
  'use strict';
  var S = SG.S;
  var cv, game;
  var qs, SOLO = true, MODE = 'solo', NAME = 'بازمانده', SKIN = 0, ROOM = '', SRV = '';
  var lastT = 0, lobbyEl = null, endShown = false;
  var roster = [];

  function init() {
    qs = new URLSearchParams(location.search);
    SOLO = qs.get('solo') === '1' || (qs.get('mode') || 'solo') === 'solo';
    MODE = SOLO ? 'solo' : qs.get('mode');
    NAME = (qs.get('name') || 'بازمانده').slice(0, 12);
    SKIN = +(qs.get('skin') || 0);
    ROOM = (qs.get('room') || '').toUpperCase();
    SRV = qs.get('srv') || '';
    game = document.getElementById('game');
    cv = document.getElementById('cv');

    HUD.init();
    window.addEventListener('pointerdown', function () { SFX.unlock(); }, { once: true });
    window.addEventListener('keydown', function () { SFX.unlock(); }, { once: true });

    SW.boot(function (msg, i, n) {
      HUD.bootProgress(msg, (i || 0) / (n || 1));
    }, ready);
  }

  function ready() {
    S.ready = true;
    RND.attach(cv);
    INPUT.init(cv);
    if (SOLO) {
      SG.reset({ mode: 'solo' });
      S.localId = 1;
      SG.addPlayer(1, NAME, SKIN);
      SIM.start();
      HUD.bootDone();
      HUD.setNet('تک‌نفره', false);
      HUD.banner('محاصرهٔ برمودا', 'روزها بساز، شب‌ها دوام بیار.', '#64e0ff');
      loop(0);
      return;
    }
    connectNet();
  }

  /* ---------------- networking ---------------- */
  function connectNet() {
    HUD.bootProgress('اتصال به سرور محلی…', 0.98);
    if (SRV) NET.setServer(SRV);
    NET.connect(function () {
      NET.join(ROOM, NAME, SKIN);
    });
    NET.on('hello', function (h) {
      HUD.bootDone();
      if (NET.host) startHost(); else startClient();
    });
    NET.on('room', function (r) {
      roster = r.players || [];
      if (S.mode === 'host') hostRoster(roster);
      lobbyUI();
    });
    NET.on('msg', onMsg);
    NET.on('status', function (st) {
      if (st.status === 'error') {
        HUD.bootProgress(st.err || 'خطای شبکه', 0.2);
        setTimeout(function () { location.href = 'index.html'; }, 2600);
      }
    });
    setTimeout(function () {
      if (!S.ready || S.mode !== 'client' && S.mode !== 'host') return;
    }, 4000);
  }

  function startHost() {
    SG.reset({ mode: 'host', count: 1 });
    S.localId = NET.id;
    SG.addPlayer(NET.id, NAME, SKIN);
    S.onSnap = function (snap) { NET.broadcast({ t: 'snap', d: snap }); };
    HUD.setNet('میزبان — اتاق ' + ROOM, true);
    HUD.bootDone();
    lobbyUI();
    loop(0);
  }

  function startClient() {
    SG.reset({ mode: 'client' });
    S.localId = NET.id;
    SG.addPlayer(NET.id, NAME, SKIN);
    S.onSend = function (inp) {
      if (!inp) return;
      NET.broadcast({
        t: 'in', n: NAME, sk: SKIN,
        m: [+(inp.mx || 0).toFixed(2), +(inp.my || 0).toFixed(2)],
        a: +(inp.a || 0).toFixed(2),
        f: inp.f ? 1 : 0, g: inp.g ? 1 : 0, r: inp.r ? 1 : 0,
        b: inp.b || null
      });
      inp.b = null;
    };
    HUD.setNet('کلاینت — اتاق ' + ROOM, true);
    HUD.bootDone();
    lobbyUI();
    loop(0);
  }

  function hostRoster(list) {
    var i, m;
    for (i = 0; i < list.length; i++) {
      m = list[i];
      if (m.id === S.localId) continue;
      if (!SG.playerById(m.id)) SG.addPlayer(m.id, m.name, m.skin || 0);
    }
    // drop players that left and keep the core in step with the team size
    for (i = S.players.length - 1; i >= 0; i--) {
      var p = S.players[i];
      if (p.id === S.localId) continue;
      var found = false;
      for (var j = 0; j < list.length; j++) if (list[j].id === p.id) found = true;
      if (!found) S.players.splice(i, 1);
    }
    var want = 1800 + 400 * Math.max(0, list.length - 1);
    if (want > S.core.max) S.core.hp += want - S.core.max;
    S.core.max = want;
  }

  function onMsg(m) {
    var d = m && m.d;
    if (!d) return;
    if (d.t === 'snap' && S.mode === 'client') {
      SIM.applySnapshot(d.d);
      if (S.started && lobbyEl) hideLobby();
    } else if (d.t === 'in' && S.mode === 'host') {
      var p = SG.playerById(m.from);
      if (!p) p = SG.addPlayer(m.from, d.n || 'بازمانده', d.sk || 0);
      if (!p) return;
      p.in = {
        mx: d.m[0], my: d.m[1], a: d.a,
        f: !!d.f, g: !!d.g, r: !!d.r,
        b: d.b || null
      };
    }
  }

  /* ---------------- lobby ---------------- */
  function lobbyUI() {
    if (S.started) return;
    if (!lobbyEl) {
      lobbyEl = document.createElement('div');
      lobbyEl.id = 'lobby';
      lobbyEl.innerHTML =
        '<h2>اتاق <span id="lobbyCode"></span></h2>' +
        '<p id="lobbyMsg">در انتظار بازیکن‌ها…</p>' +
        '<div id="lobbyList"></div>' +
        '<button id="lobbyStart">شروع محاصره</button>' +
        '<small>هر دو دستگاه باید به یک وای‌فای وصل باشند.</small>';
      game.appendChild(lobbyEl);
      document.getElementById('lobbyStart').onclick = function () {
        if (!NET.host) { HUD.toast('فقط میزبان می‌تواند بازی را شروع کند'); return; }
        SIM.start();
        hideLobby();
        HUD.banner('شب در راه است', 'تا غروب منابع جمع کنید و دیوار بکشید.', '#ffd479');
      };
    }
    var code = document.getElementById('lobbyCode');
    if (code) code.textContent = ROOM || '—';
    var list = document.getElementById('lobbyList');
    if (list) {
      var html = '';
      for (var i = 0; i < roster.length; i++) {
        html += '<div class="row"><i style="background:' + SG.COLORS[(roster[i].skin || 0) % 6] + '"></i>' +
          roster[i].name + (roster[i].host ? ' <b>میزبان</b>' : '') + '</div>';
      }
      list.innerHTML = html || '<div class="row">شما…</div>';
    }
    var msg = document.getElementById('lobbyMsg');
    if (msg) msg.textContent = roster.length > 1 ? (roster.length + ' بازمانده آماده‌اند') : 'در انتظار بازیکن‌ها…';
    var btn = document.getElementById('lobbyStart');
    if (btn) btn.style.display = NET.host ? 'block' : 'none';
  }

  function hideLobby() {
    if (lobbyEl) { lobbyEl.classList.add('hide'); }
  }

  /* ---------------- loop ---------------- */
  function loop(ts) {
    var dt = lastT ? Math.min(0.05, (ts - lastT) / 1000) : 0.016;
    lastT = ts || 1;

    INPUT.update(dt);
    if (S.mode === 'client') SIM.ease(dt); else SIM.update(dt);

    FRAME.draw(dt, ts || 0);
    HUD.update(dt);

    var p = SG.me();
    if (p) SFX.listener(p.x, p.y);

    if (S.started && lobbyEl && !lobbyEl.classList.contains('hide')) hideLobby();
    if (S.over && !endShown) { endShown = true; setTimeout(showEnd, 1400); }

    requestAnimationFrame(loop);
  }

  function showEnd() {
    if (lobbyEl) lobbyEl.remove();
    lobbyEl = document.createElement('div');
    lobbyEl.id = 'lobby';
    lobbyEl.innerHTML =
      '<h2>' + (S.win ? 'جزیره آزاد شد' : 'هسته سقوط کرد') + '</h2>' +
      '<p>' + (S.win ? 'سه شب دوام آوردید. ' + HUD.digits(S.kills) + ' بیگانه نابود شد.'
        : 'تا شب ' + HUD.digits(Math.max(1, S.nights)) + ' دوام آوردید. ' + HUD.digits(S.kills) + ' بیگانه نابود شد.') + '</p>' +
      '<button id="endBack">بازگشت به لابی</button>';
    game.appendChild(lobbyEl);
    document.getElementById('endBack').onclick = function () { location.href = 'index.html'; };
  }

  window.addEventListener('load', init);
})();
