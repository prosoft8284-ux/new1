/* BERMUDA SIEGE — input (keyboard + mouse, twin-stick touch) */
window.INPUT = (function () {
  'use strict';
  var S = SG.S, cam = RND.cam;
  var keys = {};
  var mouse = { x: 0, y: 0, down: false, inside: false };
  var sticks = {};          // pointerId -> {mode:'move'|'aim', ox, oy, x, y}
  var move = { x: 0, y: 0 };
  var aimLock = null;
  var fire = false;
  var placeT = 0;
  var onPlace = null;
  var elStick = { move: null, aim: null };

  var inp = { mx: 0, my: 0, a: -Math.PI / 2, f: false, g: false, r: false, b: null };
  var world = { x: 0, y: 0 };

  function screenToWorld(sx, sy) {
    return {
      x: cam.x + (sx - cam.w / 2) / cam.z,
      y: cam.y + (sy - cam.h / 2) / cam.z
    };
  }

  function homeSticks() {
    if (!elStick.move) return;
    var h = (window.innerHeight || 0), w = (window.innerWidth || 0);
    elStick.move.style.left = '96px';
    elStick.move.style.top = (h - 100) + 'px';
    elStick.aim.style.left = (w - 96) + 'px';
    elStick.aim.style.top = (h - 100) + 'px';
  }

  function stickBase(mode, x, y) {
    var el = elStick[mode];
    if (!el) return;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.classList.add('on');
  }

  function stickKnob(mode, dx, dy) {
    var el = elStick[mode];
    if (!el) return;
    var k = el.querySelector('i');
    if (!k) return;
    var m = Math.hypot(dx, dy), lim = 34;
    if (m > lim) { dx = dx / m * lim; dy = dy / m * lim; }
    k.style.transform = 'translate(calc(-50% + ' + dx.toFixed(1) + 'px), calc(-50% + ' + dy.toFixed(1) + 'px))';
  }

  function init(canvas) {
    elStick.move = document.getElementById('stickMove');
    elStick.aim = document.getElementById('stickAim');
    var coarse = (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || ('ontouchstart' in window);
    if (coarse) document.body.classList.add('touch');
    homeSticks();
    window.addEventListener('resize', homeSticks);
    canvas.addEventListener('keydown', function () {});
    window.addEventListener('keydown', function (e) {
      keys[e.key.toLowerCase()] = true;
      if (e.key === 'Escape') { HUD.clearSelect(); }
      var k = e.key;
      if (k >= '1' && k <= '5') {
        var kind = SG.BUILD_ORDER[+k - 1];
        if (kind) HUD.toggleSelect(kind);
      }
      if ([' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].indexOf(e.key.toLowerCase()) >= 0) e.preventDefault();
    });
    window.addEventListener('keyup', function (e) { keys[e.key.toLowerCase()] = false; });

    canvas.addEventListener('mousemove', function (e) {
      mouse.x = e.clientX; mouse.y = e.clientY; mouse.inside = true;
    });
    canvas.addEventListener('mousedown', function (e) {
      if (e.button === 2) { HUD.clearSelect(); return; }
      mouse.down = true;
      var k = HUD.selected();
      if (k) { requestPlace(); }
    });
    window.addEventListener('mouseup', function () { mouse.down = false; });
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    canvas.addEventListener('mouseleave', function () { mouse.inside = false; mouse.down = false; });

    canvas.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse') return;
      document.body.classList.add('touch');
      if (e.clientX < cam.w * 0.46) {
        stickBase('move', e.clientX, e.clientY);
        sticks[e.pointerId] = { mode: 'move', ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY };
      } else {
        sticks[e.pointerId] = { mode: 'aim', ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY };
        stickBase('aim', e.clientX, e.clientY);
        var k = HUD.selected();
        if (k) requestPlaceAt(e.clientX, e.clientY);
      }
      canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', function (e) {
      var st = sticks[e.pointerId];
      if (!st) return;
      st.x = e.clientX; st.y = e.clientY;
      stickKnob(st.mode, st.x - st.ox, st.y - st.oy);
      e.preventDefault();
    });
    function up(e) {
      var st = sticks[e.pointerId];
      if (st && elStick[st.mode]) {
        elStick[st.mode].classList.remove('on');
        stickKnob(st.mode, 0, 0);
        homeSticks();
      }
      delete sticks[e.pointerId];
    }
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);

    bindHold(document.getElementById('btnGather'), 'gather');
    bindHold(document.getElementById('btnRepair'), 'repair');
    bindHold(document.getElementById('btnFire'), 'fire');
  }

  var held = { gather: false, repair: false, fire: false };
  function bindHold(node, name) {
    if (!node) return;
    node.addEventListener('pointerdown', function (e) {
      held[name] = true; node.classList.add('on'); e.preventDefault();
    });
    function off() { held[name] = false; node.classList.remove('on'); }
    node.addEventListener('pointerup', off);
    node.addEventListener('pointerleave', off);
    node.addEventListener('pointercancel', off);
  }

  function requestPlaceAt(sx, sy) {
    var w = screenToWorld(sx, sy);
    var kind = HUD.selected();
    if (!kind) return;
    inp.b = [kind, SG.cellOf(w.x), SG.cellOf(w.y)];
    placeT = 0.18;
  }
  function requestPlace() { if (mouse.inside) requestPlaceAt(mouse.x, mouse.y); }

  function update(dt) {
    var p = SG.me();
    if (!p) return;

    var mx = 0, my = 0;
    if (keys['a'] || keys['arrowleft']) mx -= 1;
    if (keys['d'] || keys['arrowright']) mx += 1;
    if (keys['w'] || keys['arrowup']) my -= 1;
    if (keys['s'] || keys['arrowdown']) my += 1;

    var stickMove = { x: 0, y: 0 };
    var stickAim = null;
    for (var pid in sticks) {
      var st = sticks[pid];
      if (st.mode === 'move') {
        var dx = (st.x - st.ox) / 52, dy = (st.y - st.oy) / 52;
        if (Math.hypot(dx, dy) > 1) { var m = Math.hypot(dx, dy); dx /= m; dy /= m; }
        stickMove.x = dx; stickMove.y = dy;
      } else {
        var ad = Math.hypot(st.x - st.ox, st.y - st.oy);
        if (ad > 12) stickAim = Math.atan2(st.y - st.oy, st.x - st.ox);
        else stickAim = null;
      }
    }
    mx += stickMove.x; my += stickMove.y;
    var mag = Math.hypot(mx, my);
    if (mag > 1) { mx /= mag; my /= mag; }

    // aim
    var a = p.aim;
    if (mouse.inside) {
      world = screenToWorld(mouse.x, mouse.y);
      a = Math.atan2(world.y - (p.y - 18), world.x - p.x);
    }
    if (stickAim !== null) a = stickAim;
    else if (stickAim === null && Object.keys(sticks).some(function (k2) { return sticks[k2].mode === 'aim'; }) === false && mag > 0.2 && !mouse.inside) {
      a = Math.atan2(my, mx);
    }

    var aimStick = null;
    for (var k4 in sticks) if (sticks[k4].mode === 'aim') aimStick = sticks[k4];
    var firing = !!mouse.down || !!keys[' '] || !!aimStick || held.fire;
    if (HUD.selected()) firing = !!keys[' '] || !!aimStick;

    inp.mx = mx; inp.my = my; inp.a = a;
    inp.f = !!firing;
    inp.g = !!keys['e'] || held.gather;
    inp.r = !!keys['r'] || held.repair;

    // continuous placement while dragging
    placeT -= dt;
    if (HUD.selected() && mouse.down && mouse.inside && placeT <= 0) requestPlace();

    // the local survivor always reads this object
    p.in = inp;

    var ghostKind = HUD.selected();
    if (ghostKind && (mouse.inside || stickAim !== null)) {
      var gp = stickAim !== null ? { x: p.x + Math.cos(a) * 90, y: p.y + Math.sin(a) * 90 } :
        screenToWorld(mouse.x, mouse.y);
      FRAME.setGhost(ghostKind, SG.cellOf(gp.x), SG.cellOf(gp.y));
    } else if (!ghostKind) FRAME.clearGhost();
  }

  return { init: init, update: update, inp: inp, held: held, screenToWorld: screenToWorld, keys: keys,
    homeSticks: homeSticks };
})();
