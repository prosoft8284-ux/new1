import { useMemo } from "react";
import * as THREE from "three";
import { brick, earth, felt, flame, glow, plaster, starfield, stone, wood } from "./paint";

export type V3 = [number, number, number];
export const INK = "#120c16";

const OUTLINE = new THREE.MeshBasicMaterial({ color: INK, side: THREE.BackSide });

function withRepeat(tex: THREE.Texture, repeat: [number, number]) {
  const t = tex.clone();
  t.needsUpdate = true;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat[0], repeat[1]);
  return t;
}

function useMat(tex: THREE.Texture | null, repeat: [number, number] = [1, 1], tint = "#ffffff") {
  return useMemo(
    () =>
      new THREE.MeshLambertMaterial({
        map: tex ? withRepeat(tex, repeat) : null,
        color: tint,
      }),
    [tex, repeat[0], repeat[1], tint]
  );
}

type Common = {
  position?: V3;
  rotation?: V3;
  outline?: number;
  color?: string;
  map?: THREE.Texture | null;
  repeat?: [number, number];
};

export const Box = ({
  size,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  map = null,
  repeat = [1, 1],
  color = "#ffffff",
  outline = 1.012,
}: Common & { size: V3 }) => {
  const material = useMat(map, repeat, color);
  return (
    <group position={position} rotation={rotation}>
      <mesh material={material}>
        <boxGeometry args={size} />
      </mesh>
      {outline > 0 && (
        <mesh material={OUTLINE} scale={[outline, outline, outline]}>
          <boxGeometry args={size} />
        </mesh>
      )}
    </group>
  );
};

export const Cyl = ({
  rTop,
  rBottom,
  height,
  seg = 20,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  map = null,
  repeat = [1, 1],
  color = "#ffffff",
  outline = 1.014,
}: Common & { rTop: number; rBottom: number; height: number; seg?: number }) => {
  const material = useMat(map, repeat, color);
  return (
    <group position={position} rotation={rotation}>
      <mesh material={material}>
        <cylinderGeometry args={[rTop, rBottom, height, seg]} />
      </mesh>
      {outline > 0 && (
        <mesh material={OUTLINE} scale={[outline, outline, outline]}>
          <cylinderGeometry args={[rTop, rBottom, height, seg]} />
        </mesh>
      )}
    </group>
  );
};

export const Dome = ({
  radius,
  position = [0, 0, 0],
  color = "#ffffff",
  map = null,
  repeat = [1, 1],
  outline = 1.015,
  widthSeg = 24,
}: Common & { radius: number; widthSeg?: number }) => {
  const material = useMat(map, repeat, color);
  return (
    <group position={position}>
      <mesh material={material}>
        <sphereGeometry args={[radius, widthSeg, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
      </mesh>
      {outline > 0 && (
        <mesh material={OUTLINE} scale={[outline, outline, outline]}>
          <sphereGeometry args={[radius, widthSeg, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
        </mesh>
      )}
    </group>
  );
};

const TEX = {
  sand: () => plaster("#d9b785", "#b08a5d"),
  sandPale: () => plaster("#e4c79a", "#bb9a6c"),
  ochre: () => plaster("#c79a63", "#a2764a"),
  brickWarm: () => brick("#b5643f", "#8d5334"),
  brickPale: () => brick("#c9a066", "#a07c4c"),
  stone: () => stone("#9a9184"),
  stoneDark: () => stone("#6f6a62"),
  earth: () => earth("#a98a5f", "#8b9a58"),
  earthNight: () => earth("#5d5540", "#4c5c3c"),
  felt: () => felt("#e2d3b4"),
  wood: () => wood("#8a6238"),
  fire: () => glow("rgba(255,214,120,0.95)", "rgba(255,90,20,0)"),
  smoke: () => glow("rgba(70,58,62,0.55)", "rgba(40,32,38,0)"),
  shadow: () => glow("rgba(20,14,20,0.55)", "rgba(20,14,20,0)", true),
  sun: () => glow("rgba(255,236,190,1)", "rgba(255,180,90,0)"),
};

export type SkyMode = "day" | "golden" | "night" | "stars";

const SKIES: Record<SkyMode, { top: string; bottom: string; exp: number; stars: number; fog: string; fogNear: number; fogFar: number }> = {
  day: { top: "#3e7fd2", bottom: "#b8d0ec", exp: 0.85, stars: 0, fog: "#b8d0ec", fogNear: 60, fogFar: 430 },
  golden: { top: "#ffc47c", bottom: "#8a6f8a", exp: 1.15, stars: 0, fog: "#d99a76", fogNear: 55, fogFar: 420 },
  night: { top: "#12162c", bottom: "#3a2b3c", exp: 1.0, stars: 0.55, fog: "#241f33", fogNear: 50, fogFar: 400 },
  stars: { top: "#0a0d1d", bottom: "#1d2138", exp: 0.9, stars: 1, fog: "#161a2b", fogNear: 60, fogFar: 430 },
};

const skyVert = `
varying vec3 vPos;
void main() {
  vPos = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;

const skyFrag = `
uniform vec3 top;
uniform vec3 bottom;
uniform float expo;
varying vec3 vPos;
void main() {
  float h = clamp(vPos.y * 0.5 + 0.5, 0.0, 1.0);
  vec3 c = mix(bottom, top, pow(h, expo));
  gl_FragColor = vec4(c, 1.0);
}`;

export const Sky = ({ mode, frame }: { mode: SkyMode; frame: number }) => {
  const conf = SKIES[mode];
  const uniforms = useMemo(
    () => ({
      top: { value: new THREE.Color(conf.top) },
      bottom: { value: new THREE.Color(conf.bottom) },
      expo: { value: conf.exp },
    }),
    [conf.top, conf.bottom, conf.exp]
  );
  const starGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const n = 900;
    const pos = new Float32Array(n * 3);
    let seed = 7;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < n; i++) {
      const a = rnd() * Math.PI * 2;
      const h = 0.08 + rnd() * 0.9;
      const r = Math.sqrt(1 - h * h);
      pos[i * 3] = Math.cos(a) * r * 900;
      pos[i * 3 + 1] = h * 900;
      pos[i * 3 + 2] = Math.sin(a) * r * 900;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);

  const starMat = useMemo(
    () =>
      new THREE.PointsMaterial({
        color: "#eef2ff",
        size: 3.2,
        sizeAttenuation: false,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      }),
    []
  );

  return (
    <group>
      <mesh scale={[900, 900, 900]}>
        <sphereGeometry args={[1, 24, 16]} />
        <shaderMaterial
          uniforms={uniforms}
          vertexShader={skyVert}
          fragmentShader={skyFrag}
          side={THREE.BackSide}
          depthWrite={false}
        />
      </mesh>
      {conf.stars > 0 && <points geometry={starGeo} material={starMat} />}
      <fog attach="fog" args={[conf.fog, conf.fogNear, conf.fogFar]} />
    </group>
  );
};

export const Lights = ({ mode }: { mode: SkyMode }) => {
  const conf =
    mode === "day"
      ? { amb: "#cfe2ff", ambI: 1.5, key: "#fff3d6", keyI: 2.0, dir: [0.6, 1, 0.4] }
      : mode === "golden"
      ? { amb: "#8f7bb0", ambI: 1.15, key: "#ffb36b", keyI: 2.6, dir: [-0.7, 0.28, 0.5] }
      : { amb: "#5d5a86", ambI: 1.5, key: "#a8bcff", keyI: 1.2, dir: [0.4, 0.8, -0.3] };
  return (
    <group>
      <ambientLight color={conf.amb} intensity={conf.ambI} />
      <directionalLight color={conf.key} intensity={conf.keyI} position={conf.dir as any} />
      <directionalLight color={conf.amb} intensity={0.5} position={[-1, 0.4, -0.6]} />
    </group>
  );
};

export const Sun = ({ position, scale = 90, color }: { position: V3; scale?: number; color?: string }) => {
  const tex = useMemo(() => TEX.sun(), []);
  return (
    <sprite position={position} scale={[scale, scale, 1]}>
      <spriteMaterial map={tex} transparent depthWrite={false} color={color ?? "#ffffff"} />
    </sprite>
  );
};

export const Ground = ({ night }: { night?: boolean }) => {
  const tex = night ? TEX.earthNight() : TEX.earth();
  const material = useMat(tex, [130, 130]);
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} material={material}>
      <planeGeometry args={[1600, 1600]} />
    </mesh>
  );
};

export const Mountains = () => {
  const material = useMemo(() => new THREE.MeshLambertMaterial({ color: "#6d6a8c" }), []);
  const peaks = useMemo(() => {
    const out: { p: V3; r: number; h: number }[] = [];
    let seed = 21;
    const rnd = () => {
      seed = (seed * 48271) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * Math.PI * 2 + rnd() * 0.12;
      const d = 470 + rnd() * 200;
      out.push({ p: [Math.cos(a) * d, 0, Math.sin(a) * d], r: 80 + rnd() * 90, h: 55 + rnd() * 60 });
    }
    return out;
  }, []);
  return (
    <group>
      {peaks.map((k, i) => (
        <mesh key={i} position={[k.p[0], k.h / 2 - 8, k.p[2]]} material={material}>
          <coneGeometry args={[k.r, k.h, 7]} />
        </mesh>
      ))}
    </group>
  );
};

const Fire = ({ origin, frame, count = 7, spread = 1 }: { origin: V3; frame: number; count?: number; spread?: number }) => {
  const fire = useMemo(() => flame(), []);
  const smoke = useMemo(() => TEX.smoke(), []);
  const items = useMemo(() => {
    const out: { x: number; y: number; z: number; s: number; ph: number }[] = [];
    let seed = 33 + Math.round(origin[0]);
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < count; i++) {
      out.push({
        x: (rnd() - 0.5) * 22 * spread,
        y: rnd() * 7 * spread,
        z: (rnd() - 0.5) * 16 * spread,
        s: 0.9 + rnd() * 1.1,
        ph: rnd() * Math.PI * 2,
      });
    }
    return out;
  }, [count, spread, origin[0]]);
  return (
    <group position={origin}>
      {items.map((it, i) => {
        const flick = 0.85 + 0.25 * Math.sin(frame * 0.35 + it.ph);
        const rise = ((frame * 0.06 + it.ph * 3) % 16) * 1.1;
        const smokeScale = 3 + rise * 0.5;
        return (
          <group key={i} position={[it.x, it.y, it.z]}>
            <sprite position={[0, it.s * 0.4, 0]} scale={[it.s * 2.6 * flick, it.s * 2.2 * flick, 1]}>
              <spriteMaterial map={fire} transparent depthWrite={false} blending={THREE.AdditiveBlending} opacity={0.35} />
            </sprite>
            <sprite position={[0, it.s * 0.75, 0]} scale={[it.s * 0.75 * flick, it.s * 1.9 * flick, 1]}>
              <spriteMaterial map={fire} transparent depthWrite={false} blending={THREE.AdditiveBlending} opacity={0.9} />
            </sprite>
            <sprite position={[0, 4 + rise, 0]} scale={[smokeScale * 0.45, smokeScale * 0.6, 1]}>
              <spriteMaterial map={smoke} transparent depthWrite={false} opacity={Math.max(0, 0.32 - rise * 0.015)} />
            </sprite>
          </group>
        );
      })}
      <pointLight color="#ff8a3c" intensity={6} distance={110} position={[0, 8, 0]} />
    </group>
  );
};

const Shadow = ({ at, size = 2.2 }: { at: V3; size?: number }) => {
  const tex = useMemo(() => TEX.shadow(), []);
  return (
    <sprite position={[at[0], 0.08, at[2]]} rotation={[-Math.PI / 2, 0, 0]} scale={[size, size, 1]}>
      <spriteMaterial map={tex} transparent depthWrite={false} opacity={0.75} />
    </sprite>
  );
};

type House = { p: V3; s: V3; rot?: number; pale?: boolean };

const HOUSES: House[] = [
  { p: [-22, 0, -14], s: [9, 7, 9], pale: true },
  { p: [-9, 0, -22], s: [8, 8, 8] },
  { p: [6, 0, -20], s: [8, 6.5, 8], pale: true },
  { p: [20, 0, -16], s: [9, 7.5, 9] },
  { p: [30, 0, -4], s: [8, 6.5, 8], pale: true },
  { p: [-32, 0, -2], s: [8, 7, 9] },
  { p: [-24, 0, 10], s: [7, 6, 7], pale: true },
  { p: [-6, 0, 4], s: [7, 5.5, 7], pale: true },
  { p: [14, 0, 2], s: [7, 6, 7] },
  { p: [26, 0, 12], s: [8, 6.5, 8] },
  { p: [-40, 0, -18], s: [9, 8, 9], pale: true },
  { p: [38, 0, -20], s: [9, 7.5, 9] },
];

export const Town = ({ burning, frame }: { burning?: boolean; frame: number }) => {
  const sand = TEX.sand();
  const pale = TEX.sandPale();
  const ochre = TEX.ochre();
  const bricks = TEX.brickWarm();
  return (
    <group>
      {HOUSES.map((h, i) => {
        const rep: [number, number] = [Math.max(1, Math.round(h.s[0] / 3)), Math.max(1, Math.round(h.s[1] / 3))];
        const windows: number[] = [-h.s[0] * 0.22, h.s[0] * 0.22];
        return (
          <group key={i}>
            <Box
              size={h.s}
              position={[h.p[0], h.s[1] / 2, h.p[2]]}
              map={h.pale ? pale : sand}
              repeat={rep}
              color={burning ? "#8d7a6e" : "#ffffff"}
            />
            {/* plinth */}
            <Box
              size={[h.s[0] + 0.3, 0.8, h.s[2] + 0.3]}
              position={[h.p[0], 0.4, h.p[2]]}
              map={ochre}
              repeat={[3, 1]}
              color={burning ? "#7a6a64" : "#e3d2b0"}
              outline={0}
            />
            {/* windows and a door on the front face */}
            {windows.map((wx, k) => (
              <group key={k}>
                <Box
                  size={[1.35, 1.65, 0.2]}
                  position={[h.p[0] + wx, h.s[1] * 0.6, h.p[2] + h.s[2] / 2 + 0.06]}
                  map={null}
                  color={burning ? "#c9a97e" : "#efe0bd"}
                  outline={0}
                />
                <Box
                  size={[0.95, 1.25, 0.3]}
                  position={[h.p[0] + wx, h.s[1] * 0.6, h.p[2] + h.s[2] / 2 + 0.12]}
                  map={null}
                  color={burning ? "#2a1a1c" : "#3a2b30"}
                  outline={0}
                />
              </group>
            ))}
            <Box
              size={[1.5, 2.4, 0.4]}
              position={[h.p[0], 1.2, h.p[2] + h.s[2] / 2]}
              map={wood("#6a4a2c")}
              color={burning ? "#4a2a20" : "#5a3a24"}
              outline={0}
            />
            {/* parapet */}
            <Box
              size={[h.s[0] + 0.5, 0.8, h.s[2] + 0.5]}
              position={[h.p[0], h.s[1] + 0.4, h.p[2]]}
              map={ochre}
              repeat={[Math.max(1, Math.round(h.s[0] / 2)), 1]}
              color={burning ? "#7a6a60" : "#ffffff"}
            />
            {/* roof mass */}
            <Box
              size={[h.s[0] * 0.5, 1.4, h.s[2] * 0.5]}
              position={[h.p[0], h.s[1] + 1.5, h.p[2]]}
              map={bricks}
              repeat={[2, 1]}
              color={burning ? "#6d5a52" : "#ffffff"}
            />
          </group>
        );
      })}
      {/* minaret */}
      <Cyl rBottom={3.2} rTop={2.2} height={16} position={[-12, 8, -18]} map={bricks} repeat={[3, 5]} />
      <Cyl rBottom={2.6} rTop={2.6} height={0.6} position={[-12, 15.6, -18]} map={TEX.brickPale()} />
      <Dome radius={2.5} position={[-12, 15.9, -18]} color="#4f8f86" />
      {/* big dome on the prayer hall */}
      <Box size={[13, 7, 13]} position={[-12, 3.5, -18]} map={sand} repeat={[4, 2]} />
      <Dome radius={5.6} position={[-12, 7, -18]} color="#4f8f86" widthSeg={22} />
      {/* city wall at the back */}
      <Box size={[70, 6, 2]} position={[0, 3, -34]} map={bricks} repeat={[8, 1]} color={burning ? "#7d6a60" : "#ffffff"} />
      {burning && (
        <group>
          <Fire origin={[-24, 6, 10]} frame={frame} count={3} spread={0.45} />
          <Fire origin={[-6, 5.5, 4]} frame={frame} count={3} spread={0.45} />
          <Fire origin={[14, 6, 2]} frame={frame} count={3} spread={0.45} />
          <Fire origin={[26, 6.5, 12]} frame={frame} count={2} spread={0.45} />
          <Fire origin={[-9, 8, -22]} frame={frame} count={2} spread={0.45} />
          <Fire origin={[-12, 16, -18]} frame={frame} count={2} spread={0.3} />
        </group>
      )}
      <Shadow at={[0, 0, 0]} size={30} />
    </group>
  );
};

export const Fortress = ({ frame, lights }: { frame: number; lights?: boolean }) => {
  const rock = TEX.stoneDark();
  const wall = TEX.stone();
  const bricks = TEX.brickPale();
  const towers: V3[] = [
    [-11, 0, -11],
    [11, 0, -11],
    [-11, 0, 11],
    [11, 0, 11],
    [0, 0, -14],
    [0, 0, 14],
  ];
  return (
    <group position={[120, 0, -40]}>
      {/* the rock of Alamut: a few stacked masses so it reads as a crag, not a vase */}
      <Cyl rTop={15} rBottom={21} height={26} position={[0, 13, 0]} map={rock} repeat={[4, 3]} outline={1.012} color="#a89f92" />
      <Cyl rTop={9} rBottom={18} height={18} position={[-12, 9, 7]} map={rock} repeat={[3, 2]} color="#7a7268" />
      <Cyl rTop={8} rBottom={16} height={15} position={[13, 7.5, 6]} map={rock} repeat={[3, 2]} color="#948c80" />
      <Cyl rTop={7} rBottom={13} height={11} position={[2, 5.5, 14]} map={rock} repeat={[2, 2]} color="#847c72" />
      <Cyl rTop={15} rBottom={16} height={3} position={[0, 27.5, 0]} map={rock} repeat={[4, 1]} />
      {/* curtain wall */}
      {[
        [0, 0, -13, 30, 1.6],
        [0, 0, 13, 30, 1.6],
        [-13, 0, 0, 1.6, 26],
        [13, 0, 0, 1.6, 26],
      ].map((w, i) => (
        <group key={i}>
          <Box size={[w[3], 6.2, w[4]]} position={[w[0], 32.1, w[2]]} map={bricks} repeat={[8, 2]} />
          {/* crenellations */}
          {Array.from({ length: 9 }).map((_, k) => {
            const u = -1 + (k / 8) * 2;
            const x = w[3] > w[4] ? u * 13 : w[0];
            const z = w[3] > w[4] ? w[2] : u * 11;
            return (
              <Box
                key={k}
                size={[1.5, 1.1, 1.5]}
                position={[x, 35.7, z]}
                map={bricks}
                color="#c8a98a"
                outline={0}
              />
            );
          })}
        </group>
      ))}
      {towers.map((t, i) => (
        <group key={i}>
          <Cyl rBottom={2.6} rTop={2.4} height={9} position={[t[0], 33.5, t[2]]} map={wall} repeat={[2, 3]} />
          <Cyl rBottom={2.9} rTop={2.9} height={1.1} position={[t[0], 38.5, t[2]]} map={bricks} />
          <mesh position={[t[0], 41.2, t[2]]}>
            <coneGeometry args={[3.2, 4.2, 8]} />
            <meshLambertMaterial color="#6f5f7e" />
          </mesh>
        </group>
      ))}
      {/* keep */}
      <Box size={[11, 10, 11]} position={[0, 36, -4]} map={bricks} repeat={[3, 3]} />
      <Box size={[12.4, 1.1, 12.4]} position={[0, 41.5, -4]} map={wall} />
      <Dome radius={5.4} position={[0, 41.8, -4]} color="#4f8f86" />
      {/* gate */}
      <Box size={[5, 6, 1.6]} position={[0, 30.5, 13.6]} map={wood("#6a4a2c")} color="#3a2a20" />
      {lights && <Fire origin={[0, 30, 12]} frame={frame} count={2} spread={0.4} />}
    </group>
  );
};

export const Camp = ({ frame }: { frame: number }) => {
  const feltTex = TEX.felt();
  const woodTex = TEX.wood();
  return (
    <group position={[-120, 0, 30]}>
      <Cyl rBottom={3.4} rTop={3.2} height={2.9} position={[0, 1.45, 0]} map={feltTex} repeat={[4, 2]} />
      <Cyl rBottom={3.7} rTop={0.25} height={2.1} position={[0, 3.9, 0]} map={feltTex} repeat={[4, 1]} />
      <Cyl rBottom={3.3} rTop={3.3} height={0.35} position={[0, 2.95, 0]} map={woodTex} />
      <Box size={[1.5, 2.1, 0.35]} position={[0, 1.05, 3.35]} map={woodTex} color="#5a3a24" />
      {/* carpets and a low table outside */}
      <Box size={[4.4, 0.12, 3]} position={[5, 0.08, 2.4]} map={TEX.brickPale()} color="#9a3f3a" />
      <Box size={[1.8, 0.4, 1.2]} position={[5, 0.28, 2.4]} map={woodTex} />
      <Dome radius={0.7} position={[4.6, 0.5, 2.5]} color="#c9a978" outline={0} />
      <Shadow at={[0, 0, 0]} size={10} />
    </group>
  );
};

export const Observatory = ({ frame, lit }: { frame: number; lit?: boolean }) => {
  const stoneTex = TEX.stone();
  const bricks = TEX.brickWarm();
  const woodTex = TEX.wood();
  return (
    <group position={[0, 0, -180]}>
      {/* round base */}
      <Cyl rBottom={20} rTop={18} height={7} position={[0, 3.5, 0]} map={stoneTex} repeat={[8, 2]} />
      <Cyl rBottom={18.4} rTop={18.4} height={0.9} position={[0, 7.4, 0]} map={bricks} repeat={[10, 1]} />
      {/* drum */}
      <Cyl rBottom={16} rTop={15} height={6} position={[0, 10.6, 0]} map={stoneTex} repeat={[8, 2]} />
      {/* dome */}
      <Dome radius={15} position={[0, 13.4, 0]} color="#7f8fa0" />
      {/* the mural quadrant, off to one side so it reads as an instrument */}
      <group position={[-15, 0, 8]} rotation={[0, -0.5, 0]}>
        <Box size={[1.0, 11, 1.0]} position={[-7, 5.5, 0]} map={woodTex} color="#c39a6a" />
        <Box size={[1.0, 11, 1.0]} position={[7, 5.5, 0]} map={woodTex} color="#c39a6a" />
        <mesh position={[0, 8, 0]} rotation={[0, 0, 0]}>
          <torusGeometry args={[7, 0.5, 8, 20, Math.PI]} />
          <meshLambertMaterial color="#c8a55e" />
        </mesh>
        <mesh position={[0, 8, 0.4]} rotation={[0, 0, Math.PI / 4]}>
          <boxGeometry args={[9.8, 0.12, 0.12]} />
          <meshLambertMaterial color="#efe0bd" />
        </mesh>
      </group>
      {/* dark cap where the meridian slit would be */}
      <Cyl rBottom={2.2} rTop={0.6} height={1.6} position={[0, 29.2, 0]} map={null} color="#2b3347" outline={0} />
      {/* library wing */}
      <Box size={[16, 8, 12]} position={[26, 4, -6]} map={bricks} repeat={[4, 2]} />
      <Dome radius={5.5} position={[26, 8, -6]} color="#b07a4a" />
      <Box size={[17, 0.8, 13]} position={[26, 8.2, -6]} map={stoneTex} />
      {/* door */}
      <Box size={[3.2, 4.6, 0.8]} position={[0, 2.3, 17.6]} map={woodTex} color="#4a3020" />
      {lit && <Fire origin={[0, 6, 14]} frame={frame} count={2} spread={0.3} />}
      <Shadow at={[0, 0, 0]} size={44} />
    </group>
  );
};

/** Tusi couple: a small circle rolling inside a circle of twice the radius traces a straight line. */
export const Rings = ({ frame, startFrame }: { frame: number; startFrame: number }) => {
  const t = Math.max(0, frame - startFrame) / 30;
  const R = 9;
  const r = R / 2;
  const theta = t * 1.15;
  const cx = Math.cos(theta) * (R - r);
  const cy = Math.sin(theta) * (R - r);
  const spokeA = theta;
  const px = cx + Math.cos(-spokeA) * r;
  const py = cy + Math.sin(-spokeA) * r;
  return (
    <group position={[260, 12, 0]}>
      {/* big ring */}
      <mesh>
        <torusGeometry args={[R, 0.22, 10, 96]} />
        <meshBasicMaterial color="#e9d8b0" />
      </mesh>
      <mesh>
        <torusGeometry args={[R, 0.32, 10, 96]} />
        <meshBasicMaterial color={INK} side={THREE.BackSide} />
      </mesh>
      {/* the straight line the point travels on */}
      <mesh position={[0, -py * 0, 0]}>
        <boxGeometry args={[0.12, 0.12, 0.12]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      <mesh>
        <boxGeometry args={[R * 2 - 0.4, 0.06, 0.06]} />
        <meshBasicMaterial color="rgba(255,240,200,0.55)" transparent opacity={0.55} />
      </mesh>
      {/* rolling small circle */}
      <group position={[cx, cy, 0]}>
        <mesh>
          <torusGeometry args={[r, 0.16, 10, 64]} />
          <meshBasicMaterial color="#7fd6c8" />
        </mesh>
        {/* its diameter, rotating */}
        <mesh rotation={[0, 0, spokeA]}>
          <boxGeometry args={[r * 2, 0.09, 0.09]} />
          <meshBasicMaterial color="#bfeee6" />
        </mesh>
      </group>
      {/* traced point */}
      <mesh position={[px, py, 0.02]}>
        <sphereGeometry args={[0.42, 16, 12]} />
        <meshBasicMaterial color="#ffd479" />
      </mesh>
      <mesh position={[0, 0, -0.1]}>
        <circleGeometry args={[R + 0.6, 64]} />
        <meshBasicMaterial color="#0d1124" transparent opacity={0.85} />
      </mesh>
    </group>
  );
};
