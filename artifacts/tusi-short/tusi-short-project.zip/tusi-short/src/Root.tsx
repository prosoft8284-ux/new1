import { Composition } from "remotion";
import { Short } from "./Short";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TusiShort"
      component={Short}
      durationInFrames={1800}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
