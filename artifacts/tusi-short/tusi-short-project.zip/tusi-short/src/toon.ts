import * as THREE from "three";

const INK = "#241726";
const PLUM = "#2f1d28";

const cache = new Map<string, THREE.CanvasTexture>();

export type Kind =
  | "tusi"
  | "young"
  | "hulagu"
  | "worker"
  | "scholar"
  | "books"
  | "tablet"
  | "astrolabe"
  | "rider";

type Person = {
  robe: string;
  robeShade: string;
  trim: string;
  skin: string;
  hat: "turban" | "helmet" | "cap" | "bald" | "smallcap";
  hatColor: string;
  beard: "long" | "short" | "none" | "mustache";
  beardColor: string;
  scarf?: string;
};

const PEOPLE: Record<string, Person> = {
  tusi: {
    robe: "#2f6f63",
    robeShade: "#24564d",
    trim: "#ecdcae",
    skin: "#e7b892",
    hat: "turban",
    hatColor: "#2c3c60",
    beard: "long",
    beardColor: "#efeadf",
  },
  young: {
    robe: "#4a6fa8",
    robeShade: "#3a5886",
    trim: "#d8c9a6",
    skin: "#eec19b",
    hat: "cap",
    hatColor: "#8a5a2b",
    beard: "none",
    beardColor: "#2a1f22",
  },
  hulagu: {
    robe: "#8f3b32",
    robeShade: "#71302a",
    trim: "#c8a55e",
    skin: "#dca781",
    hat: "helmet",
    hatColor: "#5b6470",
    beard: "mustache",
    beardColor: "#211a1e",
  },
  worker: {
    robe: "#a8794a",
    robeShade: "#8a613a",
    trim: "#d6c19a",
    skin: "#dfab84",
    hat: "bald",
    hatColor: "#2a1f22",
    beard: "short",
    beardColor: "#3a2a26",
  },
  scholar: {
    robe: "#656a7c",
    robeShade: "#4f5464",
    trim: "#cfc7b6",
    skin: "#e9bb96",
    hat: "smallcap",
    hatColor: "#3a3f52",
    beard: "short",
    beardColor: "#cfc7b6",
  },
};

function persona(kind: string): Person {
  return PEOPLE[kind] ?? PEOPLE.scholar;
}

function stroke(ctx: CanvasRenderingContext2D, w: number, color = INK) {
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.lineWidth = w;
  ctx.strokeStyle = color;
}

function fillStroke(ctx: CanvasRenderingContext2D, fill: string, width = 13) {
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.stroke();
  ctx.lineWidth = width;
}

function drawPerson(ctx: CanvasRenderingContext2D, p: Person) {
  const cx = 300;

  // ---- robe -------------------------------------------------------------
  ctx.beginPath();
  ctx.moveTo(cx - 96, 372);
  ctx.quadraticCurveTo(cx - 128, 640, cx - 122, 936);
  ctx.quadraticCurveTo(cx, 962, cx + 122, 936);
  ctx.quadraticCurveTo(cx + 128, 640, cx + 96, 372);
  ctx.quadraticCurveTo(cx, 340, cx - 96, 372);
  ctx.closePath();
  stroke(ctx, 15);
  ctx.fillStyle = p.robe;
  ctx.fill();
  ctx.stroke();

  // two-tone shade on the right of the robe
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx + 10, 360);
  ctx.quadraticCurveTo(cx + 70, 620, cx + 122, 936);
  ctx.quadraticCurveTo(cx, 962, cx + 4, 946);
  ctx.closePath();
  ctx.fillStyle = p.robeShade;
  ctx.globalAlpha = 0.55;
  ctx.fill();
  ctx.restore();

  // collar trim
  ctx.beginPath();
  ctx.moveTo(cx - 52, 366);
  ctx.lineTo(cx, 470);
  ctx.lineTo(cx + 52, 366);
  ctx.lineWidth = 12;
  ctx.strokeStyle = p.trim;
  ctx.stroke();

  // hem trim
  ctx.beginPath();
  ctx.moveTo(cx - 120, 918);
  ctx.quadraticCurveTo(cx, 944, cx + 120, 918);
  ctx.lineWidth = 10;
  ctx.strokeStyle = p.trim;
  ctx.stroke();

  // ---- feet -------------------------------------------------------------
  for (const dx of [-46, 46]) {
    ctx.beginPath();
    ctx.ellipse(cx + dx, 962, 34, 18, 0, 0, Math.PI * 2);
    stroke(ctx, 12);
    ctx.fillStyle = "#4a3325";
    ctx.fill();
    ctx.stroke();
  }

  // ---- arms -------------------------------------------------------------
  const arm = (from: [number, number], to: [number, number]) => {
    stroke(ctx, 30);
    ctx.beginPath();
    ctx.moveTo(from[0], from[1]);
    ctx.quadraticCurveTo((from[0] + to[0]) / 2 + 18, (from[1] + to[1]) / 2, to[0], to[1]);
    ctx.stroke();
    stroke(ctx, 18);
    ctx.strokeStyle = p.robe;
    ctx.stroke();
    // hand
    ctx.beginPath();
    ctx.arc(to[0], to[1], 15, 0, Math.PI * 2);
    stroke(ctx, 10);
    ctx.fillStyle = p.skin;
    ctx.fill();
    ctx.stroke();
  };
  arm([cx - 92, 400], [cx - 138, 660]);
  arm([cx + 92, 400], [cx + 138, 660]);

  // ---- head -------------------------------------------------------------
  const headY = 236;
  ctx.beginPath();
  ctx.ellipse(cx, headY, 112, 120, 0, 0, Math.PI * 2);
  stroke(ctx, 13);
  ctx.fillStyle = p.skin;
  ctx.fill();
  ctx.stroke();

  // ears
  for (const dx of [-112, 112]) {
    ctx.beginPath();
    ctx.ellipse(cx + dx, headY + 12, 16, 22, 0, 0, Math.PI * 2);
    stroke(ctx, 10);
    ctx.fillStyle = p.skin;
    ctx.fill();
    ctx.stroke();
  }

  // ---- beard ------------------------------------------------------------
  if (p.beard === "long" || p.beard === "short") {
    const long = p.beard === "long";
    ctx.beginPath();
    ctx.moveTo(cx - 86, headY + 44);
    ctx.quadraticCurveTo(cx - 74, headY + (long ? 190 : 132), cx, headY + (long ? 210 : 146));
    ctx.quadraticCurveTo(cx + 74, headY + (long ? 190 : 132), cx + 86, headY + 44);
    ctx.quadraticCurveTo(cx, headY + 118, cx - 86, headY + 44);
    ctx.closePath();
    stroke(ctx, 12);
    ctx.fillStyle = p.beardColor;
    ctx.fill();
    ctx.stroke();
  }
  if (p.beard === "mustache") {
    ctx.beginPath();
    ctx.moveTo(cx - 42, headY + 56);
    ctx.quadraticCurveTo(cx, headY + 76, cx + 42, headY + 56);
    ctx.lineWidth = 14;
    ctx.strokeStyle = p.beardColor;
    ctx.stroke();
  }

  // ---- headwear ---------------------------------------------------------
  if (p.hat === "turban") {
    ctx.beginPath();
    ctx.ellipse(cx, headY - 62, 128, 74, 0, Math.PI, Math.PI * 2);
    stroke(ctx, 13);
    ctx.fillStyle = p.hatColor;
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, headY - 30, 124, 34, 0, Math.PI * 1.06, Math.PI * 1.94);
    ctx.lineWidth = 12;
    ctx.strokeStyle = "#efe9dc";
    ctx.stroke();
    // tail
    ctx.beginPath();
    ctx.moveTo(cx + 96, headY - 46);
    ctx.quadraticCurveTo(cx + 142, headY + 10, cx + 118, headY + 84);
    ctx.lineWidth = 22;
    ctx.strokeStyle = p.hatColor;
    ctx.stroke();
    ctx.lineWidth = 9;
    ctx.strokeStyle = INK;
    ctx.stroke();
  }
  if (p.hat === "helmet") {
    ctx.beginPath();
    ctx.ellipse(cx, headY - 58, 116, 82, 0, Math.PI, Math.PI * 2);
    stroke(ctx, 13);
    ctx.fillStyle = p.hatColor;
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.rect(cx - 124, headY - 52, 248, 18);
    stroke(ctx, 11);
    ctx.fillStyle = "#434a55";
    ctx.fill();
    ctx.stroke();
    // spike
    ctx.beginPath();
    ctx.moveTo(cx, headY - 142);
    ctx.lineTo(cx + 14, headY - 196);
    ctx.lineTo(cx - 14, headY - 196);
    ctx.closePath();
    stroke(ctx, 10);
    ctx.fillStyle = "#c8a55e";
    ctx.fill();
    ctx.stroke();
    // cheek guards
    for (const dx of [-108, 108]) {
      ctx.beginPath();
      ctx.moveTo(cx + dx, headY - 34);
      ctx.lineTo(cx + dx * 0.92, headY + 68);
      ctx.lineWidth = 20;
      ctx.strokeStyle = p.hatColor;
      ctx.stroke();
      ctx.lineWidth = 8;
      ctx.strokeStyle = INK;
      ctx.stroke();
    }
  }
  if (p.hat === "cap") {
    ctx.beginPath();
    ctx.ellipse(cx, headY - 70, 96, 58, 0, Math.PI, Math.PI * 2);
    stroke(ctx, 12);
    ctx.fillStyle = p.hatColor;
    ctx.fill();
    ctx.stroke();
  }
  if (p.hat === "smallcap") {
    ctx.beginPath();
    ctx.ellipse(cx, headY - 84, 82, 44, 0, Math.PI, Math.PI * 2);
    stroke(ctx, 12);
    ctx.fillStyle = p.hatColor;
    ctx.fill();
    ctx.stroke();
  }
  if (p.hat === "bald") {
    ctx.beginPath();
    ctx.ellipse(cx, headY - 78, 88, 34, 0, Math.PI, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.fill();
  }

  // ---- face -------------------------------------------------------------
  const eyeY = headY - 4;
  for (const dx of [-42, 42]) {
    ctx.beginPath();
    ctx.arc(cx + dx, eyeY, 10, 0, Math.PI * 2);
    ctx.fillStyle = "#241726";
    ctx.fill();
  }
  ctx.lineWidth = 9;
  ctx.strokeStyle = PLUM;
  // brows
  for (const dx of [-42, 42]) {
    ctx.beginPath();
    ctx.moveTo(cx + dx - 22, eyeY - 32);
    ctx.lineTo(cx + dx + 18, eyeY - 36);
    ctx.stroke();
  }
  // nose
  ctx.beginPath();
  ctx.moveTo(cx + 2, eyeY + 12);
  ctx.lineTo(cx - 4, eyeY + 32);
  ctx.stroke();
  // mouth
  ctx.beginPath();
  ctx.moveTo(cx - 26, eyeY + 62);
  ctx.quadraticCurveTo(cx, eyeY + 70, cx + 26, eyeY + 62);
  ctx.stroke();
}

function drawBooks(ctx: CanvasRenderingContext2D) {
  const colors = ["#8f3b32", "#2f6f63", "#3f5f8a", "#a8794a", "#6c4a86", "#b8863b"];
  let y = 620;
  colors.forEach((c, i) => {
    const w = 520 - i * 26;
    const h = 74;
    ctx.beginPath();
    ctx.roundRect(450 - w / 2, y - h, w, h, 12);
    stroke(ctx, 12);
    ctx.fillStyle = c;
    ctx.fill();
    ctx.stroke();
    // pages
    ctx.beginPath();
    ctx.rect(450 - w / 2 + 14, y - h + 14, w - 28, h - 28);
    ctx.fillStyle = "#efe6d0";
    ctx.fill();
    ctx.lineWidth = 5;
    ctx.strokeStyle = "rgba(36,23,38,0.5)";
    ctx.stroke();
    y -= h + 4;
  });
  // carrying strap
  ctx.beginPath();
  ctx.moveTo(190, 300);
  ctx.quadraticCurveTo(450, 700, 710, 300);
  ctx.lineWidth = 16;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

function drawTablet(ctx: CanvasRenderingContext2D) {
  ctx.beginPath();
  ctx.roundRect(90, 120, 720, 760, 28);
  stroke(ctx, 16);
  ctx.fillStyle = "#c9a878";
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.roundRect(130, 170, 640, 660, 16);
  ctx.fillStyle = "#d8bb92";
  ctx.fill();
  ctx.lineWidth = 6;
  ctx.strokeStyle = "rgba(36,23,38,0.45)";
  ctx.stroke();
  // grid of numbers
  ctx.strokeStyle = "rgba(36,23,38,0.55)";
  for (let row = 0; row < 12; row++) {
    const y = 230 + row * 48;
    ctx.lineWidth = row === 0 ? 5 : 3;
    ctx.beginPath();
    ctx.moveTo(160, y);
    ctx.lineTo(740, y);
    ctx.stroke();
    for (let col = 0; col < 6; col++) {
      const x = 190 + col * 95;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x, y + 12);
      ctx.lineTo(x + 46, y + 12);
      ctx.moveTo(x + 20, y + 8);
      ctx.lineTo(x + 26, y + 34);
      ctx.stroke();
    }
  }
}

function drawAstrolabe(ctx: CanvasRenderingContext2D) {
  ctx.beginPath();
  ctx.arc(400, 400, 300, 0, Math.PI * 2);
  stroke(ctx, 18);
  ctx.fillStyle = "#c8a55e";
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(400, 400, 240, 0, Math.PI * 2);
  ctx.lineWidth = 8;
  ctx.strokeStyle = "#6d4f22";
  ctx.stroke();
  for (let i = 0; i < 36; i++) {
    const a = (i / 36) * Math.PI * 2;
    const r1 = i % 3 === 0 ? 205 : 222;
    ctx.beginPath();
    ctx.moveTo(400 + Math.cos(a) * r1, 400 + Math.sin(a) * r1);
    ctx.lineTo(400 + Math.cos(a) * 240, 400 + Math.sin(a) * 240);
    ctx.lineWidth = i % 3 === 0 ? 7 : 4;
    ctx.strokeStyle = "#5a3f1c";
    ctx.stroke();
  }
  // rete: two crossing arcs and a pointer
  ctx.beginPath();
  ctx.ellipse(400, 400, 180, 240, 0, 0, Math.PI * 2);
  ctx.lineWidth = 14;
  ctx.strokeStyle = "#6d4f22";
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(400, 120);
  ctx.lineTo(400, 680);
  ctx.lineWidth = 10;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(400, 400);
  ctx.lineTo(660, 250);
  ctx.lineWidth = 16;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(660, 250, 20, 0, Math.PI * 2);
  ctx.fillStyle = "#efe6d0";
  ctx.fill();
  ctx.stroke();
}

function drawRider(ctx: CanvasRenderingContext2D) {
  // horse
  ctx.beginPath();
  ctx.moveTo(120, 620);
  ctx.quadraticCurveTo(150, 470, 300, 470);
  ctx.lineTo(520, 470);
  ctx.quadraticCurveTo(640, 480, 690, 400);
  ctx.quadraticCurveTo(720, 470, 700, 540);
  ctx.quadraticCurveTo(660, 560, 620, 560);
  ctx.lineTo(300, 570);
  ctx.quadraticCurveTo(200, 580, 200, 700);
  ctx.lineTo(150, 700);
  ctx.quadraticCurveTo(120, 660, 120, 620);
  ctx.closePath();
  stroke(ctx, 14);
  ctx.fillStyle = "#4b3a34";
  ctx.fill();
  ctx.stroke();
  // legs
  ctx.lineWidth = 26;
  ctx.strokeStyle = INK;
  for (const x of [250, 340, 560, 640]) {
    ctx.beginPath();
    ctx.moveTo(x, 560);
    ctx.lineTo(x + (x < 450 ? -12 : 16), 780);
    ctx.stroke();
  }
  // rider
  ctx.beginPath();
  ctx.roundRect(430, 250, 150, 230, 40);
  stroke(ctx, 14);
  ctx.fillStyle = "#8f3b32";
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(505, 220, 58, 0, Math.PI * 2);
  stroke(ctx, 12);
  ctx.fillStyle = "#dca781";
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(505, 178, 62, 34, 0, Math.PI, Math.PI * 2);
  stroke(ctx, 11);
  ctx.fillStyle = "#5b6470";
  ctx.fill();
  ctx.stroke();
  // spear
  ctx.beginPath();
  ctx.moveTo(300, 700);
  ctx.lineTo(760, 120);
  ctx.lineWidth = 12;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

export function cardTexture(kind: Kind): THREE.CanvasTexture {
  const hit = cache.get(kind);
  if (hit) return hit;
  const wide = kind === "books" || kind === "rider" || kind === "tablet";
  const canvas = document.createElement("canvas");
  canvas.width = kind === "rider" ? 900 : wide ? 900 : 600;
  canvas.height = kind === "rider" ? 900 : wide ? 900 : 1000;
  const ctx = canvas.getContext("2d")!;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  if (kind === "books") drawBooks(ctx);
  else if (kind === "tablet") drawTablet(ctx);
  else if (kind === "astrolabe") drawAstrolabe(ctx);
  else if (kind === "rider") drawRider(ctx);
  else drawPerson(ctx, persona(kind));
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  cache.set(kind, tex);
  return tex;
}

export const cardAspect = (kind: Kind) => {
  if (kind === "rider") return 1;
  if (kind === "books" || kind === "tablet") return 1;
  return 0.6;
};
