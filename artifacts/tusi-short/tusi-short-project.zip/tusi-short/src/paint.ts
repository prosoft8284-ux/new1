import * as THREE from "three";

const cache = new Map<string, THREE.CanvasTexture>();

function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function texture(key: string, size: number, draw: (ctx: CanvasRenderingContext2D, s: number) => void) {
  const hit = cache.get(key);
  if (hit) return hit;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  cache.set(key, tex);
  return tex;
}

function noise(ctx: CanvasRenderingContext2D, s: number, seed: number, count: number, alpha: number, light: boolean, maxRad = s / 26) {
  const r = rng(seed);
  for (let i = 0; i < count; i++) {
    const x = r() * s;
    const y = r() * s;
    const rad = 0.8 + r() * maxRad;
    ctx.fillStyle = light ? `rgba(255,255,255,${alpha * r()})` : `rgba(28,18,26,${alpha * r()})`;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function plaster(base: string, shade: string): THREE.CanvasTexture {
  return texture(`plaster:${base}:${shade}`, 512, (ctx, s) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    noise(ctx, s, 7, 1800, 0.07, true, s / 90);
    noise(ctx, s, 11, 1400, 0.09, false, s / 90);
    // damp patches low on the wall
    const r = rng(31);
    for (let i = 0; i < 14; i++) {
      ctx.fillStyle = shade;
      ctx.globalAlpha = 0.05 + r() * 0.07;
      ctx.beginPath();
      ctx.ellipse(r() * s, s * (0.45 + r() * 0.55), 30 + r() * 90, 16 + r() * 60, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    // dark seam at the bottom, painted in like the reference
    const grad = ctx.createLinearGradient(0, s * 0.82, 0, s);
    grad.addColorStop(0, "rgba(20,12,20,0)");
    grad.addColorStop(1, "rgba(20,12,20,0.55)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, s * 0.82, s, s * 0.18);
  });
}

export function brick(base: string, mortar: string): THREE.CanvasTexture {
  return texture(`brick:${base}:${mortar}`, 512, (ctx, s) => {
    ctx.fillStyle = mortar;
    ctx.fillRect(0, 0, s, s);
    const r = rng(5);
    const rows = 10;
    const h = s / rows;
    for (let row = 0; row < rows; row++) {
      const offset = row % 2 === 0 ? 0 : -h;
      for (let x = offset; x < s; x += h * 2) {
        const v = 0.85 + r() * 0.3;
        ctx.fillStyle = base;
        ctx.globalAlpha = 1;
        ctx.fillRect(x + 2, row * h + 2, h * 2 - 4, h - 4);
        ctx.fillStyle = `rgba(255,255,255,${0.03 * v})`;
        ctx.fillRect(x + 2, row * h + 2, h * 2 - 4, 3);
      }
    }
    noise(ctx, s, 17, 300, 0.1, false);
  });
}

export function stone(base: string): THREE.CanvasTexture {
  return texture(`stone:${base}`, 512, (ctx, s) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    const r = rng(23);
    ctx.strokeStyle = "rgba(24,18,28,0.35)";
    ctx.lineWidth = 2.5;
    for (let i = 0; i < 26; i++) {
      ctx.beginPath();
      let x = r() * s;
      let y = r() * s;
      ctx.moveTo(x, y);
      for (let k = 0; k < 4; k++) {
        x += (r() - 0.5) * s * 0.25;
        y += (r() - 0.5) * s * 0.2;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    noise(ctx, s, 41, 500, 0.12, true);
    noise(ctx, s, 43, 380, 0.1, false);
  });
}

export function earth(base: string, tuft: string): THREE.CanvasTexture {
  return texture(`earth:${base}:${tuft}`, 512, (ctx, s) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    const r = rng(97);
    for (let i = 0; i < 900; i++) {
      ctx.fillStyle = tuft;
      ctx.globalAlpha = 0.05 + r() * 0.1;
      const x = r() * s;
      const y = r() * s;
      ctx.beginPath();
      ctx.ellipse(x, y, 2 + r() * 7, 1 + r() * 3, r() * 3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    noise(ctx, s, 101, 2600, 0.06, false, s / 70);
    noise(ctx, s, 103, 2000, 0.05, true, s / 70);
  });
}

export function felt(base: string): THREE.CanvasTexture {
  return texture(`felt:${base}`, 256, (ctx, s) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    noise(ctx, s, 61, 600, 0.12, false);
    noise(ctx, s, 67, 400, 0.08, true);
  });
}

export function wood(base: string): THREE.CanvasTexture {
  return texture(`wood:${base}`, 512, (ctx, s) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, s, s);
    const r = rng(13);
    for (let i = 0; i < 26; i++) {
      ctx.strokeStyle = `rgba(26,16,20,${0.08 + r() * 0.16})`;
      ctx.lineWidth = 1 + r() * 3;
      ctx.beginPath();
      const y = r() * s;
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(s * 0.3, y + (r() - 0.5) * 30, s * 0.7, y + (r() - 0.5) * 30, s, y);
      ctx.stroke();
    }
  });
}

/** Tapered flame silhouette, used additively for burning rooftops. */
export function flame(): THREE.CanvasTexture {
  const key = "flame";
  const hit = cache.get(key);
  if (hit) return hit;
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 384;
  const ctx = canvas.getContext("2d")!;
  const draw = (w: number, h: number, top: string, mid: string, bottom: string, alpha: number) => {
    const grad = ctx.createLinearGradient(0, 384 - h, 0, 384);
    grad.addColorStop(0, top);
    grad.addColorStop(0.45, mid);
    grad.addColorStop(1, bottom);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(128, 384 - h);
    ctx.bezierCurveTo(128 + w * 0.35, 384 - h * 0.72, 128 + w, 384 - h * 0.4, 128 + w * 0.62, 384 - h * 0.1);
    ctx.bezierCurveTo(128 + w * 0.4, 384, 128 - w * 0.4, 384, 128 - w * 0.62, 384 - h * 0.1);
    ctx.bezierCurveTo(128 - w, 384 - h * 0.4, 128 - w * 0.35, 384 - h * 0.72, 128, 384 - h);
    ctx.closePath();
    ctx.fill();
  };
  draw(120, 360, "rgba(255,120,30,0)", "rgba(255,140,40,0.85)", "rgba(255,90,20,0.95)", 0.95);
  draw(78, 250, "rgba(255,210,120,0)", "rgba(255,220,140,0.9)", "rgba(255,190,90,0.95)", 0.95);
  draw(38, 130, "rgba(255,255,220,0)", "rgba(255,255,230,0.95)", "rgba(255,240,180,0.95)", 0.95);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  cache.set(key, tex);
  return tex;
}

/** Soft radial sprite used for fire, smoke and contact shadows. */
export function glow(inner: string, outer: string, hard = false): THREE.CanvasTexture {
  return texture(`glow:${inner}:${outer}:${hard}`, 256, (ctx, s) => {
    const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, inner);
    g.addColorStop(hard ? 0.55 : 0.35, inner);
    g.addColorStop(1, outer);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, s, s);
  });
}

export function starfield(): THREE.CanvasTexture {
  return texture("stars", 512, (ctx, s) => {
    ctx.fillStyle = "rgba(0,0,0,1)";
    ctx.fillRect(0, 0, s, s);
    const r = rng(151);
    for (let i = 0; i < 260; i++) {
      const a = 0.3 + r() * 0.7;
      const rad = r() < 0.9 ? 0.8 + r() * 1.1 : 1.8 + r() * 1.6;
      ctx.fillStyle = `rgba(255,255,255,${a})`;
      ctx.beginPath();
      ctx.arc(r() * s, r() * s, rad, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}
