import type { Kind } from "./toon";
import type { V3 } from "./world";

export type SkyMode = "day" | "golden" | "night" | "stars";

export type CamKey = {
  f: number;
  pos: V3;
  look: V3;
  fov?: number;
  roll?: number;
};

export type CastSpec = {
  kind: Kind;
  /** height as a fraction of the visible frame height at that depth */
  hs: number;
  /** screen x, -1 = left edge, 1 = right edge */
  sx?: number;
  /** screen y, -1 = bottom edge, 1 = top edge (default -0.55: standing on the ground) */
  sy?: number;
  /** lift the card up (fractions of frame height) for floating props */
  lift?: number;
  /** metres in front of the camera; omit to anchor on the ground ray */
  dist?: number;
  bob?: number;
};

export type Shot = {
  id: string;
  a: number;
  b: number;
  sky: SkyMode;
  set: "town" | "fortress" | "camp" | "observatory" | "rings";
  burning?: boolean;
  lights?: boolean;
  ground?: boolean;
  keys: CamKey[];
  cards: CastSpec[];
};

const smooth = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const lerp3 = (a: V3, b: V3, t: number): V3 => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

export const SHOTS: Shot[] = [
  {
    id: "hook",
    a: 0,
    b: 155,
    sky: "night",
    set: "town",
    burning: true,
    ground: true,
    keys: [
      { f: 0, pos: [4, 4.6, 41], look: [0, 2.4, 8], fov: 42, roll: 1.6 },
      { f: 155, pos: [3, 4.2, 34], look: [0, 2.4, 6], fov: 40, roll: -1.2 },
    ],
    cards: [
      { kind: "scholar", hs: 0.40, sx: -0.18, dist: 14, bob: 1 },
      { kind: "books", hs: 0.17, sx: 0.26, lift: 0.06, dist: 15 },
    ],
  },
  {
    id: "tus",
    a: 155,
    b: 312,
    sky: "day",
    set: "town",
    ground: true,
    keys: [
      { f: 155, pos: [11, 5.0, 45], look: [0, 2.6, 6], fov: 40, roll: 0.8 },
      { f: 312, pos: [7, 4.6, 37], look: [0, 2.6, 4], fov: 38, roll: -0.6 },
    ],
    cards: [{ kind: "young", hs: 0.42, sx: -0.12, dist: 16, bob: 1 }],
  },
  {
    id: "flight",
    a: 312,
    b: 442,
    sky: "golden",
    set: "town",
    burning: true,
    ground: true,
    keys: [
      { f: 312, pos: [-6, 4.4, 39], look: [-18, 2.4, 6], fov: 42, roll: 2.2 },
      { f: 442, pos: [-10, 4.2, 31], look: [-20, 2.4, 2], fov: 40, roll: -2.0 },
    ],
    cards: [
      { kind: "tusi", hs: 0.40, sx: -0.22, dist: 14, bob: 1 },
      { kind: "books", hs: 0.17, sx: 0.26, lift: 0.06, dist: 15 },
    ],
  },
  {
    id: "alamut",
    a: 442,
    b: 566,
    sky: "golden",
    set: "fortress",
    ground: true,
    keys: [
      { f: 442, pos: [24, 26, 96], look: [118, 26, -40], fov: 40, roll: -1.4 },
      { f: 566, pos: [40, 40, 72], look: [118, 27, -40], fov: 38, roll: 1.6 },
    ],
    cards: [],
  },
  {
    id: "snap",
    a: 566,
    b: 674,
    sky: "golden",
    set: "fortress",
    ground: true,
    keys: [
      { f: 566, pos: [26, 18, 108], look: [104, 15, -18], fov: 40, roll: 1.2 },
      { f: 674, pos: [34, 23, 92], look: [106, 16, -20], fov: 38, roll: -1.2 },
    ],
    cards: [
      { kind: "rider", hs: 0.10, sx: -0.4, dist: 82, lift: 0.01 },
      { kind: "rider", hs: 0.12, sx: 0.02, dist: 70, lift: 0.01 },
      { kind: "rider", hs: 0.09, sx: 0.42, dist: 92, lift: 0.01 },
    ],
  },
  {
    id: "deal",
    a: 674,
    b: 815,
    sky: "day",
    set: "camp",
    ground: true,
    keys: [
      { f: 674, pos: [-120, 4.4, 56], look: [-120, 2.2, 36], fov: 40, roll: -1 },
      { f: 815, pos: [-117, 4.5, 50], look: [-120, 2.2, 36], fov: 38, roll: 1 },
    ],
    cards: [
      { kind: "tusi", hs: 0.44, sx: -0.26, dist: 13 },
      { kind: "hulagu", hs: 0.44, sx: 0.26, dist: 13 },
    ],
  },
  {
    id: "why",
    a: 815,
    b: 1001,
    sky: "golden",
    set: "camp",
    ground: true,
    keys: [
      { f: 815, pos: [-114, 6, 62], look: [-120, 2.6, 36], fov: 44, roll: 0.6 },
      { f: 1001, pos: [-109, 7.5, 70], look: [-120, 2.8, 34], fov: 46, roll: -0.6 },
    ],
    cards: [
      { kind: "astrolabe", hs: 0.30, sx: 0.02, lift: 0.3, dist: 20 },
      { kind: "tusi", hs: 0.34, sx: -0.36, dist: 15 },
      { kind: "hulagu", hs: 0.34, sx: 0.36, dist: 15 },
    ],
  },
  {
    id: "maragheh",
    a: 1001,
    b: 1132,
    sky: "night",
    set: "observatory",
    ground: true,
    keys: [
      { f: 1001, pos: [58, 20, -96], look: [0, 13, -172], fov: 42, roll: -1.4 },
      { f: 1132, pos: [42, 27, -108], look: [0, 14, -174], fov: 40, roll: 1.2 },
    ],
    cards: [],
  },
  {
    id: "work",
    a: 1132,
    b: 1239,
    sky: "stars",
    set: "observatory",
    ground: true,
    keys: [
      { f: 1132, pos: [0, 5.5, -84], look: [0, 6.5, -164], fov: 44, roll: 0.8 },
      { f: 1239, pos: [0, 5.2, -90], look: [0, 6.8, -164], fov: 42, roll: -0.8 },
    ],
    cards: [
      { kind: "tusi", hs: 0.36, sx: -0.3, dist: 18 },
      { kind: "scholar", hs: 0.36, sx: 0.3, dist: 18 },
      { kind: "astrolabe", hs: 0.30, sx: 0, lift: 0.12, dist: 23 },
    ],
  },
  {
    id: "calendar",
    a: 1239,
    b: 1385,
    sky: "stars",
    set: "observatory",
    ground: true,
    keys: [
      { f: 1239, pos: [0, 5.2, -86], look: [0, 5.4, -164], fov: 44, roll: -1 },
      { f: 1385, pos: [0, 5.0, -92], look: [0, 5.6, -164], fov: 42, roll: 1 },
    ],
    cards: [
      { kind: "tablet", hs: 0.40, sx: 0, lift: 0.1, dist: 26 },
      { kind: "worker", hs: 0.32, sx: -0.46, dist: 16 },
      { kind: "scholar", hs: 0.32, sx: 0.46, dist: 16 },
    ],
  },
  {
    id: "rings",
    a: 1385,
    b: 1593,
    sky: "stars",
    set: "rings",
    ground: false,
    keys: [
      { f: 1385, pos: [260, 12, 42], look: [260, 12, 0], fov: 42, roll: 0.5 },
      { f: 1593, pos: [260, 12, 33], look: [260, 12, 0], fov: 40, roll: -0.5 },
    ],
    cards: [],
  },
  {
    id: "twist",
    a: 1593,
    b: 1800,
    sky: "stars",
    set: "observatory",
    ground: true,
    keys: [
      { f: 1593, pos: [72, 30, -68], look: [0, 18, -180], fov: 44, roll: 0.8 },
      { f: 1800, pos: [50, 22, -94], look: [0, 17, -180], fov: 42, roll: -0.6 },
    ],
    cards: [],
  },
];

export const shotAt = (frame: number): Shot => {
  for (const s of SHOTS) if (frame >= s.a && frame < s.b) return s;
  return SHOTS[SHOTS.length - 1];
};

export const camAt = (shot: Shot, frame: number) => {
  const keys = shot.keys;
  if (keys.length === 1 || frame <= keys[0].f) {
    const k = keys[0];
    return { pos: k.pos, look: k.look, fov: k.fov ?? 42, roll: k.roll ?? 0 };
  }
  for (let i = 0; i < keys.length - 1; i++) {
    const k0 = keys[i];
    const k1 = keys[i + 1];
    if (frame >= k0.f && frame <= k1.f) {
      const raw = (frame - k0.f) / Math.max(1, k1.f - k0.f);
      const t = smooth(raw);
      return {
        pos: lerp3(k0.pos, k1.pos, t) as V3,
        look: lerp3(k0.look, k1.look, t) as V3,
        fov: lerp(k0.fov ?? 42, k1.fov ?? k0.fov ?? 42, t),
        roll: lerp(k0.roll ?? 0, k1.roll ?? k0.roll ?? 0, t),
      };
    }
  }
  const k = keys[keys.length - 1];
  return { pos: k.pos, look: k.look, fov: k.fov ?? 42, roll: k.roll ?? 0 };
};

/** 4-frame white flashes on the hard set changes, like the reference shorts. */
export const FLASHES = [154, 311, 814, 1000, 1384, 1592];
