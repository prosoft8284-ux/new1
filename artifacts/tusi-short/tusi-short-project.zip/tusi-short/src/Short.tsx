import { Audio, AbsoluteFill, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useMemo } from "react";
import { Card } from "./cast";
import { FLASHES, SHOTS, Shot, camAt, shotAt } from "./shots";
import { Box, Camp, Dome, Fortress, Ground, INK, Lights, Mountains, Observatory, Rings, Sky, Sun, Town } from "./world";

const W = 1080;
const H = 1920;

const Rig = ({ cam }: { cam: { pos: [number, number, number]; look: [number, number, number]; fov: number; roll: number } }) => {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  camera.position.set(cam.pos[0], cam.pos[1], cam.pos[2]);
  camera.up.set(0, 1, 0);
  camera.lookAt(cam.look[0], cam.look[1], cam.look[2]);
  camera.rotateZ((cam.roll * Math.PI) / 180);
  if (Math.abs(camera.fov - cam.fov) > 0.001) {
    camera.fov = cam.fov;
    camera.updateProjectionMatrix();
  }
  return null;
};

const Set = ({ shot, frame, cam }: { shot: Shot; frame: number; cam: any }) => {
  // Cast is authored in screen space and projected onto the ground plane, so a
  // character always lands where the shot wants it, whatever the camera does.
  const cards = useMemo(() => {
    const [px, py, pz] = cam.pos as [number, number, number];
    const [lx, ly, lz] = cam.look as [number, number, number];
    let fx = lx - px;
    let fy = ly - py;
    let fz = lz - pz;
    const fl = Math.hypot(fx, fy, fz) || 1;
    fx /= fl; fy /= fl; fz /= fl;
    const rl = Math.hypot(fz, fx) || 1;
    const rx = -fz / rl;
    const rz = fx / rl;
    // up = right x forward
    const ux = 0 * fz - rz * fy;
    const uy = rz * fx - rx * fz;
    const uz = rx * fy - 0 * fx;
    const vTan = Math.tan((cam.fov * Math.PI) / 360);
    const aspect = W / H;

    return shot.cards.map((c) => {
      const sx = (c.sx ?? 0) * vTan * aspect;
      const sy = (c.sy ?? -0.55) * vTan;
      // depth: explicit, or the point where the subject's ground ray hits y = 0
      const gx = fx + rx * sx + ux * sy;
      const gy = fy + uy * sy;
      const gz = fz + rz * sx + uz * sy;
      const gl = Math.hypot(gx, gy, gz) || 1;
      let t = c.dist ?? (gy / gl < -0.02 ? -py / (gy / gl) : 40);
      t = Math.min(600, Math.max(6, t));
      const viewH = 2 * vTan * t;
      const h = c.hs * viewH;
      const lift = (c.lift ?? 0) * viewH;
      return {
        spec: c,
        h,
        at: [px + fx * t + rx * sx * t, lift, pz + fz * t + rz * sx * t] as [number, number, number],
      };
    });
  }, [shot, cam.pos.join(","), cam.look.join(","), cam.fov]);

  return (
    <>
      {shot.set === "town" && <Town burning={shot.burning} frame={frame} />}
      {shot.set === "fortress" && <Fortress frame={frame} lights />}
      {shot.set === "camp" && <Camp frame={frame} />}
      {shot.set === "observatory" && <Observatory frame={frame} lit />}
      {shot.set === "rings" && <Rings frame={frame} startFrame={1385} />}
      {cards.map((c, i) => (
        <Card
          key={`${shot.id}-${i}`}
          kind={c.spec.kind}
          at={c.at}
          h={c.h}
          cam={cam}
          bob={c.spec.bob}
          frame={frame}
        />
      ))}
    </>
  );
};

const Overlay = ({ shot, frame }: { shot: Shot; frame: number }) => {
  let flash = 0;
  for (const f of FLASHES) {
    if (frame >= f && frame < f + 6) flash = Math.max(flash, 1 - (frame - f) / 6);
  }
  const tint =
    shot.sky === "golden"
      ? "rgba(255,176,110,0.14)"
      : shot.sky === "night" || shot.sky === "stars"
      ? "rgba(60,80,160,0.16)"
      : "rgba(255,240,210,0.06)";
  return (
    <>
      <AbsoluteFill
        style={{
          background: `radial-gradient(120% 80% at 50% 42%, rgba(0,0,0,0) 38%, rgba(18,10,24,0.42) 100%)`,
          mixBlendMode: "multiply",
        }}
      />
      <AbsoluteFill style={{ background: tint, mixBlendMode: "soft-light" }} />
      {flash > 0 && <AbsoluteFill style={{ background: "#fffaf0", opacity: flash * 0.85 }} />}
      {/* bottom shade so the vertical frame reads like a reel */}
      <AbsoluteFill
        style={{
          background: "linear-gradient(to bottom, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0) 22%, rgba(0,0,0,0) 74%, rgba(0,0,0,0.28) 100%)",
        }}
      />
    </>
  );
};

export const Short = () => {
  const frame = useCurrentFrame();
  const shot = shotAt(frame);
  const cam = camAt(shot, frame);
  const camera = useMemo(() => ({ fov: cam.fov, near: 0.3, far: 2200, position: cam.pos }), []);

  return (
    <AbsoluteFill style={{ backgroundColor: "#0d0b18" }}>
      <ThreeCanvas width={W} height={H} camera={camera as any} gl={{ antialias: true }} dpr={1}>
        <Rig cam={cam} />
        <Sky mode={shot.sky} frame={frame} />
        <Lights mode={shot.burning ? "golden" : shot.sky} />
        <Sun
          position={
            shot.sky === "golden"
              ? shot.set === "camp"
                ? [-620, 150, -380]
                : [520, 190, -430]
              : [220, 460, -520]
          }
          scale={shot.sky === "golden" ? 300 : 180}
          color={shot.sky === "golden" ? "#ffd08a" : "#fff3d0"}
        />
        {shot.ground && <Ground night={shot.sky === "night" || shot.sky === "stars"} />}
        <Mountains />
        <Set shot={shot} frame={frame} cam={cam} />
      </ThreeCanvas>
      <Overlay shot={shot} frame={frame} />
      <Audio src={staticFile("audio/voice.wav")} />
      <Audio src={staticFile("audio/score.wav")} volume={0.6} />
    </AbsoluteFill>
  );
};
