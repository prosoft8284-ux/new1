import { useMemo } from "react";
import * as THREE from "three";
import { cardAspect, cardTexture, Kind } from "./toon";
import { glow } from "./paint";
import type { V3 } from "./world";

export type Cam = { pos: V3; look: V3; fov: number; roll: number };

let shadowTex: THREE.Texture | null = null;
const shadow = () => {
  if (!shadowTex) shadowTex = glow("rgba(16,10,18,0.6)", "rgba(16,10,18,0)", true);
  return shadowTex;
};

export const Card = ({
  kind,
  at,
  h,
  cam,
  yaw,
  bob = 0,
  frame = 0,
  opacity = 1,
}: {
  kind: Kind;
  at: V3;
  h: number;
  cam: Cam;
  yaw?: number;
  bob?: number;
  frame?: number;
  opacity?: number;
}) => {
  const tex = useMemo(() => cardTexture(kind), [kind]);
  const w = h * cardAspect(kind);
  const face = yaw ?? Math.atan2(cam.pos[0] - at[0], cam.pos[2] - at[2]);
  const bobY = bob ? Math.sin((frame / 30) * 2.4 + at[0]) * 0.05 * bob : 0;
  const shadowSize = Math.max(1.4, w * 1.05);
  return (
    <group position={[at[0], at[1], at[2]]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.06, 0]}>
        <planeGeometry args={[shadowSize, shadowSize * 0.8]} />
        <meshBasicMaterial map={shadow()} transparent depthWrite={false} opacity={0.8} />
      </mesh>
      <group rotation={[0, face, 0]}>
        <mesh position={[0, h / 2 + bobY, 0]}>
          <planeGeometry args={[w, h]} />
          <meshBasicMaterial
            map={tex}
            transparent
            toneMapped={false}
            depthWrite={false}
            opacity={opacity}
          />
        </mesh>
      </group>
    </group>
  );
};
