"""Synthesised score for the Tusi short: a march pulse, a low drone and SFX on the cuts.
Everything is generated, no samples. Output: public/audio/score.wav (48 kHz)."""
import os
import wave

import numpy as np

SR = 48000
DUR = 60.0
N = int(SR * DUR)
t = np.arange(N) / SR

L = np.zeros(N, dtype=np.float64)
R = np.zeros(N, dtype=np.float64)

rng = np.random.default_rng(1234)


def add(sig, start, gain=1.0, pan=0.0):
    i = int(start * SR)
    if i >= N:
        return
    n = min(len(sig), N - i)
    gl = gain * (1 - max(0.0, pan) * 0.5)
    gr = gain * (1 + min(0.0, pan) * 0.5)
    L[i : i + n] += sig[:n] * gl
    R[i : i + n] += sig[:n] * gr


def env(n, attack=0.005, decay=0.3):
    a = int(SR * attack)
    d = max(1, n - a)
    e = np.concatenate([np.linspace(0, 1, a), np.exp(-np.linspace(0, 1, d) * (1 / decay))])
    return e[:n]


def kick(dur=0.5, f0=92, f1=44):
    n = int(SR * dur)
    tt = np.arange(n) / SR
    freq = f0 * np.exp(-tt * 14) + f1
    sig = np.sin(2 * np.pi * np.cumsum(freq) / SR)
    return sig * env(n, 0.002, 0.16)


def snare(dur=0.28):
    n = int(SR * dur)
    noise = rng.normal(0, 1, n)
    # crude band shaping
    noise = np.convolve(noise, np.array([0.25, 0.5, 0.25]), mode="same")
    body = np.sin(2 * np.pi * 185 * np.arange(n) / SR) * 0.35
    return (noise * 0.7 + body) * env(n, 0.001, 0.09)


def whoosh(dur=1.1, up=True):
    n = int(SR * dur)
    noise = rng.normal(0, 1, n)
    k = np.hanning(160)
    noise = np.convolve(noise, k / k.sum(), mode="same")
    x = np.linspace(0, 1, n)
    shape = x**2 if up else (1 - x) ** 2
    return noise * shape


def chime(freq=880.0, dur=2.6):
    n = int(SR * dur)
    tt = np.arange(n) / SR
    sig = (
        np.sin(2 * np.pi * freq * tt) * 0.6
        + np.sin(2 * np.pi * freq * 1.5 * tt) * 0.25
        + np.sin(2 * np.pi * freq * 2.02 * tt) * 0.15
    )
    return sig * env(n, 0.01, 0.6)


def pad(freqs, dur, gain=1.0, wobble=0.25):
    n = int(SR * dur)
    tt = np.arange(n) / SR
    sig = np.zeros(n)
    for i, f in enumerate(freqs):
        detune = 1 + (i - len(freqs) / 2) * 0.0015
        sig += np.sin(2 * np.pi * f * detune * tt) / (i + 1.6)
    swell = 0.55 + 0.45 * np.sin(2 * np.pi * 0.07 * tt - np.pi / 2)
    vib = 1 + wobble * 0.02 * np.sin(2 * np.pi * 0.11 * tt)
    return sig * swell * vib * gain


# --- drone under the whole story ------------------------------------------
add(pad([110.0, 164.8, 220.0], 46.5, gain=0.22), 0.0)
add(pad([98.0, 146.8, 196.0], 14.0, gain=0.2), 46.0)

# --- march pulse ----------------------------------------------------------
bpm = 88.0
beat = 60.0 / bpm
start, stop = 4.2, 45.6
i = 0
while True:
    when = start + i * beat
    if when > stop:
        break
    add(kick(), when, gain=0.5 if i % 2 == 0 else 0.34)
    if i % 4 in (1, 3):
        add(snare(), when, gain=0.16, pan=0.15)
    i += 1

# --- SFX on the cuts ------------------------------------------------------
for when in (4.6, 10.0, 14.2, 18.4, 22.0, 26.8, 33.0, 37.4, 40.9, 45.8, 52.8):
    add(whoosh(1.2, up=False), when - 0.55, gain=0.3, pan=-0.2)
    add(whoosh(1.1, up=True), when - 0.1, gain=0.22, pan=0.2)

# revealed geometry (the Tusi couple) + the last line
add(chime(660.0, 3.2), 45.9, gain=0.26, pan=-0.1)
add(chime(990.0, 3.0), 46.5, gain=0.18, pan=0.15)
add(chime(440.0, 4.0), 53.0, gain=0.24)

# final resolve
add(pad([130.8, 196.0, 261.6, 392.0], 6.5, gain=0.26), 53.4)
add(kick(dur=0.9, f0=70, f1=38), 53.4, gain=0.4)

# --- mix ------------------------------------------------------------------
mix = np.stack([L, R], axis=1)
peak = np.max(np.abs(mix))
mix = mix / peak * 0.72
# fade in / out
fade_in = int(SR * 0.4)
fade_out = int(SR * 1.1)
mix[:fade_in] *= np.linspace(0, 1, fade_in)[:, None]
mix[-fade_out:] *= np.linspace(1, 0, fade_out)[:, None]

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "audio", "score.wav")
with wave.open(out, "wb") as w:
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((np.clip(mix, -1, 1) * 32767).astype(np.int16).tobytes())
print("wrote", out, round(len(mix) / SR, 2), "s")
