"""Build the narration for the Tusi short with piper (fa_IR), plus a timings.json
that the Remotion composition uses to line the shots up with the voice."""
import json
import os
import subprocess
import sys
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, "..", "public", "audio")
VOICE_DIR = os.path.join(HERE, "voices")
VENV = os.path.join(ROOT, ".venv", "bin", "python")
MODEL = os.path.join(VOICE_DIR, "fa_IR-amir-medium.onnx")
CONFIG = MODEL + ".json"

# One entry per beat of the script. "gap" = silence after the line, seconds.
LINES = [
    ("hook", "بغداد را آتش زدند، اما کتابخانه‌اش را یک ریاضیدان ایرانی نجات داد.", 0.55),
    ("tus", "خواجه نصیرالدین طوسی در توس به دنیا آمد، سالی که مغول‌ها شهر به شهر می‌سوختند.", 0.4),
    ("flight", "شهر به شهر سوخت، و او از جایی به جای دیگر رفت تا جان و کتاب‌هایش را نجات دهد.", 0.45),
    ("alamut", "او در قلعه الموت پناه گرفت و آن بالا، فلسفه و نجوم نوشت.", 0.45),
    ("snap", "هلاکو در سال هزار و دویست و پنجاه و شش، الموت را گرفت.", 0.35),
    ("deal", "نصیر از قلعه بیرون آمد و یک شرط گذاشت: کشتن دانشمندان بس است.", 0.45),
    ("why", "هلاکو قبول کرد. برای یک امپراتوری، یک تقویم دقیق از یک سردار ارزشمندتر بود.", 0.5),
    ("maragheh", "پس در مراغه رصدخانه‌ای ساخت، با کتابخانه‌ای چهارصد هزار جلدی.", 0.45),
    ("work", "تیمش هفت سال آسمان را رصد کرد و زیج ایلخانی را نوشت.", 0.4),
    ("calendar", "با آن تقویم، سال‌های امپراتوری دقیق شد و خزانه حساب و کتاب پیدا کرد.", 0.45),
    ("tusi", "و نصیر جفت طوسی را کشف کرد: دایره‌ای کوچک که در دایره‌ای بزرگ می‌غلتد، حرکت خطی می‌سازد.", 0.5),
    ("twist", "سیصد سال بعد، کوپرنیک از همین جفت استفاده کرد. مغول‌ها رفتند، محاسبه ماند.", 0.2),
]


def run_tts(text: str, out_path: str) -> None:
    cmd = [
        VENV,
        "-m",
        "piper",
        "-m",
        MODEL,
        "-c",
        CONFIG,
        "-f",
        out_path,
        "--length-scale",
        "0.85",
        "--sentence-silence",
        "0.25",
    ]
    subprocess.run(cmd, input=text.encode("utf-8"), check=True)


def read_wav(path: str):
    with wave.open(path, "rb") as w:
        assert w.getnchannels() == 1, path
        sr = w.getframerate()
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    return sr, data


def trim(data: np.ndarray, thresh: float = 0.006) -> np.ndarray:
    idx = np.where(np.abs(data) > thresh)[0]
    if len(idx) == 0:
        return data
    return data[max(0, idx[0] - 600) : min(len(data), idx[-1] + 3000)]


def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(os.path.join(HERE, "tmp"), exist_ok=True)
    sr = 48000
    pieces = []
    marks = []
    t = 0.35  # lead-in
    pieces.append(np.zeros(int(sr * t), dtype=np.float32))
    for key, text, gap in LINES:
        gap *= 0.55  # the reference style has almost no pauses
        raw_path = os.path.join(HERE, "tmp", f"{key}.wav")
        run_tts(text, raw_path)
        line_sr, data = read_wav(raw_path)
        data = trim(data)
        if line_sr != sr:
            n = int(round(len(data) * sr / line_sr))
            data = np.interp(
                np.linspace(0.0, len(data) - 1, n, dtype=np.float64),
                np.arange(len(data), dtype=np.float64),
                data,
            ).astype(np.float32)
        marks.append({"key": key, "text": text, "start": round(t, 4), "dur": round(len(data) / sr, 4)})
        pieces.append(data)
        t += len(data) / sr
        silence = np.zeros(int(sr * gap), dtype=np.float32)
        pieces.append(silence)
        t += gap

    voice = np.concatenate(pieces)
    target = 60.0  # the short is exactly 60 s
    if len(voice) / sr < target:
        voice = np.concatenate([voice, np.zeros(int(sr * (target - len(voice) / sr)), dtype=np.float32)])
    # gentle normalise to -3 dBFS peak
    peak = float(np.max(np.abs(voice))) or 1.0
    voice = voice * (0.707 / peak)
    total = len(voice) / sr

    with wave.open(os.path.join(OUT, "voice.wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((voice * 32767).astype(np.int16).tobytes())

    with open(os.path.join(HERE, "timings.json"), "w", encoding="utf-8") as f:
        json.dump({"total": round(total, 4), "sampleRate": sr, "marks": marks}, f, ensure_ascii=False, indent=2)

    print(json.dumps({"total": round(total, 3), "marks": [(m["key"], m["start"]) for m in marks]}, ensure_ascii=False))


if __name__ == "__main__":
    sys.exit(main())
